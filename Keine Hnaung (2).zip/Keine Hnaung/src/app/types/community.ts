// Community Mode Types
// Roles & Permissions

export type UserRole = 'mentor' | 'member';

export interface CommunityUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatarUrl?: string;
  joinedAt: string;
  status: 'active' | 'inactive' | 'suspended';
}

export interface MentorProfile extends CommunityUser {
  role: 'mentor';
  communityName: string;
  memberCount: number;
  affiliateCode: string;
  revenueShare: number; // percentage
  methodology?: string;
}

export interface MemberProfile extends CommunityUser {
  role: 'member';
  mentorId: string;
  mentorName: string;
  onboardingComplete: boolean;
  allowedFeatures: string[];
}

// Performance & Analytics

export interface MemberPerformance {
  memberId: string;
  memberName: string;
  avatarUrl?: string;
  metrics: {
    spend: number;
    revenue: number;
    roas: number;
    cpa: number;
    impressions: number;
    clicks: number;
    conversions: number;
  };
  period: {
    start: string;
    end: string;
  };
  improvement: {
    roasChange: number; // percentage
    cpaChange: number; // percentage
    conversionChange: number; // percentage
  };
  riskStatus: 'healthy' | 'warning' | 'critical';
  lastActivity: string;
}

export interface GroupPerformance {
  totalMembers: number;
  activeMembers: number;
  aggregateMetrics: {
    totalSpend: number;
    totalRevenue: number;
    avgRoas: number;
    avgCpa: number;
    totalImpressions: number;
    totalClicks: number;
    totalConversions: number;
  };
  period: {
    start: string;
    end: string;
  };
  trend: {
    spendChange: number;
    revenueChange: number;
    roasChange: number;
  };
}

// AI Analysis for Community

export interface GroupInsight {
  id: string;
  type: 'creative' | 'targeting' | 'budget' | 'strategy' | 'offer';
  severity: 'critical' | 'warning' | 'info' | 'success';
  title: string;
  description: string;
  affectedMembers: number;
  affectedPercentage: number;
  recommendation: string;
  impact: 'high' | 'medium' | 'low';
  createdAt: string;
}

export interface CommonMistake {
  category: string;
  mistake: string;
  occurrence: number; // how many members
  avgImpact: string; // e.g. "-15% ROAS"
  quickFix: string;
}

export interface GroupPattern {
  pattern: string;
  winningApproach: string;
  memberCount: number;
  avgImprovement: string;
  examples: string[];
}

// Templates & Content

export interface MentorTemplate {
  id: string;
  name: string;
  type: 'hook' | 'creative' | 'offer' | 'strategy';
  description: string;
  content: any; // Template-specific content structure
  locked: boolean;
  editableFields: string[];
  createdAt: string;
  usageCount: number;
  avgPerformance?: {
    roas: number;
    ctr: number;
  };
}

export interface StrategyGuardrail {
  id: string;
  name: string;
  description: string;
  rule: {
    type: 'min' | 'max' | 'range' | 'allowed_values' | 'forbidden_values';
    field: string;
    value: any;
  };
  enabled: boolean;
  reason: string;
}

// Affiliate & Revenue

export interface AffiliateStats {
  mentorId: string;
  period: {
    start: string;
    end: string;
  };
  metrics: {
    totalMembers: number;
    activeMembers: number;
    newMembersThisPeriod: number;
    churnedMembers: number;
    retentionRate: number;
  };
  revenue: {
    totalRevenue: number;
    revenueShare: number;
    payoutAmount: number;
    currency: string;
    nextPayoutDate: string;
  };
  performance: {
    conversionRate: number;
    avgMemberLifetime: number; // days
    avgMemberValue: number;
  };
  referrals: {
    totalClicks: number;
    totalSignups: number;
    conversionRate: number;
  };
}

export interface PayoutHistory {
  id: string;
  date: string;
  amount: number;
  currency: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  members: number;
  period: string;
}

// Leaderboard

export interface LeaderboardEntry {
  rank: number;
  memberId: string;
  memberName: string;
  avatarUrl?: string;
  metric: 'roas' | 'cpa' | 'improvement' | 'consistency';
  value: number;
  change: number; // vs previous period
  badge?: 'top_performer' | 'most_improved' | 'consistent' | 'rising_star';
}

// Community Settings

export interface CommunitySettings {
  communityName: string;
  mentorInfo: {
    name: string;
    methodology: string;
    welcomeMessage: string;
  };
  features: {
    aiAnalysis: boolean;
    creativeBuilder: boolean;
    hookBuilder: boolean;
    adBuilder: boolean;
    strategies: boolean;
    analytics: boolean;
  };
  branding: {
    primaryColor: string;
    logoUrl?: string;
    customDomain?: string;
  };
  automation: {
    autoApplyTemplates: boolean;
    autoShareInsights: boolean;
    weeklyReports: boolean;
  };
  guardrails: StrategyGuardrail[];
}

// Onboarding

export interface MemberOnboarding {
  memberId: string;
  mentorName: string;
  communityName: string;
  methodology: string;
  welcomeMessage: string;
  presetTemplates: MentorTemplate[];
  allowedFeatures: string[];
  steps: {
    id: string;
    title: string;
    description: string;
    completed: boolean;
  }[];
}
