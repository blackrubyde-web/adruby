import React, { useState } from 'react';
import { AIAnalysisPage } from './AIAnalysisPage';
import { CreativeBuilderPage } from './builder/CreativeBuildePage';
import { LearningDashboard } from './LearningDashboard';
import { AgencyDashboard } from './AgencyDashboard';
import { DesignSystemShowcase } from './DesignSystemShowcase';
import { WhyAdRuby } from './differentiation/WhyAdRuby';
import { CommunityHub } from './community/CommunityHub';
import { Brain, Palette, Building2, Database, Sparkles, Layout, Users } from 'lucide-react';

type DemoPage = 
  | 'why-adrubi'
  | 'ai-analysis' 
  | 'creative-builder' 
  | 'learning' 
  | 'agency'
  | 'community'
  | 'design-system';

export function MasterDemo() {
  const [currentPage, setCurrentPage] = useState<DemoPage>('why-adrubi');

  const pages = [
    { 
      id: 'why-adrubi' as DemoPage, 
      label: 'Why AdRuby', 
      icon: Sparkles,
      description: 'The differentiation layer'
    },
    { 
      id: 'ai-analysis' as DemoPage, 
      label: 'AI Analysis', 
      icon: Brain,
      description: 'Decision engine'
    },
    { 
      id: 'creative-builder' as DemoPage, 
      label: 'Creative Builder', 
      icon: Palette,
      description: 'Hypothesis-driven'
    },
    { 
      id: 'learning' as DemoPage, 
      label: 'Learning Memory', 
      icon: Database,
      description: 'Gets smarter over time'
    },
    { 
      id: 'agency' as DemoPage, 
      label: 'Agency Dashboard', 
      icon: Building2,
      description: 'Multi-account scale'
    },
    { 
      id: 'community' as DemoPage, 
      label: 'Community Mode', 
      icon: Users,
      description: 'Scale communities'
    },
    { 
      id: 'design-system' as DemoPage, 
      label: 'Design System', 
      icon: Layout,
      description: 'World-class polish'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <div className="sticky top-0 z-50 bg-card border-b border-border shadow-sm">
        <div className="max-w-[1600px] mx-auto px-6">
          <div className="flex items-center gap-1 py-3 overflow-x-auto">
            {pages.map((page) => {
              const Icon = page.icon;
              return (
                <button
                  key={page.id}
                  onClick={() => setCurrentPage(page.id)}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-semibold text-sm transition-all whitespace-nowrap ${
                    currentPage === page.id
                      ? 'bg-foreground text-background'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <div className="text-left">
                    <div>{page.label}</div>
                    <div className="text-xs opacity-70">{page.description}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Page Content */}
      <div>
        {currentPage === 'why-adrubi' && (
          <div className="max-w-[1400px] mx-auto px-6 py-12">
            <WhyAdRuby />
            
            <div className="mt-12 p-8 bg-gradient-to-br from-blue-500/5 to-purple-500/5 border border-blue-500/10 rounded-2xl">
              <h2 className="text-2xl font-bold text-foreground mb-4 text-center">
                The Complete Positioning Stack
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-card border border-border rounded-xl p-6">
                  <div className="text-sm font-bold text-muted-foreground mb-2 uppercase tracking-wide">
                    Level 1: Immediate (0-3s)
                  </div>
                  <ul className="text-sm text-foreground space-y-2">
                    <li>• "Portfolio: 6 accounts • $248k/mo"</li>
                    <li>• "Decision Engine"</li>
                    <li>• Philosophy statements</li>
                  </ul>
                  <div className="mt-4 pt-4 border-t border-border text-xs text-primary font-semibold">
                    User Thinks: "This is professional software"
                  </div>
                </div>

                <div className="bg-card border border-border rounded-xl p-6">
                  <div className="text-sm font-bold text-muted-foreground mb-2 uppercase tracking-wide">
                    Level 2: Understanding (First Session)
                  </div>
                  <ul className="text-sm text-foreground space-y-2">
                    <li>• Market comparison table</li>
                    <li>• "How This Works"</li>
                    <li>• Hypothesis language</li>
                  </ul>
                  <div className="mt-4 pt-4 border-t border-border text-xs text-primary font-semibold">
                    User Thinks: "This is different from competitors"
                  </div>
                </div>

                <div className="bg-card border border-border rounded-xl p-6">
                  <div className="text-sm font-bold text-muted-foreground mb-2 uppercase tracking-wide">
                    Level 3: Conviction (Week 1)
                  </div>
                  <ul className="text-sm text-foreground space-y-2">
                    <li>• Learning memory active</li>
                    <li>• Cross-account insights</li>
                    <li>• Template library growing</li>
                  </ul>
                  <div className="mt-4 pt-4 border-t border-border text-xs text-primary font-semibold">
                    User Thinks: "This thinks like a senior media buyer"
                  </div>
                </div>
              </div>

              <div className="text-center">
                <div className="inline-block bg-card border border-primary/20 rounded-xl p-6">
                  <div className="text-lg font-bold text-foreground mb-2">
                    The Final Positioning Statement
                  </div>
                  <p className="text-sm text-muted-foreground max-w-2xl">
                    "AdRuby is not an ad generator. It's a decision engine that tells you exactly 
                    what to change to scale. Built for senior media buyers and agencies who think 
                    in hypotheses, not random variations. It learns from every test, remembers what 
                    works, and gets smarter over time."
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {currentPage === 'ai-analysis' && (
          <AIAnalysisPage onNavigateToBuilder={() => setCurrentPage('creative-builder')} />
        )}

        {currentPage === 'creative-builder' && (
          <CreativeBuilderPage 
            reason="Hooks lose attention after 1.8 seconds. CTR dropped 34% in last 7 days."
            onBack={() => setCurrentPage('ai-analysis')}
          />
        )}

        {currentPage === 'learning' && <LearningDashboard />}

        {currentPage === 'agency' && <AgencyDashboard />}

        {currentPage === 'community' && <CommunityHub />}

        {currentPage === 'design-system' && <DesignSystemShowcase />}
      </div>
    </div>
  );
}