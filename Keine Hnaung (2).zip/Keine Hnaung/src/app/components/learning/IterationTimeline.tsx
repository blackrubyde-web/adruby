import React from 'react';
import { CheckCircle, TrendingUp, TrendingDown, MinusCircle, Clock } from 'lucide-react';

export interface TimelineEntry {
  id: string;
  date: string;
  testName: string;
  hypothesis: string;
  whatChanged: string;
  result: 'winner' | 'loser' | 'neutral' | 'running';
  metrics: {
    ctr: { before: string; after: string };
    cpa: { before: string; after: string };
    roas?: { before: string; after: string };
  };
  learnings: string[];
  confidence: 'high' | 'medium' | 'low';
}

interface IterationTimelineProps {
  entries: TimelineEntry[];
}

export function IterationTimeline({ entries }: IterationTimelineProps) {
  const getResultConfig = (result: TimelineEntry['result']) => {
    const configs = {
      winner: {
        icon: CheckCircle,
        color: 'text-green-600',
        bg: 'bg-green-500/10',
        border: 'border-green-500/20',
        label: 'Winner'
      },
      loser: {
        icon: TrendingDown,
        color: 'text-red-600',
        bg: 'bg-red-500/10',
        border: 'border-red-500/20',
        label: 'Lost'
      },
      neutral: {
        icon: MinusCircle,
        color: 'text-gray-600',
        bg: 'bg-gray-500/10',
        border: 'border-gray-500/20',
        label: 'No Change'
      },
      running: {
        icon: Clock,
        color: 'text-blue-600',
        bg: 'bg-blue-500/10',
        border: 'border-blue-500/20',
        label: 'Running'
      }
    };
    return configs[result];
  };

  const getConfidenceBadge = (confidence: TimelineEntry['confidence']) => {
    const configs = {
      high: { label: 'High Confidence', color: 'text-green-600', bg: 'bg-green-500/10' },
      medium: { label: 'Medium Confidence', color: 'text-blue-600', bg: 'bg-blue-500/10' },
      low: { label: 'Low Confidence', color: 'text-yellow-600', bg: 'bg-yellow-500/10' }
    };
    return configs[confidence];
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-xl font-bold text-foreground mb-2">Iteration Timeline</h2>
        <p className="text-sm text-muted-foreground">
          Every test, every change, every learning
        </p>
      </div>

      {/* Timeline */}
      <div className="relative">
        {/* Vertical Line */}
        <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-border" />

        {/* Entries */}
        <div className="space-y-6">
          {entries.map((entry, index) => {
            const resultConfig = getResultConfig(entry.result);
            const confidenceConfig = getConfidenceBadge(entry.confidence);
            const ResultIcon = resultConfig.icon;

            return (
              <div key={entry.id} className="relative pl-16">
                {/* Timeline Dot */}
                <div
                  className={`absolute left-3.5 top-3 w-5 h-5 rounded-full border-4 border-background ${resultConfig.bg} flex items-center justify-center`}
                >
                  <div className={`w-2 h-2 rounded-full ${resultConfig.color.replace('text-', 'bg-')}`} />
                </div>

                {/* Card */}
                <div className={`bg-card border rounded-xl p-5 ${resultConfig.border} hover:shadow-lg transition-all`}>
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <div className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${resultConfig.bg} ${resultConfig.color}`}>
                          {resultConfig.label}
                        </div>
                        <div className={`px-2 py-1 rounded text-[10px] font-bold ${confidenceConfig.bg} ${confidenceConfig.color}`}>
                          {confidenceConfig.label.replace(' Confidence', '')}
                        </div>
                        <span className="text-xs text-muted-foreground ml-auto">{entry.date}</span>
                      </div>
                      <h3 className="font-bold text-foreground text-base mb-1">
                        {entry.testName}
                      </h3>
                      <p className="text-xs text-muted-foreground">
                        {entry.hypothesis}
                      </p>
                    </div>
                  </div>

                  {/* What Changed */}
                  <div className="mb-4 p-3 bg-muted/30 rounded-lg">
                    <div className="text-[10px] font-bold text-foreground uppercase tracking-wide mb-1">
                      What Changed
                    </div>
                    <p className="text-xs text-foreground">{entry.whatChanged}</p>
                  </div>

                  {/* Metrics */}
                  <div className="grid grid-cols-3 gap-3 mb-4">
                    <div>
                      <div className="text-[10px] text-muted-foreground mb-1">CTR</div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground line-through">
                          {entry.metrics.ctr.before}
                        </span>
                        <span className="text-xs font-bold text-foreground">
                          {entry.metrics.ctr.after}
                        </span>
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-muted-foreground mb-1">CPA</div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground line-through">
                          {entry.metrics.cpa.before}
                        </span>
                        <span className="text-xs font-bold text-foreground">
                          {entry.metrics.cpa.after}
                        </span>
                      </div>
                    </div>
                    {entry.metrics.roas && (
                      <div>
                        <div className="text-[10px] text-muted-foreground mb-1">ROAS</div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-muted-foreground line-through">
                            {entry.metrics.roas.before}
                          </span>
                          <span className="text-xs font-bold text-foreground">
                            {entry.metrics.roas.after}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Learnings */}
                  {entry.learnings.length > 0 && (
                    <div className={`p-3 rounded-lg border ${resultConfig.bg} ${resultConfig.border}`}>
                      <div className="flex items-center gap-2 mb-2">
                        <ResultIcon className={`w-4 h-4 ${resultConfig.color}`} />
                        <div className="text-xs font-bold text-foreground">
                          What We Learned
                        </div>
                      </div>
                      <ul className="space-y-1">
                        {entry.learnings.map((learning, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <div className={`w-1 h-1 rounded-full flex-shrink-0 mt-1.5 ${resultConfig.color.replace('text-', 'bg-')}`} />
                            <span className="text-xs text-foreground">{learning}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
