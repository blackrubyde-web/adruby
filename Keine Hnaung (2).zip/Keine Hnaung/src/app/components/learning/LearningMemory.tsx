import React from 'react';
import { Brain, TrendingUp, AlertTriangle, Lightbulb } from 'lucide-react';

export interface Learning {
  id: string;
  category: 'audience' | 'creative' | 'timing' | 'offer';
  insight: string;
  confidence: 'high' | 'medium' | 'low';
  impact: 'high' | 'medium' | 'low';
  basedOn: string; // How many tests/data points
  actionable: string; // What to do with this
}

interface LearningMemoryProps {
  learnings: Learning[];
}

export function LearningMemory({ learnings }: LearningMemoryProps) {
  const getCategoryConfig = (category: Learning['category']) => {
    const configs = {
      audience: {
        icon: '👥',
        label: 'Audience',
        color: 'text-blue-600',
        bg: 'bg-blue-500/10',
        border: 'border-blue-500/20'
      },
      creative: {
        icon: '🎨',
        label: 'Creative',
        color: 'text-purple-600',
        bg: 'bg-purple-500/10',
        border: 'border-purple-500/20'
      },
      timing: {
        icon: '⏰',
        label: 'Timing',
        color: 'text-green-600',
        bg: 'bg-green-500/10',
        border: 'border-green-500/20'
      },
      offer: {
        icon: '💰',
        label: 'Offer',
        color: 'text-primary',
        bg: 'bg-primary/10',
        border: 'border-primary/20'
      }
    };
    return configs[category];
  };

  const getImpactIcon = (impact: Learning['impact']) => {
    if (impact === 'high') return <TrendingUp className="w-4 h-4 text-green-600" />;
    if (impact === 'medium') return <Lightbulb className="w-4 h-4 text-blue-600" />;
    return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
  };

  // Group by category
  const groupedLearnings = learnings.reduce((acc, learning) => {
    if (!acc[learning.category]) acc[learning.category] = [];
    acc[learning.category].push(learning);
    return acc;
  }, {} as Record<string, Learning[]>);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 bg-gradient-to-br from-primary to-blue-600 rounded-xl flex items-center justify-center">
          <Brain className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-foreground">Learning Memory</h2>
          <p className="text-sm text-muted-foreground">
            What this account has learned over time
          </p>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="bg-card border border-border rounded-xl p-4 text-center">
          <div className="text-2xl font-bold text-foreground">{learnings.length}</div>
          <div className="text-xs text-muted-foreground mt-1">Total Learnings</div>
        </div>
        <div className="bg-card border border-border rounded-xl p-4 text-center">
          <div className="text-2xl font-bold text-green-600">
            {learnings.filter(l => l.confidence === 'high').length}
          </div>
          <div className="text-xs text-muted-foreground mt-1">High Confidence</div>
        </div>
        <div className="bg-card border border-border rounded-xl p-4 text-center">
          <div className="text-2xl font-bold text-primary">
            {learnings.filter(l => l.impact === 'high').length}
          </div>
          <div className="text-xs text-muted-foreground mt-1">High Impact</div>
        </div>
        <div className="bg-card border border-border rounded-xl p-4 text-center">
          <div className="text-2xl font-bold text-blue-600">
            {Object.keys(groupedLearnings).length}
          </div>
          <div className="text-xs text-muted-foreground mt-1">Categories</div>
        </div>
      </div>

      {/* Learnings by Category */}
      {Object.entries(groupedLearnings).map(([category, categoryLearnings]) => {
        const config = getCategoryConfig(category as Learning['category']);
        
        return (
          <div key={category} className="space-y-3">
            {/* Category Header */}
            <div className="flex items-center gap-2 mb-3">
              <span className="text-2xl">{config.icon}</span>
              <h3 className={`font-bold text-sm uppercase tracking-wide ${config.color}`}>
                {config.label}
              </h3>
              <div className="h-px flex-1 bg-border ml-2" />
            </div>

            {/* Learning Cards */}
            <div className="space-y-3">
              {categoryLearnings.map((learning) => (
                <div
                  key={learning.id}
                  className={`bg-card border rounded-xl p-4 ${config.border} hover:shadow-md transition-all`}
                >
                  {/* Header */}
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      {getImpactIcon(learning.impact)}
                      <div className={`text-xs font-bold uppercase ${config.color}`}>
                        {learning.impact} Impact
                      </div>
                    </div>
                    <div className={`px-2 py-1 rounded text-[10px] font-bold ${
                      learning.confidence === 'high' 
                        ? 'bg-green-500/10 text-green-600'
                        : learning.confidence === 'medium'
                        ? 'bg-blue-500/10 text-blue-600'
                        : 'bg-yellow-500/10 text-yellow-600'
                    }`}>
                      {learning.confidence.toUpperCase()} CONFIDENCE
                    </div>
                  </div>

                  {/* Insight */}
                  <p className="text-sm font-semibold text-foreground mb-3 leading-relaxed">
                    {learning.insight}
                  </p>

                  {/* Based On */}
                  <div className="text-xs text-muted-foreground mb-3">
                    📊 Based on: {learning.basedOn}
                  </div>

                  {/* Actionable */}
                  <div className={`p-3 rounded-lg ${config.bg}`}>
                    <div className="text-[10px] font-bold text-foreground uppercase tracking-wide mb-1">
                      What to Do
                    </div>
                    <p className="text-xs text-foreground">
                      {learning.actionable}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}
