import React, { useState } from 'react';
import { ArrowLeft, Sparkles, Target, GitCompare } from 'lucide-react';
import { toast } from 'sonner';
import { TestingHypothesisPanel, TestingFocus } from './TestingHypothesisPanel';
import { VariantComparisonView, Variant } from './VariantComparisonView';

interface PrecisionCreativeBuilderProps {
  reason?: string;
  onBack?: () => void;
}

type BuilderStep = 'hypothesis' | 'generate' | 'compare';

export function PrecisionCreativeBuilder({ reason, onBack }: PrecisionCreativeBuilderProps) {
  const [currentStep, setCurrentStep] = useState<BuilderStep>('hypothesis');
  const [testingFocus, setTestingFocus] = useState<TestingFocus>('hook');
  const [variantCount, setVariantCount] = useState(4);
  const [generatedVariants, setGeneratedVariants] = useState<Variant[]>([]);

  // Hypothesis templates based on focus
  const hypothesisTemplates: Record<TestingFocus, { hypothesis: string; control: string }> = {
    hook: {
      hypothesis: 'Pain-point hooks will outperform curiosity hooks for cold traffic by creating immediate relevance',
      control: 'Keep body copy, CTA, and visuals identical across all variants'
    },
    visual: {
      hypothesis: 'Product-in-use visuals will outperform lifestyle shots by making the value more tangible',
      control: 'Keep all copy (headline, body, CTA) identical across all variants'
    },
    copy: {
      hypothesis: 'Feature-focused copy will outperform benefit-focused copy for this technical audience',
      control: 'Keep hook, CTA, and visual style identical across all variants'
    },
    cta: {
      hypothesis: 'High-urgency CTAs will outperform low-pressure CTAs for warm traffic',
      control: 'Keep headline, body copy, and visuals identical across all variants'
    },
    proof: {
      hypothesis: 'Specific numbers (10,000+ users) will outperform generic testimonials by adding credibility',
      control: 'Keep hook, body copy, and CTA identical across all variants'
    },
    offer: {
      hypothesis: 'Discount-first framing will outperform value-first framing for price-sensitive segments',
      control: 'Keep visuals and proof elements identical across all variants'
    }
  };

  const currentHypothesis = hypothesisTemplates[testingFocus];

  const handleGenerate = () => {
    // Mock variant generation
    const mockVariants: Variant[] = [
      {
        id: 'control',
        name: 'V1',
        purpose: 'Control - Current best performer',
        changes: ['No changes (baseline)'],
        isControl: true
      },
      {
        id: 'variant-1',
        name: 'V2',
        purpose: 'Test pain-point hook with urgency',
        changes: [
          'Hook: "Stop wasting $2,000/month on underperforming ads"',
          'Emphasizes direct cost (pain point)'
        ]
      },
      {
        id: 'variant-2',
        name: 'V3',
        purpose: 'Test social proof hook',
        changes: [
          'Hook: "Join 10,000+ marketers who cut CPA by 40%"',
          'Adds credibility through numbers'
        ]
      },
      {
        id: 'variant-3',
        name: 'V4',
        purpose: 'Test curiosity + FOMO hook',
        changes: [
          'Hook: "The ad strategy your competitors don\'t want you to know"',
          'Creates intrigue and competitive pressure'
        ]
      }
    ];

    setGeneratedVariants(mockVariants);
    setCurrentStep('compare');
    toast.success(`${variantCount} surgical variants generated`);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Context Banner */}
      {reason && (
        <div className="bg-primary/10 border-b border-primary/20 px-6 py-3">
          <div className="max-w-[1600px] mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                <Target className="w-4 h-4 text-white" />
              </div>
              <div>
                <span className="text-xs font-semibold text-primary uppercase tracking-wide">Fixing Priority #1: </span>
                <span className="text-sm font-semibold text-foreground">{reason}</span>
              </div>
            </div>
            {onBack && (
              <button
                onClick={onBack}
                className="px-3 py-1.5 bg-card border border-border rounded-lg text-xs font-semibold hover:bg-muted/50 transition-all flex items-center gap-2"
              >
                <ArrowLeft className="w-3 h-3" />
                Back to Analysis
              </button>
            )}
          </div>
        </div>
      )}

      <div className="max-w-[1600px] mx-auto px-6 py-8">
        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-6">
            {[
              { key: 'hypothesis', label: '1. Define Hypothesis', icon: Target },
              { key: 'generate', label: '2. Generate Variants', icon: Sparkles },
              { key: 'compare', label: '3. Compare & Deploy', icon: GitCompare }
            ].map((step, index) => {
              const Icon = step.icon;
              const isActive = currentStep === step.key;
              const isComplete = 
                (step.key === 'hypothesis' && (currentStep === 'generate' || currentStep === 'compare')) ||
                (step.key === 'generate' && currentStep === 'compare');

              return (
                <React.Fragment key={step.key}>
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                        isComplete
                          ? 'bg-green-600 text-white'
                          : isActive
                          ? 'bg-primary text-white'
                          : 'bg-muted text-muted-foreground'
                      }`}
                    >
                      {isComplete ? (
                        <span className="text-lg">✓</span>
                      ) : (
                        <Icon className="w-5 h-5" />
                      )}
                    </div>
                    <div>
                      <div
                        className={`text-sm font-bold ${
                          isActive ? 'text-foreground' : 'text-muted-foreground'
                        }`}
                      >
                        {step.label}
                      </div>
                    </div>
                  </div>
                  {index < 2 && (
                    <div
                      className={`h-0.5 w-16 transition-all ${
                        isComplete ? 'bg-green-600' : 'bg-border'
                      }`}
                    />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>

        {/* Step 1: Define Hypothesis */}
        {currentStep === 'hypothesis' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground mb-2">
                Define Testing Hypothesis
              </h1>
              <p className="text-sm text-muted-foreground">
                No random generation. Every variant must test a specific hypothesis.
              </p>
            </div>

            <TestingHypothesisPanel
              focus={testingFocus}
              hypothesis={currentHypothesis.hypothesis}
              controlElement={currentHypothesis.control}
              onChange={(focus) => setTestingFocus(focus)}
            />

            {/* Variant Count */}
            <div className="bg-card border border-border rounded-xl p-5">
              <h3 className="font-bold text-foreground mb-4 text-sm">Variant Count</h3>
              <p className="text-xs text-muted-foreground mb-4">
                More variants = more data, but slower decisions. Start with 4.
              </p>
              <div className="grid grid-cols-6 gap-2">
                {[3, 4, 6, 8, 12, 16].map((count) => (
                  <button
                    key={count}
                    onClick={() => setVariantCount(count)}
                    className={`px-4 py-3 rounded-lg font-bold text-sm transition-all ${
                      variantCount === count
                        ? 'bg-primary text-white'
                        : 'bg-muted text-foreground hover:bg-muted/70'
                    }`}
                  >
                    {count}
                  </button>
                ))}
              </div>
            </div>

            {/* Action */}
            <button
              onClick={() => setCurrentStep('generate')}
              className="w-full px-6 py-4 bg-primary text-white rounded-xl font-bold hover:bg-primary/90 transition-all shadow-md hover:shadow-xl flex items-center justify-center gap-2"
            >
              Continue to Generation
            </button>
          </div>
        )}

        {/* Step 2: Generate (Confirmation) */}
        {currentStep === 'generate' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground mb-2">
                Generate Surgical Variants
              </h1>
              <p className="text-sm text-muted-foreground">
                Confirm your testing strategy before generation
              </p>
            </div>

            {/* Summary */}
            <div className="bg-gradient-to-br from-primary/5 to-blue-500/5 border border-primary/20 rounded-xl p-6">
              <h3 className="font-bold text-foreground mb-4">Testing Summary</h3>
              
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="text-xs font-bold text-primary uppercase tracking-wide min-w-[100px]">
                    Focus:
                  </div>
                  <div className="text-sm font-semibold text-foreground">
                    {hypothesisTemplates[testingFocus].hypothesis.split(' ')[0]} Testing
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="text-xs font-bold text-primary uppercase tracking-wide min-w-[100px]">
                    Hypothesis:
                  </div>
                  <div className="text-sm text-foreground">
                    {currentHypothesis.hypothesis}
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="text-xs font-bold text-primary uppercase tracking-wide min-w-[100px]">
                    Control:
                  </div>
                  <div className="text-sm text-foreground">
                    {currentHypothesis.control}
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="text-xs font-bold text-primary uppercase tracking-wide min-w-[100px]">
                    Variants:
                  </div>
                  <div className="text-sm font-bold text-foreground">
                    {variantCount} variants (1 control + {variantCount - 1} test variants)
                  </div>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => setCurrentStep('hypothesis')}
                className="px-6 py-3 bg-card border border-border text-foreground rounded-lg font-semibold hover:bg-muted/50 transition-all"
              >
                ← Back
              </button>
              <button
                onClick={handleGenerate}
                className="flex-1 px-6 py-4 bg-primary text-white rounded-xl font-bold hover:bg-primary/90 transition-all shadow-md hover:shadow-xl flex items-center justify-center gap-2"
              >
                <Sparkles className="w-5 h-5" />
                Generate {variantCount} Surgical Variants
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Compare */}
        {currentStep === 'compare' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-foreground mb-2">
                  Variant Comparison
                </h1>
                <p className="text-sm text-muted-foreground">
                  Review variants, differences are highlighted
                </p>
              </div>

              <button
                onClick={() => toast.success('Deploying all variants to Meta Ads...')}
                className="px-6 py-3 bg-green-600 text-white rounded-lg font-bold hover:bg-green-700 transition-all shadow-md hover:shadow-lg"
              >
                Deploy All to Meta Ads
              </button>
            </div>

            {/* Testing Context (Always Visible) */}
            <div className="bg-blue-500/5 border border-blue-500/20 rounded-xl p-4 flex items-start gap-3">
              <Target className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <div className="text-xs font-bold text-blue-600 uppercase tracking-wide mb-1">
                  Testing Focus: {testingFocus.toUpperCase()}
                </div>
                <div className="text-sm text-foreground">
                  {currentHypothesis.hypothesis}
                </div>
              </div>
            </div>

            <VariantComparisonView
              variants={generatedVariants}
              onSelectVariant={(id) => toast.success(`Opening variant ${id} in editor...`)}
              onDuplicateVariant={(id) => toast.success(`Duplicating variant ${id}...`)}
            />

            {/* Bottom Actions */}
            <div className="flex items-center justify-between pt-6 border-t border-border">
              <button
                onClick={() => setCurrentStep('hypothesis')}
                className="px-6 py-3 bg-card border border-border text-foreground rounded-lg font-semibold hover:bg-muted/50 transition-all"
              >
                Generate New Batch
              </button>
              <div className="text-xs text-muted-foreground">
                💡 Tip: Run test for at least 48 hours before making decisions
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
