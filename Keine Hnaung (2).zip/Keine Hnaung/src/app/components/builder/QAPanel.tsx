import React from 'react';
import { AlertTriangle, CheckCircle, RefreshCw, Wand2 } from 'lucide-react';

export type QAIssue = {
  id: string;
  type: 'error' | 'warning' | 'passed';
  title: string;
  description: string;
  autoFixAvailable: boolean;
};

export function QAPanel() {
  const issues: QAIssue[] = [
    {
      id: '1',
      type: 'error',
      title: 'Low Contrast Detected',
      description: 'Text contrast ratio is 3.2:1. Meta requires minimum 4.5:1 for accessibility.',
      autoFixAvailable: true
    },
    {
      id: '2',
      type: 'warning',
      title: 'Text Length Exceeds Recommendation',
      description: 'Primary text is 142 characters. Meta recommends max 125 for optimal mobile display.',
      autoFixAvailable: true
    },
    {
      id: '3',
      type: 'warning',
      title: 'Claim May Require Proof',
      description: 'Headline contains "guaranteed results" which may be flagged by Meta\'s ad review.',
      autoFixAvailable: false
    },
    {
      id: '4',
      type: 'passed',
      title: 'Product Visibility Good',
      description: 'Product occupies 38% of visual area (target: 30-50%).',
      autoFixAvailable: false
    },
    {
      id: '5',
      type: 'passed',
      title: 'Brand Logo Present',
      description: 'Logo detected in recommended position (top-left).',
      autoFixAvailable: false
    }
  ];

  const errorCount = issues.filter(i => i.type === 'error').length;
  const warningCount = issues.filter(i => i.type === 'warning').length;
  const passedCount = issues.filter(i => i.type === 'passed').length;

  return (
    <div className="space-y-6">
      {/* QA Summary */}
      <div>
        <h3 className="font-bold text-foreground mb-4">Quality Assurance</h3>
        <div className="grid grid-cols-3 gap-3 mb-4">
          <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-center">
            <div className="text-2xl font-bold text-red-600">{errorCount}</div>
            <div className="text-xs text-red-600 font-semibold">Errors</div>
          </div>
          <div className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg text-center">
            <div className="text-2xl font-bold text-yellow-600">{warningCount}</div>
            <div className="text-xs text-yellow-600 font-semibold">Warnings</div>
          </div>
          <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-lg text-center">
            <div className="text-2xl font-bold text-green-600">{passedCount}</div>
            <div className="text-xs text-green-600 font-semibold">Passed</div>
          </div>
        </div>
      </div>

      {/* Issues List */}
      <div className="space-y-3">
        {issues.map((issue) => (
          <div
            key={issue.id}
            className={`p-4 rounded-lg border ${
              issue.type === 'error'
                ? 'bg-red-500/5 border-red-500/20'
                : issue.type === 'warning'
                ? 'bg-yellow-500/5 border-yellow-500/20'
                : 'bg-green-500/5 border-green-500/20'
            }`}
          >
            {/* Issue Header */}
            <div className="flex items-start gap-3 mb-2">
              {issue.type === 'error' && (
                <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              )}
              {issue.type === 'warning' && (
                <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              )}
              {issue.type === 'passed' && (
                <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              )}
              <div className="flex-1 min-w-0">
                <h4
                  className={`font-semibold text-sm mb-1 ${
                    issue.type === 'error'
                      ? 'text-red-600'
                      : issue.type === 'warning'
                      ? 'text-yellow-600'
                      : 'text-green-600'
                  }`}
                >
                  {issue.title}
                </h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {issue.description}
                </p>
              </div>
            </div>

            {/* Auto-Fix Button */}
            {issue.autoFixAvailable && (
              <button className="mt-3 w-full px-3 py-1.5 bg-foreground text-background rounded text-xs font-semibold hover:bg-foreground/90 transition-all flex items-center justify-center gap-2">
                <Wand2 className="w-3 h-3" />
                Auto-Fix This Issue
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Batch Actions */}
      <div className="space-y-2 pt-4 border-t border-border">
        <button className="w-full px-4 py-2.5 bg-primary text-white rounded-lg font-semibold text-sm hover:bg-primary/90 transition-all flex items-center justify-center gap-2">
          <Wand2 className="w-4 h-4" />
          Fix All Auto-Fixable Issues
        </button>
        <button className="w-full px-4 py-2.5 bg-card border border-border text-foreground rounded-lg font-semibold text-sm hover:bg-muted/50 transition-all flex items-center justify-center gap-2">
          <RefreshCw className="w-4 h-4" />
          Regenerate Hook Only
        </button>
      </div>
    </div>
  );
}
