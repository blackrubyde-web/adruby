import React from 'react';
import { ShoppingBag, Users, Target, Lightbulb, Briefcase, FileText, Sparkles } from 'lucide-react';

interface TemplateCategory {
  id: string;
  name: string;
  icon: React.ReactNode;
  templates: Template[];
}

interface Template {
  id: string;
  name: string;
  description: string;
  thumbnail: string;
}

interface TemplateLibraryProps {
  onSelectTemplate: (id: string) => void;
  selectedTemplate: string | null;
  variantCount: number;
  onVariantCountChange: (count: number) => void;
}

export function TemplateLibrary({
  onSelectTemplate,
  selectedTemplate,
  variantCount,
  onVariantCountChange
}: TemplateLibraryProps) {
  const categories: TemplateCategory[] = [
    {
      id: 'conversion',
      name: 'Conversion',
      icon: <Target className="w-4 h-4" />,
      templates: [
        { id: 'conv-1', name: 'Direct Offer', description: 'Clear CTA with benefit', thumbnail: '🎯' },
        { id: 'conv-2', name: 'Discount Focus', description: 'Price-driven conversion', thumbnail: '💰' },
        { id: 'conv-3', name: 'Urgency', description: 'Limited time emphasis', thumbnail: '⏰' }
      ]
    },
    {
      id: 'social-proof',
      name: 'Social Proof',
      icon: <Users className="w-4 h-4" />,
      templates: [
        { id: 'proof-1', name: 'Testimonial', description: 'Customer quote + photo', thumbnail: '💬' },
        { id: 'proof-2', name: 'Case Study', description: 'Results-driven proof', thumbnail: '📊' },
        { id: 'proof-3', name: 'Review Highlight', description: 'Star rating + quote', thumbnail: '⭐' }
      ]
    },
    {
      id: 'problem-solution',
      name: 'Problem / Solution',
      icon: <Lightbulb className="w-4 h-4" />,
      templates: [
        { id: 'ps-1', name: 'Pain Point', description: 'Problem-first approach', thumbnail: '❌' },
        { id: 'ps-2', name: 'Before/After', description: 'Transformation focus', thumbnail: '✅' },
        { id: 'ps-3', name: 'Challenge', description: 'Relatable struggle', thumbnail: '🤔' }
      ]
    },
    {
      id: 'ecommerce',
      name: 'E-commerce',
      icon: <ShoppingBag className="w-4 h-4" />,
      templates: [
        { id: 'ecom-1', name: 'Product Hero', description: 'Product-first visual', thumbnail: '📦' },
        { id: 'ecom-2', name: 'Lifestyle', description: 'Product in use', thumbnail: '🏡' },
        { id: 'ecom-3', name: 'Bundle', description: 'Multi-product offer', thumbnail: '🎁' }
      ]
    }
  ];

  const variantOptions = [4, 8, 12, 24];

  return (
    <div className="p-6">
      {/* Header */}
      <div className="mb-6">
        <h3 className="font-bold text-foreground mb-1">Template Library</h3>
        <p className="text-xs text-muted-foreground">
          Choose a template to start generating variants
        </p>
      </div>

      {/* Variant Count Selector */}
      <div className="mb-6 p-4 bg-muted/30 rounded-lg border border-border">
        <label className="text-xs font-semibold text-foreground mb-2 block">
          Generate Variants
        </label>
        <div className="grid grid-cols-4 gap-2">
          {variantOptions.map((count) => (
            <button
              key={count}
              onClick={() => onVariantCountChange(count)}
              className={`px-3 py-2 rounded-lg font-bold text-sm transition-all ${
                variantCount === count
                  ? 'bg-primary text-white'
                  : 'bg-card border border-border text-foreground hover:bg-muted/50'
              }`}
            >
              {count}
            </button>
          ))}
        </div>
      </div>

      {/* Template Categories */}
      <div className="space-y-6">
        {categories.map((category) => (
          <div key={category.id}>
            <div className="flex items-center gap-2 mb-3">
              <div className="text-muted-foreground">{category.icon}</div>
              <h4 className="text-sm font-bold text-foreground">{category.name}</h4>
            </div>
            <div className="space-y-2">
              {category.templates.map((template) => (
                <button
                  key={template.id}
                  onClick={() => onSelectTemplate(template.id)}
                  className={`w-full p-3 rounded-lg border transition-all text-left ${
                    selectedTemplate === template.id
                      ? 'border-primary bg-primary/5'
                      : 'border-border bg-card hover:bg-muted/30'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="text-2xl flex-shrink-0">{template.thumbnail}</div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm text-foreground mb-0.5">
                        {template.name}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {template.description}
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* AI Generate Button */}
      <div className="mt-6 pt-6 border-t border-border">
        <button className="w-full px-4 py-3 bg-primary text-white rounded-lg font-semibold text-sm hover:bg-primary/90 transition-all flex items-center justify-center gap-2">
          <Sparkles className="w-4 h-4" />
          Generate {variantCount} Variants
        </button>
      </div>
    </div>
  );
}
