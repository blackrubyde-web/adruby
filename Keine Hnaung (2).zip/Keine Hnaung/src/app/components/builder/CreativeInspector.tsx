import React from 'react';
import { FileText, Palette, Image, CheckCircle, Download } from 'lucide-react';
import { QAPanel } from './QAPanel';

interface CreativeInspectorProps {
  activeTab: 'copy' | 'design' | 'assets' | 'qa' | 'export';
  onTabChange: (tab: 'copy' | 'design' | 'assets' | 'qa' | 'export') => void;
}

export function CreativeInspector({ activeTab, onTabChange }: CreativeInspectorProps) {
  const tabs = [
    { id: 'copy' as const, label: 'Copy', icon: FileText },
    { id: 'design' as const, label: 'Design', icon: Palette },
    { id: 'assets' as const, label: 'Assets', icon: Image },
    { id: 'qa' as const, label: 'QA', icon: CheckCircle },
    { id: 'export' as const, label: 'Export', icon: Download }
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Tabs */}
      <div className="border-b border-border bg-muted/20">
        <div className="flex">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex-1 px-4 py-3 text-xs font-semibold transition-all flex items-center justify-center gap-2 ${
                activeTab === tab.id
                  ? 'border-b-2 border-primary text-primary bg-background'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted/30'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-6">
        {activeTab === 'copy' && <CopyTab />}
        {activeTab === 'design' && <DesignTab />}
        {activeTab === 'assets' && <AssetsTab />}
        {activeTab === 'qa' && <QAPanel />}
        {activeTab === 'export' && <ExportTab />}
      </div>
    </div>
  );
}

function CopyTab() {
  return (
    <div className="space-y-4">
      <div>
        <label className="text-xs font-semibold text-foreground mb-2 block">
          Headline
        </label>
        <textarea
          className="w-full px-3 py-2 bg-card border border-border rounded-lg text-sm text-foreground resize-none focus:outline-none focus:ring-2 focus:ring-primary/20"
          rows={2}
          placeholder="Enter headline..."
          defaultValue="Transform your ad creative workflow"
        />
        <div className="text-xs text-muted-foreground mt-1">32 characters</div>
      </div>

      <div>
        <label className="text-xs font-semibold text-foreground mb-2 block">
          Primary Text
        </label>
        <textarea
          className="w-full px-3 py-2 bg-card border border-border rounded-lg text-sm text-foreground resize-none focus:outline-none focus:ring-2 focus:ring-primary/20"
          rows={4}
          placeholder="Enter primary text..."
          defaultValue="With AI-powered analysis and insights, create high-converting ads in seconds."
        />
        <div className="text-xs text-muted-foreground mt-1">89 characters</div>
      </div>

      <div>
        <label className="text-xs font-semibold text-foreground mb-2 block">
          Call to Action
        </label>
        <select className="w-full px-3 py-2 bg-card border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20">
          <option>Learn More</option>
          <option>Shop Now</option>
          <option>Sign Up</option>
          <option>Get Started</option>
          <option>Download</option>
        </select>
      </div>

      <button className="w-full px-4 py-2.5 bg-primary text-white rounded-lg font-semibold text-sm hover:bg-primary/90 transition-all">
        Regenerate Copy
      </button>
    </div>
  );
}

function DesignTab() {
  return (
    <div className="space-y-4">
      <div>
        <label className="text-xs font-semibold text-foreground mb-2 block">
          Color Theme
        </label>
        <div className="grid grid-cols-5 gap-2">
          {['#C80000', '#3B82F6', '#10B981', '#F59E0B', '#8B5CF6'].map((color) => (
            <button
              key={color}
              className="aspect-square rounded-lg border-2 border-border hover:border-foreground transition-all"
              style={{ backgroundColor: color }}
            />
          ))}
        </div>
      </div>

      <div>
        <label className="text-xs font-semibold text-foreground mb-2 block">
          Background Style
        </label>
        <select className="w-full px-3 py-2 bg-card border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20">
          <option>Gradient</option>
          <option>Solid Color</option>
          <option>Image</option>
          <option>Pattern</option>
        </select>
      </div>

      <div>
        <label className="text-xs font-semibold text-foreground mb-2 block">
          Text Contrast
        </label>
        <input
          type="range"
          min="0"
          max="100"
          defaultValue="75"
          className="w-full"
        />
      </div>

      <button className="w-full px-4 py-2.5 bg-foreground text-background rounded-lg font-semibold text-sm hover:bg-foreground/90 transition-all">
        Apply Design Changes
      </button>
    </div>
  );
}

function AssetsTab() {
  return (
    <div className="space-y-4">
      <div>
        <label className="text-xs font-semibold text-foreground mb-2 block">
          Product Image
        </label>
        <div className="aspect-square bg-muted/30 rounded-lg border-2 border-dashed border-border flex items-center justify-center cursor-pointer hover:bg-muted/50 transition-all">
          <div className="text-center">
            <Image className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
            <div className="text-xs font-semibold text-foreground">Upload Image</div>
            <div className="text-[10px] text-muted-foreground mt-1">PNG, JPG up to 10MB</div>
          </div>
        </div>
      </div>

      <div>
        <label className="text-xs font-semibold text-foreground mb-2 block">
          Logo
        </label>
        <div className="aspect-video bg-muted/30 rounded-lg border-2 border-dashed border-border flex items-center justify-center cursor-pointer hover:bg-muted/50 transition-all">
          <div className="text-center">
            <div className="text-xs font-semibold text-foreground">Upload Logo</div>
          </div>
        </div>
      </div>

      <button className="w-full px-4 py-2.5 bg-foreground text-background rounded-lg font-semibold text-sm hover:bg-foreground/90 transition-all">
        Browse Asset Library
      </button>
    </div>
  );
}

function ExportTab() {
  return (
    <div className="space-y-4">
      <div>
        <label className="text-xs font-semibold text-foreground mb-2 block">
          Export Format
        </label>
        <div className="space-y-2">
          {['PNG (Web)', 'JPG (High Quality)', 'PDF (Print)', 'MP4 (Video)'].map((format) => (
            <label key={format} className="flex items-center gap-3 p-3 bg-card border border-border rounded-lg cursor-pointer hover:bg-muted/30 transition-all">
              <input type="radio" name="format" className="w-4 h-4" />
              <span className="text-sm font-medium text-foreground">{format}</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <label className="text-xs font-semibold text-foreground mb-2 block">
          Export All Variants
        </label>
        <div className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
          <input type="checkbox" className="w-4 h-4" defaultChecked />
          <span className="text-sm text-foreground">Include all 4 variants (ZIP)</span>
        </div>
      </div>

      <button className="w-full px-4 py-2.5 bg-primary text-white rounded-lg font-semibold text-sm hover:bg-primary/90 transition-all flex items-center justify-center gap-2">
        <Download className="w-4 h-4" />
        Export Creatives
      </button>

      <button className="w-full px-4 py-2.5 bg-foreground text-background rounded-lg font-semibold text-sm hover:bg-foreground/90 transition-all">
        Deploy to Meta Ads
      </button>
    </div>
  );
}
