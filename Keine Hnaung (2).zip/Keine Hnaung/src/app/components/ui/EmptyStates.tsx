import React from 'react';
import { BarChart3, Database, FileText, TrendingUp } from 'lucide-react';

interface EmptyStateProps {
  type: 'no-data' | 'no-results' | 'no-campaigns' | 'no-learnings';
  onAction?: () => void;
  actionLabel?: string;
}

export function EmptyState({ type, onAction, actionLabel }: EmptyStateProps) {
  const configs = {
    'no-data': {
      icon: BarChart3,
      title: 'Insufficient data for analysis',
      description: 'System requires minimum 48 hours of campaign activity and 1,000 impressions to generate actionable insights.',
      action: actionLabel || 'Review Campaign Settings'
    },
    'no-results': {
      icon: Database,
      title: 'No matching records',
      description: 'Adjust filter parameters or expand date range to surface additional data points.',
      action: actionLabel || 'Clear Filters'
    },
    'no-campaigns': {
      icon: TrendingUp,
      title: 'No active campaigns detected',
      description: 'Connect Meta Ads account or activate existing campaigns to begin performance analysis.',
      action: actionLabel || 'Connect Account'
    },
    'no-learnings': {
      icon: FileText,
      title: 'Learning memory initializing',
      description: 'System will begin capturing insights after first campaign iteration. Minimum 2 A/B tests required.',
      action: actionLabel || 'View Testing Guide'
    }
  };

  const config = configs[type];
  const Icon = config.icon;

  return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="text-center max-w-md">
        <div className="w-16 h-16 bg-muted rounded-xl flex items-center justify-center mx-auto mb-4">
          <Icon className="w-8 h-8 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-bold text-foreground mb-2">
          {config.title}
        </h3>
        <p className="text-sm text-muted-foreground leading-relaxed mb-6">
          {config.description}
        </p>
        {onAction && (
          <button
            onClick={onAction}
            className="px-6 py-2.5 bg-foreground text-background rounded-lg font-semibold text-sm hover:bg-foreground/90 transition-all"
          >
            {config.action}
          </button>
        )}
      </div>
    </div>
  );
}

// Loading states with analytical messaging
export function LoadingState({ message }: { message?: string }) {
  const messages = [
    'Analyzing performance vectors',
    'Processing decision tree',
    'Calculating confidence intervals',
    'Indexing historical patterns',
    'Compiling insights'
  ];

  const displayMessage = message || messages[Math.floor(Math.random() * messages.length)];

  return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="text-center">
        <div className="w-12 h-12 border-4 border-primary/20 border-t-primary rounded-full animate-spin mx-auto mb-4" />
        <p className="text-sm font-semibold text-foreground">
          {displayMessage}
        </p>
      </div>
    </div>
  );
}

// Success states
export function SuccessState({ title, description }: { title: string; description: string }) {
  return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="text-center max-w-md">
        <div className="w-16 h-16 bg-green-500/10 rounded-xl flex items-center justify-center mx-auto mb-4">
          <div className="text-3xl">✓</div>
        </div>
        <h3 className="text-lg font-bold text-foreground mb-2">
          {title}
        </h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          {description}
        </p>
      </div>
    </div>
  );
}

// Error states with technical language
export function ErrorState({ 
  title, 
  description, 
  onRetry 
}: { 
  title?: string; 
  description?: string; 
  onRetry?: () => void;
}) {
  return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="text-center max-w-md">
        <div className="w-16 h-16 bg-red-500/10 rounded-xl flex items-center justify-center mx-auto mb-4">
          <div className="text-3xl text-red-600">!</div>
        </div>
        <h3 className="text-lg font-bold text-foreground mb-2">
          {title || 'Analysis interrupted'}
        </h3>
        <p className="text-sm text-muted-foreground leading-relaxed mb-6">
          {description || 'Unable to complete operation. Verify connection integrity and retry.'}
        </p>
        {onRetry && (
          <button
            onClick={onRetry}
            className="px-6 py-2.5 bg-foreground text-background rounded-lg font-semibold text-sm hover:bg-foreground/90 transition-all"
          >
            Retry Operation
          </button>
        )}
      </div>
    </div>
  );
}
