import { useEffect, useState } from 'react';
import { Loader2, Sparkles, CheckCircle } from 'lucide-react';

interface AuthProcessingPageProps {
  message?: string;
  onComplete?: () => void;
}

export function AuthProcessingPage({ 
  message = 'Logging you in...',
  onComplete 
}: AuthProcessingPageProps) {
  const [progress, setProgress] = useState(0);
  const [isComplete, setIsComplete] = useState(false);

  useEffect(() => {
    // Simulate progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsComplete(true);
          if (onComplete) {
            setTimeout(onComplete, 500);
          }
          return 100;
        }
        return prev + 10;
      });
    }, 200);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background px-4">
      <div className="text-center max-w-md">
        {/* Logo */}
        <div className="flex items-center justify-center gap-2 mb-12">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-red-600 flex items-center justify-center">
            <Sparkles className="w-7 h-7 text-white" />
          </div>
          <span className="font-bold text-2xl">AdRuby</span>
        </div>

        {/* Loading Icon */}
        <div className="mb-8 flex items-center justify-center">
          {isComplete ? (
            <CheckCircle className="w-16 h-16 text-green-600 animate-pulse" />
          ) : (
            <Loader2 className="w-16 h-16 text-primary animate-spin" />
          )}
        </div>

        {/* Message */}
        <h2 className="text-2xl font-bold mb-4">
          {isComplete ? 'Success!' : message}
        </h2>
        <p className="text-muted-foreground mb-8">
          {isComplete 
            ? 'Redirecting you to your dashboard...' 
            : 'Please wait while we set up your session'}
        </p>

        {/* Progress Bar */}
        <div className="w-full max-w-xs mx-auto">
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-primary to-red-600 transition-all duration-300 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-sm text-muted-foreground mt-3">{progress}%</p>
        </div>
      </div>
    </div>
  );
}
