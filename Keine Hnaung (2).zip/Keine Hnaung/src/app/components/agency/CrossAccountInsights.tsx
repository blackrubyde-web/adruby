import React from 'react';
import { TrendingUp, TrendingDown, AlertTriangle } from 'lucide-react';

export interface AccountPerformance {
  id: string;
  name: string;
  spend: string;
  roas: number;
  cpa: string;
  change: number; // percentage
  status: 'outperforming' | 'underperforming' | 'average';
}

interface CrossAccountInsightsProps {
  accounts: AccountPerformance[];
  aggregateMetrics: {
    totalSpend: string;
    averageROAS: string;
    totalAccounts: number;
    activeAccounts: number;
  };
}

export function CrossAccountInsights({ accounts, aggregateMetrics }: CrossAccountInsightsProps) {
  const topPerformers = accounts
    .filter(a => a.status === 'outperforming')
    .sort((a, b) => b.roas - a.roas)
    .slice(0, 3);

  const needsAttention = accounts
    .filter(a => a.status === 'underperforming')
    .sort((a, b) => a.roas - b.roas)
    .slice(0, 3);

  const averageROAS = accounts.reduce((sum, a) => sum + a.roas, 0) / accounts.length;
  const medianROAS = [...accounts].sort((a, b) => a.roas - b.roas)[Math.floor(accounts.length / 2)]?.roas || 0;

  return (
    <div className="space-y-6">
      {/* Aggregate Header */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-card border border-border rounded-xl p-4">
          <div className="text-xs text-muted-foreground mb-1 uppercase tracking-wide font-semibold">
            Portfolio Spend
          </div>
          <div className="text-2xl font-bold text-foreground">
            {aggregateMetrics.totalSpend}
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            Across {aggregateMetrics.totalAccounts} accounts
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-4">
          <div className="text-xs text-muted-foreground mb-1 uppercase tracking-wide font-semibold">
            Avg ROAS
          </div>
          <div className="text-2xl font-bold text-foreground">
            {aggregateMetrics.averageROAS}
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            Median: {medianROAS.toFixed(1)}x
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-4">
          <div className="text-xs text-muted-foreground mb-1 uppercase tracking-wide font-semibold">
            Active Accounts
          </div>
          <div className="text-2xl font-bold text-foreground">
            {aggregateMetrics.activeAccounts}
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            {((aggregateMetrics.activeAccounts / aggregateMetrics.totalAccounts) * 100).toFixed(0)}% of portfolio
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-4">
          <div className="text-xs text-muted-foreground mb-1 uppercase tracking-wide font-semibold">
            Needs Attention
          </div>
          <div className="text-2xl font-bold text-primary">
            {needsAttention.length}
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            Below portfolio average
          </div>
        </div>
      </div>

      {/* Performance Distribution */}
      <div className="grid grid-cols-2 gap-6">
        {/* Top Performers */}
        <div className="bg-card border border-border rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-green-600" />
            <h3 className="font-bold text-foreground">Top Performers</h3>
          </div>
          <div className="space-y-3">
            {topPerformers.map((account, index) => (
              <div key={account.id} className="flex items-center gap-3 p-3 bg-green-500/5 border border-green-500/10 rounded-lg">
                <div className="w-6 h-6 bg-green-600 text-white rounded flex items-center justify-center text-xs font-bold flex-shrink-0">
                  {index + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-foreground truncate">
                    {account.name}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Spend: {account.spend} • CPA: {account.cpa}
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="text-sm font-bold text-green-600">
                    {account.roas.toFixed(1)}x
                  </div>
                  <div className="text-xs text-green-600">
                    +{account.change}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Needs Attention */}
        <div className="bg-card border border-border rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-5 h-5 text-primary" />
            <h3 className="font-bold text-foreground">Requires Action</h3>
          </div>
          <div className="space-y-3">
            {needsAttention.map((account, index) => (
              <div key={account.id} className="flex items-center gap-3 p-3 bg-primary/5 border border-primary/10 rounded-lg">
                <div className="w-6 h-6 bg-primary text-white rounded flex items-center justify-center text-xs font-bold flex-shrink-0">
                  !
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-foreground truncate">
                    {account.name}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Spend: {account.spend} • CPA: {account.cpa}
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="text-sm font-bold text-primary">
                    {account.roas.toFixed(1)}x
                  </div>
                  <div className="text-xs text-primary">
                    {account.change}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Performance Table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="px-4 py-3 text-left text-xs font-bold text-foreground uppercase tracking-wide">
                  Account
                </th>
                <th className="px-4 py-3 text-right text-xs font-bold text-foreground uppercase tracking-wide">
                  Spend (30d)
                </th>
                <th className="px-4 py-3 text-right text-xs font-bold text-foreground uppercase tracking-wide">
                  ROAS
                </th>
                <th className="px-4 py-3 text-right text-xs font-bold text-foreground uppercase tracking-wide">
                  CPA
                </th>
                <th className="px-4 py-3 text-right text-xs font-bold text-foreground uppercase tracking-wide">
                  Change
                </th>
                <th className="px-4 py-3 text-center text-xs font-bold text-foreground uppercase tracking-wide">
                  Status
                </th>
              </tr>
            </thead>
            <tbody>
              {accounts.map((account, index) => (
                <tr
                  key={account.id}
                  className={`border-b border-border hover:bg-muted/20 transition-colors ${
                    index % 2 === 0 ? 'bg-muted/5' : ''
                  }`}
                >
                  <td className="px-4 py-3 text-sm font-semibold text-foreground">
                    {account.name}
                  </td>
                  <td className="px-4 py-3 text-sm text-foreground text-right">
                    {account.spend}
                  </td>
                  <td className="px-4 py-3 text-sm font-bold text-foreground text-right">
                    {account.roas.toFixed(1)}x
                  </td>
                  <td className="px-4 py-3 text-sm text-foreground text-right">
                    {account.cpa}
                  </td>
                  <td className="px-4 py-3 text-sm text-right">
                    <span className={`font-semibold ${
                      account.change > 0 ? 'text-green-600' : 'text-primary'
                    }`}>
                      {account.change > 0 ? '+' : ''}{account.change}%
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    {account.status === 'outperforming' && (
                      <TrendingUp className="w-4 h-4 text-green-600 mx-auto" />
                    )}
                    {account.status === 'underperforming' && (
                      <TrendingDown className="w-4 h-4 text-primary mx-auto" />
                    )}
                    {account.status === 'average' && (
                      <div className="w-4 h-0.5 bg-gray-400 mx-auto" />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
