import React from 'react';
import { Database, TrendingUp, Lock, Unlock } from 'lucide-react';

export interface SharedLearning {
  id: string;
  insight: string;
  sourceAccounts: number; // How many accounts contributed
  confidence: 'high' | 'medium' | 'low';
  impact: 'high' | 'medium' | 'low';
  applicableTo: string[]; // Which verticals/industries
  basedOn: {
    tests: number;
    impressions: string;
    spend: string;
  };
  isPrivate: boolean; // Locked to organization
}

interface SharedLearningPoolProps {
  learnings: SharedLearning[];
  organizationName: string;
  totalAccounts: number;
}

export function SharedLearningPool({ learnings, organizationName, totalAccounts }: SharedLearningPoolProps) {
  const highConfidenceLearnings = learnings.filter(l => l.confidence === 'high');
  const crossAccountLearnings = learnings.filter(l => l.sourceAccounts > 1);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
            <Database className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-foreground">Shared Learning Pool</h2>
            <p className="text-sm text-muted-foreground">
              {organizationName} • {totalAccounts} accounts contributing
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="text-2xl font-bold text-foreground">{learnings.length}</div>
            <div className="text-xs text-muted-foreground">Total Learnings</div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-blue-600">{crossAccountLearnings.length}</div>
            <div className="text-xs text-muted-foreground">Cross-Account</div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-card border border-border rounded-xl p-4 text-center">
          <div className="text-2xl font-bold text-foreground">{highConfidenceLearnings.length}</div>
          <div className="text-xs text-muted-foreground mt-1">High Confidence</div>
        </div>
        <div className="bg-card border border-border rounded-xl p-4 text-center">
          <div className="text-2xl font-bold text-foreground">
            {learnings.reduce((sum, l) => sum + l.basedOn.tests, 0)}
          </div>
          <div className="text-xs text-muted-foreground mt-1">Total Tests</div>
        </div>
        <div className="bg-card border border-border rounded-xl p-4 text-center">
          <div className="text-2xl font-bold text-foreground">
            {learnings.reduce((sum, l) => sum + l.sourceAccounts, 0)}
          </div>
          <div className="text-xs text-muted-foreground mt-1">Account Contributions</div>
        </div>
      </div>

      {/* Learning Cards */}
      <div className="space-y-4">
        {learnings.map((learning) => (
          <div
            key={learning.id}
            className="bg-card border border-border rounded-xl p-5 hover:shadow-lg transition-all"
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-2 flex-wrap">
                {/* Confidence */}
                <div className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${
                  learning.confidence === 'high'
                    ? 'bg-green-500/10 text-green-600'
                    : learning.confidence === 'medium'
                    ? 'bg-blue-500/10 text-blue-600'
                    : 'bg-yellow-500/10 text-yellow-600'
                }`}>
                  {learning.confidence} confidence
                </div>

                {/* Impact */}
                <div className={`px-2 py-1 rounded text-[10px] font-bold uppercase flex items-center gap-1 ${
                  learning.impact === 'high'
                    ? 'bg-primary/10 text-primary'
                    : 'bg-gray-500/10 text-gray-600'
                }`}>
                  {learning.impact === 'high' && <TrendingUp className="w-3 h-3" />}
                  {learning.impact} impact
                </div>

                {/* Source Count */}
                <div className="px-2 py-1 bg-blue-500/10 text-blue-600 rounded text-[10px] font-bold">
                  {learning.sourceAccounts} account{learning.sourceAccounts > 1 ? 's' : ''}
                </div>

                {/* Privacy */}
                {learning.isPrivate ? (
                  <div className="px-2 py-1 bg-gray-500/10 text-gray-600 rounded text-[10px] font-bold flex items-center gap-1">
                    <Lock className="w-3 h-3" />
                    Private
                  </div>
                ) : (
                  <div className="px-2 py-1 bg-green-500/10 text-green-600 rounded text-[10px] font-bold flex items-center gap-1">
                    <Unlock className="w-3 h-3" />
                    Shared
                  </div>
                )}
              </div>
            </div>

            {/* Insight */}
            <p className="text-sm font-semibold text-foreground mb-4 leading-relaxed">
              {learning.insight}
            </p>

            {/* Meta Info */}
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <div className="text-xs text-muted-foreground mb-1">Based On</div>
                <div className="text-xs text-foreground">
                  {learning.basedOn.tests} tests • {learning.basedOn.impressions} impressions • {learning.basedOn.spend} spend
                </div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground mb-1">Applicable To</div>
                <div className="flex flex-wrap gap-1">
                  {learning.applicableTo.map((vertical, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 bg-muted text-foreground rounded text-xs"
                    >
                      {vertical}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Cross-Account Indicator */}
            {learning.sourceAccounts > 1 && (
              <div className="pt-4 border-t border-border">
                <div className="flex items-center gap-2 text-xs text-blue-600">
                  <Database className="w-4 h-4" />
                  <span className="font-semibold">
                    Cross-account pattern detected across {learning.sourceAccounts} accounts
                  </span>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
