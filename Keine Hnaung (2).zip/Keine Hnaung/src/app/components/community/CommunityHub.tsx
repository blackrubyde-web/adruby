import React, { useState } from 'react';
import { MentorDashboard } from './MentorDashboard';
import { MemberExperience } from './MemberExperience';
import { AffiliateRevenueDashboard } from './AffiliateRevenueDashboard';
import { CommunitySettings } from './CommunitySettings';
import { MembersList } from './MembersList';
import { Users, DollarSign, Settings as SettingsIcon, UserCircle, List } from 'lucide-react';
import type { UserRole } from '../../types/community';

type CommunityView = 'mentor-dashboard' | 'members-list' | 'member-experience' | 'affiliate' | 'settings';

export function CommunityHub() {
  // Demo: Toggle between Mentor and Member role
  const [currentRole, setCurrentRole] = useState<UserRole>('mentor');
  const [currentView, setCurrentView] = useState<CommunityView>('mentor-dashboard');

  // Role-based views
  const mentorViews = [
    { id: 'mentor-dashboard' as CommunityView, label: 'Control Room', icon: Users },
    { id: 'members-list' as CommunityView, label: 'Members', icon: List },
    { id: 'affiliate' as CommunityView, label: 'Revenue', icon: DollarSign },
    { id: 'settings' as CommunityView, label: 'Settings', icon: SettingsIcon },
  ];

  const memberViews = [
    { id: 'member-experience' as CommunityView, label: 'My Dashboard', icon: UserCircle },
  ];

  const views = currentRole === 'mentor' ? mentorViews : memberViews;

  return (
    <div className="min-h-screen bg-background">
      {/* Role Switcher + Navigation */}
      <div className="sticky top-0 z-50 bg-card border-b border-border shadow-sm">
        <div className="max-w-[1600px] mx-auto px-6">
          <div className="flex items-center justify-between py-3">
            {/* Left: View Navigation */}
            <div className="flex items-center gap-1">
              {views.map((view) => {
                const Icon = view.icon;
                return (
                  <button
                    key={view.id}
                    onClick={() => setCurrentView(view.id)}
                    className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-semibold text-sm transition-all ${
                      currentView === view.id
                        ? 'bg-foreground text-background'
                        : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {view.label}
                  </button>
                );
              })}
            </div>

            {/* Right: Role Switcher (Demo Only) */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground font-semibold">DEMO MODE:</span>
              <button
                onClick={() => {
                  setCurrentRole('mentor');
                  setCurrentView('mentor-dashboard');
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  currentRole === 'mentor'
                    ? 'bg-primary text-white'
                    : 'bg-muted text-muted-foreground hover:bg-muted/70'
                }`}
              >
                Mentor View
              </button>
              <button
                onClick={() => {
                  setCurrentRole('member');
                  setCurrentView('member-experience');
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  currentRole === 'member'
                    ? 'bg-primary text-white'
                    : 'bg-muted text-muted-foreground hover:bg-muted/70'
                }`}
              >
                Member View
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div>
        {currentView === 'mentor-dashboard' && <MentorDashboard />}
        {currentView === 'members-list' && <MembersList />}
        {currentView === 'member-experience' && <MemberExperience />}
        {currentView === 'affiliate' && <AffiliateRevenueDashboard />}
        {currentView === 'settings' && <CommunitySettings />}
      </div>
    </div>
  );
}