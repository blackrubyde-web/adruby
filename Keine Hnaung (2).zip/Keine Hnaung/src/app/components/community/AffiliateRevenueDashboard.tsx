import React, { useState } from 'react';
import { PageShell } from '../layout/PageShell';
import { HeroHeader } from '../layout/HeroHeader';
import { Card } from '../layout/Card';
import { Chip } from '../layout/Chip';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { 
  DollarSign,
  TrendingUp,
  Users,
  Calendar,
  Link2,
  Download,
  Copy,
  CheckCircle2,
  ArrowUp,
  Award,
  Target,
  Clock
} from 'lucide-react';
import type { AffiliateStats, PayoutHistory } from '../../types/community';

// Mock Data
const mockAffiliateStats: AffiliateStats = {
  mentorId: '1',
  period: {
    start: '2024-12-01',
    end: '2024-12-18'
  },
  metrics: {
    totalMembers: 47,
    activeMembers: 42,
    newMembersThisPeriod: 8,
    churnedMembers: 2,
    retentionRate: 89.4
  },
  revenue: {
    totalRevenue: 14100,
    revenueShare: 30,
    payoutAmount: 4230,
    currency: 'USD',
    nextPayoutDate: '2025-01-01'
  },
  performance: {
    conversionRate: 12.4,
    avgMemberLifetime: 247,
    avgMemberValue: 300
  },
  referrals: {
    totalClicks: 342,
    totalSignups: 64,
    conversionRate: 18.7
  }
};

const mockPayoutHistory: PayoutHistory[] = [
  {
    id: '1',
    date: '2024-12-01',
    amount: 4230,
    currency: 'USD',
    status: 'pending',
    members: 47,
    period: 'Nov 2024'
  },
  {
    id: '2',
    date: '2024-11-01',
    amount: 3780,
    currency: 'USD',
    status: 'completed',
    members: 42,
    period: 'Oct 2024'
  },
  {
    id: '3',
    date: '2024-10-01',
    amount: 3150,
    currency: 'USD',
    status: 'completed',
    members: 35,
    period: 'Sep 2024'
  },
  {
    id: '4',
    date: '2024-09-01',
    amount: 2520,
    currency: 'USD',
    status: 'completed',
    members: 28,
    period: 'Aug 2024'
  },
  {
    id: '5',
    date: '2024-08-01',
    amount: 1890,
    currency: 'USD',
    status: 'completed',
    members: 21,
    period: 'Jul 2024'
  }
];

const mockTiers = [
  { members: 50, share: 30, status: 'current' },
  { members: 100, share: 35, status: 'next' },
  { members: 250, share: 40, status: 'future' },
  { members: 500, share: 45, status: 'future' }
];

export function AffiliateRevenueDashboard() {
  const [affiliateCode] = useState('ALEXMORRISON_MASTERS');
  const [copied, setCopied] = useState(false);

  const formatCurrency = (value: number) => 
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0 }).format(value);

  const formatNumber = (value: number) => 
    new Intl.NumberFormat('en-US').format(value);

  const handleCopy = () => {
    navigator.clipboard.writeText(`https://adrubi.com/join/${affiliateCode}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-yellow-500/10 text-yellow-500">Pending</Badge>;
      case 'processing':
        return <Badge className="bg-blue-500/10 text-blue-500">Processing</Badge>;
      case 'completed':
        return <Badge className="bg-green-500/10 text-green-500">Completed</Badge>;
      case 'failed':
        return <Badge className="bg-red-500/10 text-red-500">Failed</Badge>;
      default:
        return null;
    }
  };

  const currentTier = mockTiers.find(t => t.status === 'current')!;
  const nextTier = mockTiers.find(t => t.status === 'next');

  return (
    <PageShell>
      {/* Hero Header */}
      <HeroHeader
        title="Affiliate & Revenue"
        subtitle="Track your community growth, earnings, and performance-based rewards"
        chips={
          <>
            <Chip icon={<Users className="w-3 h-3" />}>
              {mockAffiliateStats.metrics.totalMembers} Total Members
            </Chip>
            <Chip icon={<DollarSign className="w-3 h-3" />}>
              {mockAffiliateStats.revenue.revenueShare}% Revenue Share
            </Chip>
          </>
        }
        actions={
          <Button variant="accent" size="sm" icon={<Download className="w-4 h-4" />}>
            Export Report
          </Button>
        }
      />

      {/* Revenue Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Total Earnings */}
        <Card>
          <div className="p-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-2">
              <DollarSign className="w-4 h-4" />
              <span className="text-xs font-semibold uppercase tracking-wide">Total Earnings</span>
            </div>
            <div className="text-3xl font-bold text-foreground mb-1">
              {formatCurrency(mockAffiliateStats.revenue.totalRevenue)}
            </div>
            <div className="text-xs text-muted-foreground">This month</div>
          </div>
        </Card>

        {/* Next Payout */}
        <Card>
          <div className="p-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-2">
              <Calendar className="w-4 h-4" />
              <span className="text-xs font-semibold uppercase tracking-wide">Next Payout</span>
            </div>
            <div className="text-3xl font-bold text-primary mb-1">
              {formatCurrency(mockAffiliateStats.revenue.payoutAmount)}
            </div>
            <div className="text-xs text-muted-foreground">
              Due {new Date(mockAffiliateStats.revenue.nextPayoutDate).toLocaleDateString()}
            </div>
          </div>
        </Card>

        {/* Active Members */}
        <Card>
          <div className="p-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-2">
              <Users className="w-4 h-4" />
              <span className="text-xs font-semibold uppercase tracking-wide">Active Members</span>
            </div>
            <div className="text-3xl font-bold text-foreground mb-1">
              {mockAffiliateStats.metrics.activeMembers}
            </div>
            <div className="flex items-center gap-1 text-xs text-green-500 font-semibold">
              <ArrowUp className="w-3 h-3" />
              +{mockAffiliateStats.metrics.newMembersThisPeriod} this period
            </div>
          </div>
        </Card>

        {/* Avg Member Value */}
        <Card>
          <div className="p-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-2">
              <Target className="w-4 h-4" />
              <span className="text-xs font-semibold uppercase tracking-wide">Avg Member Value</span>
            </div>
            <div className="text-3xl font-bold text-foreground mb-1">
              {formatCurrency(mockAffiliateStats.performance.avgMemberValue)}
            </div>
            <div className="text-xs text-muted-foreground">Lifetime value</div>
          </div>
        </Card>
      </div>

      {/* Referral Link & Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Referral Link */}
        <Card>
          <div className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-primary/10">
                <Link2 className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">Your Referral Link</h2>
                <p className="text-sm text-muted-foreground">Share this with your community</p>
              </div>
            </div>

            <div className="p-4 rounded-lg bg-muted/30 border border-border/40 mb-4">
              <div className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wide">
                Affiliate Code
              </div>
              <div className="flex items-center gap-2">
                <code className="flex-1 text-sm font-mono text-foreground bg-background px-3 py-2 rounded border border-border">
                  https://adrubi.com/join/{affiliateCode}
                </code>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={handleCopy}
                  icon={copied ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                >
                  {copied ? 'Copied!' : 'Copy'}
                </Button>
              </div>
            </div>

            {/* Referral Stats */}
            <div className="grid grid-cols-3 gap-4">
              <div className="p-3 rounded-lg bg-muted/20 border border-border/40">
                <div className="text-xs text-muted-foreground mb-1">Clicks</div>
                <div className="text-xl font-bold text-foreground">
                  {formatNumber(mockAffiliateStats.referrals.totalClicks)}
                </div>
              </div>
              <div className="p-3 rounded-lg bg-muted/20 border border-border/40">
                <div className="text-xs text-muted-foreground mb-1">Sign-ups</div>
                <div className="text-xl font-bold text-foreground">
                  {formatNumber(mockAffiliateStats.referrals.totalSignups)}
                </div>
              </div>
              <div className="p-3 rounded-lg bg-muted/20 border border-border/40">
                <div className="text-xs text-muted-foreground mb-1">Conv Rate</div>
                <div className="text-xl font-bold text-green-500">
                  {mockAffiliateStats.referrals.conversionRate.toFixed(1)}%
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Tiered Rewards */}
        <Card>
          <div className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-yellow-500/10">
                <Award className="w-5 h-5 text-yellow-500" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">Tiered Rewards</h2>
                <p className="text-sm text-muted-foreground">Scale your revenue share as you grow</p>
              </div>
            </div>

            <div className="space-y-3">
              {mockTiers.map((tier, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border transition-all ${
                    tier.status === 'current'
                      ? 'bg-primary/5 border-primary/40'
                      : tier.status === 'next'
                      ? 'bg-blue-500/5 border-blue-500/20'
                      : 'bg-muted/20 border-border/40 opacity-60'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-foreground">
                        {tier.members}+ Members
                      </span>
                      {tier.status === 'current' && (
                        <Badge className="bg-primary/10 text-primary text-xs">Current</Badge>
                      )}
                      {tier.status === 'next' && (
                        <Badge className="bg-blue-500/10 text-blue-500 text-xs">Next Tier</Badge>
                      )}
                    </div>
                    <div className="text-xl font-bold text-foreground">
                      {tier.share}%
                    </div>
                  </div>
                  
                  {tier.status === 'next' && nextTier && (
                    <div className="mt-3">
                      <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                        <span>Progress to next tier</span>
                        <span>{mockAffiliateStats.metrics.totalMembers}/{tier.members}</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-primary transition-all"
                          style={{ width: `${(mockAffiliateStats.metrics.totalMembers / tier.members) * 100}%` }}
                        />
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {tier.members - mockAffiliateStats.metrics.totalMembers} members to unlock {tier.share}% share
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>

      {/* Performance Metrics */}
      <Card>
        <div className="p-6">
          <h2 className="text-lg font-semibold text-foreground mb-6">Performance Metrics</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Retention Rate */}
            <div className="p-4 rounded-lg bg-muted/30 border border-border/40">
              <div className="flex items-center gap-2 text-muted-foreground mb-3">
                <Clock className="w-4 h-4" />
                <span className="text-xs font-semibold uppercase tracking-wide">Retention Rate</span>
              </div>
              <div className="text-3xl font-bold text-foreground mb-2">
                {mockAffiliateStats.metrics.retentionRate.toFixed(1)}%
              </div>
              <div className="text-sm text-muted-foreground mb-3">
                {mockAffiliateStats.metrics.churnedMembers} churned this period
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div 
                  className="h-full bg-green-500 transition-all"
                  style={{ width: `${mockAffiliateStats.metrics.retentionRate}%` }}
                />
              </div>
            </div>

            {/* Avg Member Lifetime */}
            <div className="p-4 rounded-lg bg-muted/30 border border-border/40">
              <div className="flex items-center gap-2 text-muted-foreground mb-3">
                <Users className="w-4 h-4" />
                <span className="text-xs font-semibold uppercase tracking-wide">Avg Lifetime</span>
              </div>
              <div className="text-3xl font-bold text-foreground mb-2">
                {mockAffiliateStats.performance.avgMemberLifetime} days
              </div>
              <div className="text-sm text-muted-foreground">
                Strong engagement = longer lifetime
              </div>
            </div>

            {/* Conversion Rate */}
            <div className="p-4 rounded-lg bg-muted/30 border border-border/40">
              <div className="flex items-center gap-2 text-muted-foreground mb-3">
                <TrendingUp className="w-4 h-4" />
                <span className="text-xs font-semibold uppercase tracking-wide">Conversion Rate</span>
              </div>
              <div className="text-3xl font-bold text-foreground mb-2">
                {mockAffiliateStats.performance.conversionRate.toFixed(1)}%
              </div>
              <div className="text-sm text-muted-foreground">
                Click → Paid member rate
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Payout History */}
      <Card>
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-semibold text-foreground">Payout History</h2>
              <p className="text-sm text-muted-foreground">Your monthly earnings over time</p>
            </div>
            <Button variant="secondary" size="sm" icon={<Download className="w-4 h-4" />}>
              Download CSV
            </Button>
          </div>

          <div className="space-y-2">
            {mockPayoutHistory.map((payout) => (
              <div
                key={payout.id}
                className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border/40 hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className={`p-2 rounded-lg ${
                    payout.status === 'completed' ? 'bg-green-500/10' :
                    payout.status === 'pending' ? 'bg-yellow-500/10' :
                    'bg-muted'
                  }`}>
                    <DollarSign className={`w-5 h-5 ${
                      payout.status === 'completed' ? 'text-green-500' :
                      payout.status === 'pending' ? 'text-yellow-500' :
                      'text-muted-foreground'
                    }`} />
                  </div>
                  <div>
                    <div className="font-semibold text-foreground">{payout.period}</div>
                    <div className="text-xs text-muted-foreground">
                      {new Date(payout.date).toLocaleDateString()} • {payout.members} members
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  {getStatusBadge(payout.status)}
                  <div className="text-right">
                    <div className="font-bold text-foreground">
                      {formatCurrency(payout.amount)}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 p-4 rounded-lg bg-primary/5 border border-primary/20">
            <div className="flex items-start gap-3">
              <TrendingUp className="w-5 h-5 text-primary shrink-0 mt-0.5" />
              <div>
                <div className="font-semibold text-foreground mb-1">Growing Consistently</div>
                <p className="text-sm text-muted-foreground">
                  Your earnings have grown {((mockPayoutHistory[0].amount / mockPayoutHistory[4].amount - 1) * 100).toFixed(0)}% 
                  over the past 5 months. The better your community performs, the more everyone wins.
                </p>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </PageShell>
  );
}
