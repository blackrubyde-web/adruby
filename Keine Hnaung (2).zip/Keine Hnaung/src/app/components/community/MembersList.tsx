import React, { useState } from 'react';
import { PageShell } from '../layout/PageShell';
import { HeroHeader } from '../layout/HeroHeader';
import { Card } from '../layout/Card';
import { Chip } from '../layout/Chip';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { 
  Users,
  Search,
  ListFilter,
  Ellipsis,
  Mail,
  Activity,
  AlertTriangle,
  CheckCircle2,
  Clock,
  TrendingUp,
  TrendingDown,
  ArrowUpDown
} from 'lucide-react';
import type { MemberPerformance } from '../../types/community';

// Mock Data
const mockMembers: MemberPerformance[] = [
  {
    memberId: '1',
    memberName: 'Sarah Chen',
    avatarUrl: undefined,
    metrics: {
      spend: 8420,
      revenue: 31240,
      roas: 3.71,
      cpa: 28.50,
      impressions: 342000,
      clicks: 1820,
      conversions: 295
    },
    period: { start: '2024-12-01', end: '2024-12-18' },
    improvement: {
      roasChange: 127,
      cpaChange: -32,
      conversionChange: 89
    },
    riskStatus: 'healthy',
    lastActivity: '2024-12-18T14:30:00Z'
  },
  {
    memberId: '2',
    memberName: 'Marcus Johnson',
    metrics: {
      spend: 12350,
      revenue: 59525,
      roas: 4.82,
      cpa: 22.80,
      impressions: 520000,
      clicks: 2840,
      conversions: 542
    },
    period: { start: '2024-12-01', end: '2024-12-18' },
    improvement: {
      roasChange: 45,
      cpaChange: -18,
      conversionChange: 52
    },
    riskStatus: 'healthy',
    lastActivity: '2024-12-18T16:45:00Z'
  },
  {
    memberId: '3',
    memberName: 'Emma Rodriguez',
    metrics: {
      spend: 5240,
      revenue: 14230,
      roas: 2.71,
      cpa: 38.90,
      impressions: 210000,
      clicks: 980,
      conversions: 135
    },
    period: { start: '2024-12-01', end: '2024-12-18' },
    improvement: {
      roasChange: -12,
      cpaChange: 24,
      conversionChange: -8
    },
    riskStatus: 'warning',
    lastActivity: '2024-12-17T09:20:00Z'
  },
  {
    memberId: '4',
    memberName: 'David Kim',
    metrics: {
      spend: 9850,
      revenue: 41475,
      roas: 4.21,
      cpa: 24.70,
      impressions: 410000,
      clicks: 2150,
      conversions: 399
    },
    period: { start: '2024-12-01', end: '2024-12-18' },
    improvement: {
      roasChange: 38,
      cpaChange: -22,
      conversionChange: 41
    },
    riskStatus: 'healthy',
    lastActivity: '2024-12-18T11:15:00Z'
  },
  {
    memberId: '5',
    memberName: 'Lisa Patel',
    metrics: {
      spend: 3120,
      revenue: 6552,
      roas: 2.10,
      cpa: 45.20,
      impressions: 145000,
      clicks: 620,
      conversions: 69
    },
    period: { start: '2024-12-01', end: '2024-12-18' },
    improvement: {
      roasChange: -28,
      cpaChange: 42,
      conversionChange: -18
    },
    riskStatus: 'critical',
    lastActivity: '2024-12-15T18:40:00Z'
  },
  {
    memberId: '6',
    memberName: 'James Wilson',
    metrics: {
      spend: 7680,
      revenue: 26912,
      roas: 3.50,
      cpa: 31.20,
      impressions: 320000,
      clicks: 1640,
      conversions: 246
    },
    period: { start: '2024-12-01', end: '2024-12-18' },
    improvement: {
      roasChange: 62,
      cpaChange: -15,
      conversionChange: 58
    },
    riskStatus: 'healthy',
    lastActivity: '2024-12-18T13:55:00Z'
  },
  {
    memberId: '7',
    memberName: 'Sofia Martinez',
    metrics: {
      spend: 4580,
      revenue: 10674,
      roas: 2.33,
      cpa: 42.10,
      impressions: 190000,
      clicks: 840,
      conversions: 109
    },
    period: { start: '2024-12-01', end: '2024-12-18' },
    improvement: {
      roasChange: -8,
      cpaChange: 18,
      conversionChange: 2
    },
    riskStatus: 'warning',
    lastActivity: '2024-12-18T10:30:00Z'
  }
];

type SortField = 'name' | 'roas' | 'cpa' | 'spend' | 'improvement';
type SortDirection = 'asc' | 'desc';

export function MembersList() {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'healthy' | 'warning' | 'critical'>('all');
  const [sortField, setSortField] = useState<SortField>('roas');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

  const formatCurrency = (value: number) => 
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0 }).format(value);

  const formatNumber = (value: number) => 
    new Intl.NumberFormat('en-US').format(value);

  const getTimeSince = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
  };

  const getRiskBadge = (status: string) => {
    switch (status) {
      case 'healthy':
        return <Badge className="bg-green-500/10 text-green-500 text-xs">Healthy</Badge>;
      case 'warning':
        return <Badge className="bg-yellow-500/10 text-yellow-500 text-xs">Needs Attention</Badge>;
      case 'critical':
        return <Badge className="bg-red-500/10 text-red-500 text-xs">Critical</Badge>;
      default:
        return null;
    }
  };

  const getRiskIcon = (status: string) => {
    switch (status) {
      case 'healthy':
        return <CheckCircle2 className="w-4 h-4 text-green-500" />;
      case 'warning':
        return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      case 'critical':
        return <AlertTriangle className="w-4 h-4 text-red-500" />;
      default:
        return <Activity className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  // Filter and sort members
  const filteredMembers = mockMembers
    .filter(member => {
      const matchesSearch = member.memberName.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === 'all' || member.riskStatus === statusFilter;
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      let aValue: number, bValue: number;
      
      switch (sortField) {
        case 'name':
          return sortDirection === 'asc' 
            ? a.memberName.localeCompare(b.memberName)
            : b.memberName.localeCompare(a.memberName);
        case 'roas':
          aValue = a.metrics.roas;
          bValue = b.metrics.roas;
          break;
        case 'cpa':
          aValue = a.metrics.cpa;
          bValue = b.metrics.cpa;
          break;
        case 'spend':
          aValue = a.metrics.spend;
          bValue = b.metrics.spend;
          break;
        case 'improvement':
          aValue = a.improvement.roasChange;
          bValue = b.improvement.roasChange;
          break;
        default:
          return 0;
      }
      
      return sortDirection === 'asc' ? aValue - bValue : bValue - aValue;
    });

  const healthyCount = mockMembers.filter(m => m.riskStatus === 'healthy').length;
  const warningCount = mockMembers.filter(m => m.riskStatus === 'warning').length;
  const criticalCount = mockMembers.filter(m => m.riskStatus === 'critical').length;

  return (
    <PageShell>
      {/* Hero Header */}
      <HeroHeader
        title="Members Overview"
        subtitle="Monitor, manage, and support all community members from one place"
        chips={
          <>
            <Chip icon={<Users className="w-3 h-3" />}>
              {mockMembers.length} Total Members
            </Chip>
            <Chip icon={<CheckCircle2 className="w-3 h-3 text-green-500" />}>
              {healthyCount} Healthy
            </Chip>
            {warningCount > 0 && (
              <Chip icon={<AlertTriangle className="w-3 h-3 text-yellow-500" />}>
                {warningCount} Need Attention
              </Chip>
            )}
            {criticalCount > 0 && (
              <Chip icon={<AlertTriangle className="w-3 h-3 text-red-500" />}>
                {criticalCount} Critical
              </Chip>
            )}
          </>
        }
      />

      {/* Filters & Search */}
      <Card>
        <div className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search members..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Status Filter */}
            <div className="flex gap-2">
              {(['all', 'healthy', 'warning', 'critical'] as const).map(status => (
                <button
                  key={status}
                  onClick={() => setStatusFilter(status)}
                  className={`px-3 py-2 rounded-lg text-xs font-semibold transition-colors capitalize ${
                    statusFilter === status
                      ? 'bg-foreground text-background'
                      : 'bg-muted text-muted-foreground hover:bg-muted/70'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>
          </div>
        </div>
      </Card>

      {/* Members Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left p-4">
                  <button
                    onClick={() => handleSort('name')}
                    className="flex items-center gap-2 text-xs font-semibold text-muted-foreground uppercase tracking-wide hover:text-foreground transition-colors"
                  >
                    Member
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="text-left p-4">
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                    Status
                  </span>
                </th>
                <th className="text-right p-4">
                  <button
                    onClick={() => handleSort('spend')}
                    className="flex items-center gap-2 ml-auto text-xs font-semibold text-muted-foreground uppercase tracking-wide hover:text-foreground transition-colors"
                  >
                    Spend
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="text-right p-4">
                  <button
                    onClick={() => handleSort('roas')}
                    className="flex items-center gap-2 ml-auto text-xs font-semibold text-muted-foreground uppercase tracking-wide hover:text-foreground transition-colors"
                  >
                    ROAS
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="text-right p-4">
                  <button
                    onClick={() => handleSort('cpa')}
                    className="flex items-center gap-2 ml-auto text-xs font-semibold text-muted-foreground uppercase tracking-wide hover:text-foreground transition-colors"
                  >
                    CPA
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="text-right p-4">
                  <button
                    onClick={() => handleSort('improvement')}
                    className="flex items-center gap-2 ml-auto text-xs font-semibold text-muted-foreground uppercase tracking-wide hover:text-foreground transition-colors"
                  >
                    Improvement
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="text-left p-4">
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                    Last Active
                  </span>
                </th>
                <th className="text-right p-4">
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                    Actions
                  </span>
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredMembers.map((member) => (
                <tr 
                  key={member.memberId}
                  className="border-b border-border hover:bg-muted/30 transition-colors"
                >
                  {/* Member Info */}
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white font-semibold text-sm">
                        {member.memberName.charAt(0)}
                      </div>
                      <div>
                        <div className="font-semibold text-foreground">{member.memberName}</div>
                        <div className="text-xs text-muted-foreground">
                          {formatNumber(member.metrics.conversions)} conversions
                        </div>
                      </div>
                    </div>
                  </td>

                  {/* Status */}
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      {getRiskIcon(member.riskStatus)}
                      {getRiskBadge(member.riskStatus)}
                    </div>
                  </td>

                  {/* Spend */}
                  <td className="p-4 text-right">
                    <div className="font-semibold text-foreground">
                      {formatCurrency(member.metrics.spend)}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {formatNumber(member.metrics.impressions)} imp
                    </div>
                  </td>

                  {/* ROAS */}
                  <td className="p-4 text-right">
                    <div className="font-semibold text-foreground">
                      {member.metrics.roas.toFixed(2)}x
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {formatCurrency(member.metrics.revenue)}
                    </div>
                  </td>

                  {/* CPA */}
                  <td className="p-4 text-right">
                    <div className="font-semibold text-foreground">
                      {formatCurrency(member.metrics.cpa)}
                    </div>
                    <div className={`flex items-center justify-end gap-1 text-xs font-semibold ${
                      member.improvement.cpaChange < 0 ? 'text-green-500' : 'text-red-500'
                    }`}>
                      {member.improvement.cpaChange < 0 ? (
                        <TrendingDown className="w-3 h-3" />
                      ) : (
                        <TrendingUp className="w-3 h-3" />
                      )}
                      {Math.abs(member.improvement.cpaChange)}%
                    </div>
                  </td>

                  {/* Improvement */}
                  <td className="p-4 text-right">
                    <div className={`flex items-center justify-end gap-1 font-semibold ${
                      member.improvement.roasChange > 0 ? 'text-green-500' : 'text-red-500'
                    }`}>
                      {member.improvement.roasChange > 0 ? (
                        <TrendingUp className="w-4 h-4" />
                      ) : (
                        <TrendingDown className="w-4 h-4" />
                      )}
                      {member.improvement.roasChange > 0 ? '+' : ''}{member.improvement.roasChange}%
                    </div>
                  </td>

                  {/* Last Active */}
                  <td className="p-4">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      {getTimeSince(member.lastActivity)}
                    </div>
                  </td>

                  {/* Actions */}
                  <td className="p-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button variant="ghost" size="sm" icon={<Mail className="w-3 h-3" />}>
                        Message
                      </Button>
                      <Button variant="ghost" size="sm" icon={<Ellipsis className="w-4 h-4" />} />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredMembers.length === 0 && (
          <div className="p-12 text-center">
            <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <div className="font-semibold text-foreground mb-1">No members found</div>
            <div className="text-sm text-muted-foreground">
              Try adjusting your search or filter
            </div>
          </div>
        )}
      </Card>
    </PageShell>
  );
}
