import React from 'react';
import { TrendingUp, TrendingDown, Activity } from 'lucide-react';

export type CampaignStatus = 'scaling' | 'stable' | 'at-risk' | 'fatigued';

interface MetricProps {
  label: string;
  value: string;
  change: number;
  isPositive: boolean;
}

function Metric({ label, value, change, isPositive }: MetricProps) {
  return (
    <div className="p-3 bg-muted/30 rounded-lg border border-border/40">
      <div className="text-xs text-muted-foreground mb-1 font-medium">
        {label}
      </div>
      <div className="flex items-baseline justify-between">
        <span className="text-lg font-bold text-foreground">{value}</span>
        <span className={`text-xs font-semibold flex items-center gap-0.5 ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
          {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
          {Math.abs(change)}%
        </span>
      </div>
    </div>
  );
}

interface CampaignHealthCardProps {
  campaignName: string;
  status: CampaignStatus;
  metrics: {
    ctr: { value: string; change: number };
    cpa: { value: string; change: number };
    roas: { value: string; change: number };
    spend: { value: string; change: number };
  };
}

export function CampaignHealthCard({ campaignName, status, metrics }: CampaignHealthCardProps) {
  const statusConfig = {
    scaling: {
      label: 'Scaling',
      color: 'text-green-600',
      bgColor: 'bg-green-500/10',
      borderColor: 'border-green-500/20'
    },
    stable: {
      label: 'Stable',
      color: 'text-blue-600',
      bgColor: 'bg-blue-500/10',
      borderColor: 'border-blue-500/20'
    },
    'at-risk': {
      label: 'At Risk',
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-500/10',
      borderColor: 'border-yellow-500/20'
    },
    fatigued: {
      label: 'Fatigued',
      color: 'text-red-600',
      bgColor: 'bg-red-500/10',
      borderColor: 'border-red-500/20'
    }
  };

  const config = statusConfig[status];

  return (
    <div className="bg-card border border-border rounded-xl p-6">
      {/* Header */}
      <div className="mb-5">
        <div className="flex items-center gap-2 mb-3">
          <Activity className="w-5 h-5 text-muted-foreground" />
          <h3 className="font-bold text-foreground">Campaign Health</h3>
        </div>
        <div className="text-sm text-muted-foreground mb-3">{campaignName}</div>
        <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border ${config.bgColor} ${config.borderColor}`}>
          <div className={`w-2 h-2 rounded-full ${config.color.replace('text-', 'bg-')}`} />
          <span className={`text-sm font-semibold ${config.color}`}>
            {config.label}
          </span>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="space-y-2.5">
        <Metric 
          label="CTR" 
          value={metrics.ctr.value} 
          change={metrics.ctr.change}
          isPositive={metrics.ctr.change > 0}
        />
        <Metric 
          label="CPA" 
          value={metrics.cpa.value} 
          change={metrics.cpa.change}
          isPositive={metrics.cpa.change < 0} // Lower is better for CPA
        />
        <Metric 
          label="ROAS" 
          value={metrics.roas.value} 
          change={metrics.roas.change}
          isPositive={metrics.roas.change > 0}
        />
        <Metric 
          label="Spend" 
          value={metrics.spend.value} 
          change={metrics.spend.change}
          isPositive={metrics.spend.change > 0}
        />
      </div>

      {/* Fatigue Warning */}
      {status === 'fatigued' && (
        <div className="mt-4 p-3 bg-red-500/5 border border-red-500/10 rounded-lg">
          <div className="text-xs font-semibold text-red-600 mb-1">
            ⚠️ CREATIVE FATIGUE DETECTED
          </div>
          <p className="text-xs text-muted-foreground">
            Performance declining for 3+ days. New creatives needed.
          </p>
        </div>
      )}
    </div>
  );
}
