import React from 'react';
import { AlertCircle, AlertTriangle, Info } from 'lucide-react';

export type SeverityLevel = 'low' | 'medium' | 'high' | 'critical';

interface SeverityBadgeProps {
  level: SeverityLevel;
  className?: string;
}

export function SeverityBadge({ level, className = '' }: SeverityBadgeProps) {
  const config = {
    low: {
      label: 'Low',
      bgColor: 'bg-blue-500/10',
      textColor: 'text-blue-600',
      borderColor: 'border-blue-500/20',
      icon: Info
    },
    medium: {
      label: 'Medium',
      bgColor: 'bg-yellow-500/10',
      textColor: 'text-yellow-600',
      borderColor: 'border-yellow-500/20',
      icon: AlertCircle
    },
    high: {
      label: 'High',
      bgColor: 'bg-orange-500/10',
      textColor: 'text-orange-600',
      borderColor: 'border-orange-500/20',
      icon: AlertTriangle
    },
    critical: {
      label: 'Critical',
      bgColor: 'bg-primary/10',
      textColor: 'text-primary',
      borderColor: 'border-primary/20',
      icon: AlertTriangle
    }
  };

  const { label, bgColor, textColor, borderColor, icon: Icon } = config[level];

  return (
    <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border ${bgColor} ${borderColor} ${className}`}>
      <Icon className={`w-3.5 h-3.5 ${textColor}`} />
      <span className={`text-xs font-semibold uppercase tracking-wide ${textColor}`}>
        {label}
      </span>
    </div>
  );
}
