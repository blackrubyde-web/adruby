import React from 'react';
import { ArrowRight, TrendingDown, TrendingUp } from 'lucide-react';

export type ConfidenceLevel = 'low' | 'medium' | 'high';
export type ImpactLevel = 'low' | 'medium' | 'high';

interface DecisionCardProps {
  priority: number; // 1, 2, 3...
  decision: string; // The decision to make, not the problem
  why: string; // Why this matters (business impact)
  impact: ImpactLevel;
  confidence: ConfidenceLevel;
  estimatedChange: {
    metric: 'CPA' | 'CTR' | 'ROAS' | 'Revenue';
    value: string;
    direction: 'increase' | 'decrease';
  };
  actionLabel: string;
  onExecute: () => void;
  isPrimary?: boolean; // Hero card styling
}

export function DecisionCard({
  priority,
  decision,
  why,
  impact,
  confidence,
  estimatedChange,
  actionLabel,
  onExecute,
  isPrimary = false
}: DecisionCardProps) {
  const confidenceConfig = {
    low: { label: 'Low Confidence', color: 'text-yellow-600', bg: 'bg-yellow-500/10', border: 'border-yellow-500/20' },
    medium: { label: 'Medium Confidence', color: 'text-blue-600', bg: 'bg-blue-500/10', border: 'border-blue-500/20' },
    high: { label: 'High Confidence', color: 'text-green-600', bg: 'bg-green-500/10', border: 'border-green-500/20' }
  };

  const impactConfig = {
    low: { label: 'Low Impact', color: 'text-gray-600' },
    medium: { label: 'Medium Impact', color: 'text-blue-600' },
    high: { label: 'High Impact', color: 'text-primary' }
  };

  const conf = confidenceConfig[confidence];
  const imp = impactConfig[impact];

  const changeColor = 
    estimatedChange.metric === 'CPA' 
      ? estimatedChange.direction === 'decrease' ? 'text-green-600' : 'text-red-600'
      : estimatedChange.metric === 'ROAS' || estimatedChange.metric === 'Revenue'
      ? estimatedChange.direction === 'increase' ? 'text-green-600' : 'text-red-600'
      : estimatedChange.direction === 'increase' ? 'text-green-600' : 'text-red-600';

  const ChangeIcon = estimatedChange.direction === 'increase' ? TrendingUp : TrendingDown;

  if (isPrimary) {
    // HERO CARD - Top Priority
    return (
      <div className="bg-gradient-to-br from-primary/5 to-blue-500/5 border-2 border-primary/30 rounded-2xl p-8 shadow-lg">
        {/* Priority Badge */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-lg">#{priority}</span>
            </div>
            <div>
              <div className="text-xs font-semibold text-primary uppercase tracking-wide">
                Top Priority
              </div>
              <div className={`text-xs font-semibold ${imp.color}`}>
                {imp.label}
              </div>
            </div>
          </div>
          <div className={`px-3 py-1.5 rounded-lg border ${conf.bg} ${conf.border}`}>
            <span className={`text-xs font-bold ${conf.color}`}>
              {conf.label.replace(' Confidence', '')}
            </span>
          </div>
        </div>

        {/* Decision (not problem) */}
        <h2 className="text-2xl font-bold text-foreground mb-4 leading-tight">
          {decision}
        </h2>

        {/* Why this matters */}
        <div className="mb-6 p-4 bg-white/60 rounded-xl border border-border/40">
          <div className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wide">
            Why This Matters
          </div>
          <p className="text-sm text-foreground leading-relaxed">
            {why}
          </p>
        </div>

        {/* Expected Outcome */}
        <div className="mb-8 flex items-center gap-3 p-4 bg-white/80 rounded-xl border border-border">
          <ChangeIcon className={`w-6 h-6 ${changeColor}`} />
          <div>
            <div className="text-xs text-muted-foreground mb-0.5">Expected Impact</div>
            <div className={`text-xl font-bold ${changeColor}`}>
              {estimatedChange.value} {estimatedChange.metric}
            </div>
          </div>
        </div>

        {/* Primary Action */}
        <button
          onClick={onExecute}
          className="w-full px-6 py-4 bg-primary text-white rounded-xl font-bold text-base hover:bg-primary/90 transition-all shadow-md hover:shadow-xl flex items-center justify-center gap-2 group"
        >
          {actionLabel}
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    );
  }

  // SECONDARY CARDS - Remaining priorities
  return (
    <div className="bg-card border border-border rounded-xl p-5 hover:border-border/60 transition-all group">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-start gap-3 flex-1">
          <div className="w-7 h-7 bg-muted rounded-full flex items-center justify-center flex-shrink-0">
            <span className="text-foreground font-bold text-sm">#{priority}</span>
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-foreground mb-1 leading-tight">
              {decision}
            </h3>
            <p className="text-xs text-muted-foreground leading-relaxed">
              {why}
            </p>
          </div>
        </div>
      </div>

      {/* Metadata */}
      <div className="flex items-center gap-2 mb-4">
        <div className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${conf.bg} ${conf.color}`}>
          {conf.label.replace(' Confidence', '')}
        </div>
        <div className={`px-2 py-1 rounded text-[10px] font-bold ${imp.color}`}>
          {imp.label.replace(' Impact', '')}
        </div>
        <div className={`text-sm font-bold ${changeColor} ml-auto`}>
          {estimatedChange.value} {estimatedChange.metric}
        </div>
      </div>

      {/* Action */}
      <button
        onClick={onExecute}
        className="w-full px-4 py-2.5 bg-foreground text-background rounded-lg font-semibold text-sm hover:bg-foreground/90 transition-all opacity-0 group-hover:opacity-100"
      >
        {actionLabel} →
      </button>
    </div>
  );
}