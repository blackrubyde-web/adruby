import React from 'react';
import { Brain, ArrowRight } from 'lucide-react';

interface ProactiveLearningCardProps {
  learnings: string[];
  onViewAll?: () => void;
}

export function ProactiveLearningCard({ learnings, onViewAll }: ProactiveLearningCardProps) {
  if (learnings.length === 0) return null;

  return (
    <div className="bg-gradient-to-br from-purple-500/5 to-blue-500/5 border border-purple-500/20 rounded-xl p-5">
      {/* Header */}
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-blue-600 rounded-full flex items-center justify-center">
          <Brain className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1">
          <h3 className="font-bold text-foreground text-sm">Account Learning History</h3>
          <p className="text-xs text-muted-foreground">Insights from past tests</p>
        </div>
      </div>

      {/* Learnings */}
      <div className="space-y-3 mb-4">
        {learnings.slice(0, 3).map((learning, i) => (
          <div key={i} className="flex items-start gap-3 p-3 bg-white/60 rounded-lg">
            <div className="w-6 h-6 bg-purple-600 text-white rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold">
              {i + 1}
            </div>
            <p className="text-xs text-foreground leading-relaxed flex-1">
              {learning}
            </p>
          </div>
        ))}
      </div>

      {/* View All */}
      {learnings.length > 3 && (
        <button
          onClick={onViewAll}
          className="w-full px-4 py-2.5 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg font-semibold text-xs hover:opacity-90 transition-all flex items-center justify-center gap-2"
        >
          View All {learnings.length} Learnings
          <ArrowRight className="w-3 h-3" />
        </button>
      )}
    </div>
  );
}