import React from 'react';
import { Sparkles, RefreshCw, TrendingUp, Target, ImagePlus, Zap } from 'lucide-react';

export interface ActionItem {
  id: string;
  title: string;
  description: string;
  type: 'generate' | 'test' | 'refresh' | 'scale' | 'change';
  icon?: React.ReactNode;
  estimatedImpact: string;
  confidence: 'low' | 'medium' | 'high';
  onExecute: () => void;
}

interface ActionEngineProps {
  actions: ActionItem[];
}

export function ActionEngine({ actions }: ActionEngineProps) {
  const getActionIcon = (type: ActionItem['type']) => {
    switch (type) {
      case 'generate':
        return <Sparkles className="w-4 h-4" />;
      case 'test':
        return <Target className="w-4 h-4" />;
      case 'refresh':
        return <RefreshCw className="w-4 h-4" />;
      case 'scale':
        return <TrendingUp className="w-4 h-4" />;
      case 'change':
        return <ImagePlus className="w-4 h-4" />;
      default:
        return <Zap className="w-4 h-4" />;
    }
  };

  const getConfidenceBadge = (confidence: ActionItem['confidence']) => {
    const config = {
      low: { label: 'Low Confidence', color: 'text-yellow-600', bg: 'bg-yellow-500/10' },
      medium: { label: 'Medium Confidence', color: 'text-blue-600', bg: 'bg-blue-500/10' },
      high: { label: 'High Confidence', color: 'text-green-600', bg: 'bg-green-500/10' }
    };
    const c = config[confidence];
    return (
      <span className={`text-[10px] font-semibold uppercase tracking-wide ${c.color} ${c.bg} px-2 py-0.5 rounded`}>
        {c.label}
      </span>
    );
  };

  return (
    <div className="bg-card border border-border rounded-xl p-6">
      {/* Header */}
      <div className="mb-5">
        <div className="flex items-center gap-2 mb-2">
          <Zap className="w-5 h-5 text-primary" />
          <h3 className="font-bold text-foreground">Action Engine</h3>
        </div>
        <p className="text-sm text-muted-foreground">
          AI-recommended fixes ranked by impact
        </p>
      </div>

      {/* Actions List */}
      <div className="space-y-3">
        {actions.map((action) => (
          <div
            key={action.id}
            className="border border-border rounded-lg p-4 hover:border-primary/40 transition-all group bg-background"
          >
            {/* Action Header */}
            <div className="flex items-start gap-3 mb-3">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary flex-shrink-0">
                {action.icon || getActionIcon(action.type)}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-semibold text-foreground text-sm mb-1 leading-tight">
                  {action.title}
                </h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {action.description}
                </p>
              </div>
            </div>

            {/* Metadata */}
            <div className="flex items-center justify-between mb-3">
              <div className="text-xs text-muted-foreground">
                Impact: <span className="font-semibold text-foreground">{action.estimatedImpact}</span>
              </div>
              {getConfidenceBadge(action.confidence)}
            </div>

            {/* Execute Button */}
            <button
              onClick={action.onExecute}
              className="w-full px-4 py-2 bg-foreground text-background rounded-lg font-semibold text-sm hover:bg-foreground/90 transition-all group-hover:shadow-md"
            >
              Execute Now →
            </button>
          </div>
        ))}
      </div>

      {/* Batch Execute */}
      {actions.length > 1 && (
        <div className="mt-4 pt-4 border-t border-border">
          <button className="w-full px-4 py-2.5 bg-primary text-white rounded-lg font-semibold text-sm hover:bg-primary/90 transition-all">
            Execute All High-Confidence Actions ({actions.filter(a => a.confidence === 'high').length})
          </button>
        </div>
      )}
    </div>
  );
}
