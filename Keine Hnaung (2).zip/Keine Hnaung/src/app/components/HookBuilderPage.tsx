import React, { useState } from 'react';
import { SimplifiedHookBuilder } from './SimplifiedHookBuilder';

export function HookBuilderPage() {
  return <SimplifiedHookBuilder />;
}