import React from 'react';
import { Brain, Zap, Target, Database, TrendingUp, Shield } from 'lucide-react';

export function WhyAdRuby() {
  const principles = [
    {
      icon: Brain,
      title: 'Decision Engine, Not Ad Generator',
      description: 'We don\'t create random variations. We tell you exactly what to change and why it will work for your specific account.'
    },
    {
      icon: Target,
      title: 'Hypothesis-Driven Testing',
      description: 'Every variant tests a specific hypothesis based on your performance patterns. No guessing. No waste.'
    },
    {
      icon: Database,
      title: 'Learning Memory System',
      description: 'AdRuby remembers what worked and what didn\'t. Each test makes the system smarter for your account.'
    },
    {
      icon: TrendingUp,
      title: 'Built For Scale',
      description: 'Multi-account management, shared learnings, and template inheritance. This is professional-grade infrastructure.'
    },
    {
      icon: Zap,
      title: 'Speed Through Precision',
      description: '3-5 targeted variants beat 100 random ones. Less testing time, faster iteration, better results.'
    },
    {
      icon: Shield,
      title: 'Agency-First Design',
      description: 'Portfolio view, cross-account insights, and client management built in. Scale with confidence.'
    }
  ];

  return (
    <div className="bg-gradient-to-br from-blue-500/5 to-purple-500/5 border border-blue-500/10 rounded-2xl p-8">
      {/* Header */}
      <div className="text-center mb-12">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-2xl mb-4">
          <Brain className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-3xl font-bold text-foreground mb-3">
          Why AdRuby Exists
        </h2>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          We built the tool senior media buyers wished existed — 
          a decision engine that thinks like you do, scales like you need it to, 
          and gets smarter with every test.
        </p>
      </div>

      {/* Principles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {principles.map((principle, index) => {
          const Icon = principle.icon;
          return (
            <div
              key={index}
              className="bg-card border border-border rounded-xl p-6 hover:shadow-lg hover:-translate-y-0.5 transition-all"
            >
              <div className="w-12 h-12 bg-primary/10 border border-primary/20 rounded-xl flex items-center justify-center mb-4">
                <Icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-bold text-foreground mb-2">
                {principle.title}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {principle.description}
              </p>
            </div>
          );
        })}
      </div>

      {/* Bottom Statement */}
      <div className="text-center pt-8 border-t border-border">
        <p className="text-sm text-foreground font-semibold max-w-3xl mx-auto">
          AdRuby is not for beginners who want AI to do everything. 
          It's for professionals who want AI to help them make better decisions, faster.
        </p>
      </div>
    </div>
  );
}
