import React from 'react';
import { Check, X } from 'lucide-react';

export function MarketComparison() {
  const features = [
    {
      feature: 'Approach',
      others: 'Generate random variations',
      adruby: 'Hypothesis-driven iteration'
    },
    {
      feature: 'Learning',
      others: 'Generic best practices',
      adruby: 'Account-specific patterns'
    },
    {
      feature: 'Output',
      others: '100+ variations to test',
      adruby: '3-5 variants with clear purpose'
    },
    {
      feature: 'Guidance',
      others: 'No context on why it works',
      adruby: 'Testing context for each variant'
    },
    {
      feature: 'Decision Support',
      others: 'You figure it out',
      adruby: 'Prioritized action list'
    }
  ];

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      {/* Header */}
      <div className="p-5 border-b border-border bg-muted/20">
        <h3 className="font-bold text-foreground mb-1">
          How AdRuby Is Different
        </h3>
        <p className="text-sm text-muted-foreground">
          We don't generate ads. We help you make better decisions.
        </p>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border bg-muted/10">
              <th className="px-4 py-3 text-left text-xs font-bold text-muted-foreground uppercase tracking-wide">
                Capability
              </th>
              <th className="px-4 py-3 text-left text-xs font-bold text-muted-foreground uppercase tracking-wide">
                Other Tools
              </th>
              <th className="px-4 py-3 text-left text-xs font-bold text-primary uppercase tracking-wide">
                AdRuby
              </th>
            </tr>
          </thead>
          <tbody>
            {features.map((item, index) => (
              <tr
                key={index}
                className={`border-b border-border ${
                  index % 2 === 0 ? 'bg-muted/5' : ''
                }`}
              >
                <td className="px-4 py-3 text-sm font-semibold text-foreground">
                  {item.feature}
                </td>
                <td className="px-4 py-3 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <X className="w-4 h-4 text-red-600 flex-shrink-0" />
                    <span>{item.others}</span>
                  </div>
                </td>
                <td className="px-4 py-3 text-sm text-foreground">
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600 flex-shrink-0" />
                    <span className="font-semibold">{item.adruby}</span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Footer */}
      <div className="p-4 bg-blue-500/5 border-t border-blue-500/10">
        <p className="text-xs text-center text-foreground font-semibold">
          AdRuby is a decision engine for media buyers, not an ad generator for beginners.
        </p>
      </div>
    </div>
  );
}
