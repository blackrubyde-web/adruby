import React from 'react';
import { Brain, Sparkles, X } from 'lucide-react';

interface PhilosophyStatementProps {
  context: 'creative-builder' | 'ai-analysis' | 'learning';
}

export function PhilosophyStatement({ context }: PhilosophyStatementProps) {
  const configs = {
    'creative-builder': {
      wrong: {
        icon: Sparkles,
        title: 'Random Ad Generator',
        description: 'Generate 100 variations and hope one works',
        color: 'text-gray-400'
      },
      right: {
        icon: Brain,
        title: 'Hypothesis-Driven Iteration',
        description: 'Each variant tests a specific hypothesis based on your account history',
        color: 'text-primary'
      }
    },
    'ai-analysis': {
      wrong: {
        icon: Sparkles,
        title: 'Generic Recommendations',
        description: 'AI suggests best practices from the internet',
        color: 'text-gray-400'
      },
      right: {
        icon: Brain,
        title: 'Decision Engine',
        description: 'Prioritized actions based on your specific performance patterns',
        color: 'text-primary'
      }
    },
    'learning': {
      wrong: {
        icon: Sparkles,
        title: 'Template Library',
        description: 'Copy what worked for someone else',
        color: 'text-gray-400'
      },
      right: {
        icon: Brain,
        title: 'Learning Memory',
        description: 'System learns what works specifically for your accounts',
        color: 'text-primary'
      }
    }
  };

  const config = configs[context];

  return (
    <div className="bg-gradient-to-br from-blue-500/5 to-purple-500/5 border border-blue-500/10 rounded-xl p-6">
      {/* Header */}
      <div className="text-center mb-6">
        <div className="text-xs font-bold uppercase tracking-wide text-muted-foreground mb-2">
          Why AdRuby Exists
        </div>
        <h3 className="font-bold text-foreground">
          Built for media buyers who scale with precision, not volume
        </h3>
      </div>

      {/* Comparison */}
      <div className="grid grid-cols-2 gap-4">
        {/* Wrong Approach */}
        <div className="bg-card/50 border border-border/50 rounded-lg p-4 relative">
          {/* X Badge */}
          <div className="absolute -top-2 -right-2 w-6 h-6 bg-red-600 rounded-full flex items-center justify-center">
            <X className="w-3 h-3 text-white" />
          </div>

          <div className="flex items-center gap-2 mb-3">
            <config.wrong.icon className={`w-4 h-4 ${config.wrong.color}`} />
            <div className="text-sm font-semibold text-gray-400">
              {config.wrong.title}
            </div>
          </div>
          <p className="text-xs text-gray-400 leading-relaxed line-through">
            {config.wrong.description}
          </p>
        </div>

        {/* Right Approach */}
        <div className="bg-primary/5 border border-primary/20 rounded-lg p-4 relative">
          {/* Check Badge */}
          <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-600 rounded-full flex items-center justify-center">
            <div className="text-white text-xs font-bold">✓</div>
          </div>

          <div className="flex items-center gap-2 mb-3">
            <config.right.icon className={`w-4 h-4 ${config.right.color}`} />
            <div className="text-sm font-semibold text-foreground">
              {config.right.title}
            </div>
          </div>
          <p className="text-xs text-foreground leading-relaxed font-medium">
            {config.right.description}
          </p>
        </div>
      </div>

      {/* Footer */}
      <div className="mt-4 pt-4 border-t border-border/50">
        <p className="text-xs text-center text-muted-foreground">
          AdRuby doesn't create ads. AdRuby tells you what to change to scale.
        </p>
      </div>
    </div>
  );
}
