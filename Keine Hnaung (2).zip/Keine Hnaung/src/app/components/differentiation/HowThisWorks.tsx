import React from 'react';
import { Lightbulb } from 'lucide-react';

interface HowThisWorksProps {
  title: string;
  steps: {
    label: string;
    description: string;
  }[];
  insight?: string;
}

export function HowThisWorks({ title, steps, insight }: HowThisWorksProps) {
  return (
    <div className="bg-blue-500/5 border border-blue-500/10 rounded-xl p-5">
      {/* Header */}
      <div className="flex items-center gap-2 mb-4">
        <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
          <Lightbulb className="w-4 h-4 text-white" />
        </div>
        <h4 className="font-bold text-foreground text-sm">{title}</h4>
      </div>

      {/* Steps */}
      <div className="space-y-3 mb-4">
        {steps.map((step, index) => (
          <div key={index} className="flex items-start gap-3">
            <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold">
              {index + 1}
            </div>
            <div className="flex-1 pt-0.5">
              <div className="text-sm font-semibold text-foreground mb-1">
                {step.label}
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">
                {step.description}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Insight */}
      {insight && (
        <div className="pt-4 border-t border-blue-500/10">
          <p className="text-xs text-blue-600 font-semibold">
            💡 {insight}
          </p>
        </div>
      )}
    </div>
  );
}
