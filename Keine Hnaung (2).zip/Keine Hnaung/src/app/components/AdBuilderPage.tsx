import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Progress } from './ui/progress';
import { PageHeader } from './PageHeader';
import { 
  ChevronRight, 
  ChevronLeft, 
  Sparkles, 
  Target, 
  Image as ImageIcon, 
  TrendingUp,
  Users,
  DollarSign,
  Check,
  Zap,
  Brain,
  BarChart3,
  Eye,
  Rocket
} from 'lucide-react';
import { MarketAnalysisLoader } from './MarketAnalysisLoader';
import { AdPreview } from './AdPreview';
import { ConversionScore } from './ConversionScore';
import { AIAdCopyGenerator } from './AIAdCopyGenerator';
import { PageShell, HeroHeader, Card, Chip } from './layout';

interface AdBuilderData {
  productName: string;
  productDescription: string;
  targetAudience: string;
  ageRange: string;
  interests: string;
  painPoints: string;
  uniqueSellingPoint: string;
  budget: string;
  duration: string;
  objective: string;
}

const steps = [
  { id: 1, name: 'Produkt & Messaging', icon: Sparkles },
  { id: 2, name: 'Zielgruppe', icon: Users },
  { id: 3, name: 'Ad Creative', icon: ImageIcon },
  { id: 4, name: 'Marktanalyse', icon: BarChart3 },
  { id: 5, name: 'Performance', icon: TrendingUp },
  { id: 6, name: 'Review & Launch', icon: Rocket },
];

export function AdBuilderPage() {
  const [currentStep, setCurrentStep] = useState(1);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [formData, setFormData] = useState<AdBuilderData>({
    productName: '',
    productDescription: '',
    targetAudience: '',
    ageRange: '',
    interests: '',
    painPoints: '',
    uniqueSellingPoint: '',
    budget: '',
    duration: '',
    objective: 'conversions',
  });

  const [generatedCopy, setGeneratedCopy] = useState<{headline: string, description: string, cta: string}[]>([]);
  const [selectedCopy, setSelectedCopy] = useState<number | null>(null);
  const [selectedVisualStyle, setSelectedVisualStyle] = useState<string | null>(null);
  const [selectedCTA, setSelectedCTA] = useState<string | null>(null);

  const updateFormData = (field: keyof AdBuilderData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleNext = () => {
    if (currentStep === 3) {
      setCurrentStep(4);
      setIsAnalyzing(true);
      setTimeout(() => {
        setIsAnalyzing(false);
        setCurrentStep(5);
      }, 5000);
    } else if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const getNextButtonLabel = () => {
    switch (currentStep) {
      case 1:
        return 'Continue to Targeting';
      case 2:
        return 'Continue to Creative';
      case 3:
        return 'Analyze Market';
      case 5:
        return 'Review Campaign';
      case 6:
        return 'Complete';
      default:
        return 'Continue';
    }
  };

  const generateCopy = () => {
    const copies = [
      {
        headline: `${formData.productName} - Jetzt entdecken`,
        description: `Die perfekte Lösung für ${formData.targetAudience}. ${formData.uniqueSellingPoint}`,
        cta: 'Jetzt kaufen'
      },
      {
        headline: `Revolutioniere dein Business mit ${formData.productName}`,
        description: `Speziell entwickelt für ${formData.targetAudience}. Starte noch heute!`,
        cta: 'Mehr erfahren'
      },
      {
        headline: `Warum ${formData.productName}?`,
        description: `${formData.uniqueSellingPoint}. Perfekt für ${formData.targetAudience}.`,
        cta: 'Kostenlos testen'
      }
    ];
    setGeneratedCopy(copies);
  };

  const progressPercentage = (currentStep / steps.length) * 100;

  return (
    <PageShell>
      <HeroHeader
        title="Ad Builder"
        subtitle="Create high-performing Facebook ads with AI-powered targeting, creative optimization, and automated workflows"
      />

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-5 rounded-lg bg-muted/50 border border-border">
          <div className="text-sm text-muted-foreground mb-1">Ads Created</div>
          <div className="text-2xl font-bold text-foreground">24</div>
        </div>
        <div className="p-5 rounded-lg bg-muted/50 border border-border">
          <div className="text-sm text-muted-foreground mb-1">Avg. ROAS</div>
          <div className="text-2xl font-bold text-foreground">4.8x</div>
        </div>
        <div className="p-5 rounded-lg bg-muted/50 border border-border">
          <div className="text-sm text-muted-foreground mb-1">Avg. CTR</div>
          <div className="text-2xl font-bold text-foreground">3.2%</div>
        </div>
        <div className="p-5 rounded-lg bg-muted/50 border border-border">
          <div className="text-sm text-muted-foreground mb-1">Active Ads</div>
          <div className="text-2xl font-bold text-foreground">12</div>
        </div>
      </div>

      {/* Progress Stepper */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          {steps.map((step, index) => (
            <div key={step.id} className="flex items-center flex-1">
              <div className="flex flex-col items-center flex-1">
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 transition-all border-2 ${
                    currentStep > step.id
                      ? 'bg-primary border-primary text-primary-foreground'
                      : currentStep === step.id
                      ? 'bg-primary border-primary text-primary-foreground'
                      : 'bg-transparent border-border text-muted-foreground'
                  }`}
                >
                  {currentStep > step.id ? (
                    <Check className="w-6 h-6" />
                  ) : (
                    <step.icon className="w-6 h-6" />
                  )}
                </div>
                <span
                  className={`text-sm text-center ${
                    currentStep >= step.id ? 'text-foreground' : 'text-muted-foreground'
                  }`}
                >
                  {step.name}
                </span>
              </div>
              {index < steps.length - 1 && (
                <div
                  className={`h-0.5 flex-1 mx-2 rounded ${
                    currentStep > step.id ? 'bg-primary' : 'bg-border'
                  }`}
                />
              )}
            </div>
          ))}
        </div>
        <Progress value={progressPercentage} className="h-2" />
      </Card>

      {/* Market Analysis Loader */}
      {isAnalyzing && <MarketAnalysisLoader />}

      {/* Main Content */}
      {!isAnalyzing && (
        // FIX 1: Outer Grid - Responsive + Overflow Protection
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 lg:gap-6 w-full max-w-full overflow-x-hidden">
          {/* FIX 2: Left Column - Mobile full width + min-w-0 */}
          <div className="lg:col-span-2 min-w-0">
            <Card className="bg-card border-border p-4 sm:p-6 min-w-0">
              {/* Step 1: Product & Messaging */}
              {currentStep === 1 && (
                <div>
                  <div className="flex items-center gap-3 mb-6 min-w-0">
                    <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center shrink-0">
                      <Sparkles className="w-6 h-6 text-primary-foreground" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h2 className="text-foreground truncate">Produkt-Input für Conversion-Ad</h2>
                      <p className="text-muted-foreground text-sm break-words">Geben Sie Ihre Produktdaten ein für die KI-Analyse</p>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <Label className="text-foreground mb-2">Produktname *</Label>
                      <Input
                        value={formData.productName}
                        onChange={(e) => updateFormData('productName', e.target.value)}
                        placeholder="z.B: FitMax Pro Supplement"
                        className="bg-input border-border text-foreground w-full max-w-full"
                      />
                    </div>

                    <div>
                      <Label className="text-foreground mb-2">Produktbeschreibung *</Label>
                      <Textarea
                        value={formData.productDescription}
                        onChange={(e) => updateFormData('productDescription', e.target.value)}
                        placeholder="Detaillierte Beschreibung Ihres Produkts..."
                        rows={4}
                        className="bg-input border-border text-foreground w-full max-w-full"
                      />
                    </div>

                    {/* FIX 5A: Responsive 2-column grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-foreground mb-2">Branche</Label>
                        <Input
                          placeholder="E-Commerce"
                          className="bg-input border-border text-foreground w-full max-w-full"
                        />
                      </div>
                      <div>
                        <Label className="text-foreground mb-2">Preis</Label>
                        <Input
                          placeholder="€49.99"
                          className="bg-input border-border text-foreground w-full max-w-full"
                        />
                      </div>
                    </div>

                    <div>
                      <Label className="text-foreground mb-2">Hauptnutzen *</Label>
                      <Textarea
                        value={formData.uniqueSellingPoint}
                        onChange={(e) => updateFormData('uniqueSellingPoint', e.target.value)}
                        placeholder="Die wichtigsten Vorteile Ihres Produkts..."
                        rows={3}
                        className="bg-input border-border text-foreground w-full max-w-full"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Step 2: Target Audience */}
              {currentStep === 2 && (
                <div>
                  <div className="flex items-center gap-3 mb-6 min-w-0">
                    <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center shrink-0">
                      <Users className="w-6 h-6 text-primary-foreground" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h2 className="text-foreground truncate">Zielgruppen-Targeting</h2>
                      <p className="text-muted-foreground text-sm break-words">KI-gestützte Audience-Definition</p>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <Label className="text-foreground mb-2">Zielgruppe *</Label>
                      <Input
                        value={formData.targetAudience}
                        onChange={(e) => updateFormData('targetAudience', e.target.value)}
                        placeholder="z.B: Fitness-Enthusiasten, 25-45 Jahre"
                        className="bg-input border-border text-foreground w-full max-w-full"
                      />
                    </div>

                    {/* FIX 5A: Responsive 2-column grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-foreground mb-2">Altersbereich</Label>
                        <Input
                          value={formData.ageRange}
                          onChange={(e) => updateFormData('ageRange', e.target.value)}
                          placeholder="25-45"
                          className="bg-input border-border text-foreground w-full max-w-full"
                        />
                      </div>
                      <div>
                        <Label className="text-foreground mb-2">Geschlecht</Label>
                        <Input
                          placeholder="Alle / Männlich / Weiblich"
                          className="bg-input border-border text-foreground w-full max-w-full"
                        />
                      </div>
                    </div>

                    <div>
                      <Label className="text-foreground mb-2">Interessen & Hobbies</Label>
                      <Input
                        value={formData.interests}
                        onChange={(e) => updateFormData('interests', e.target.value)}
                        placeholder="Fitness, Gesundheit, Ernährung, Sport"
                        className="bg-input border-border text-foreground w-full max-w-full"
                      />
                    </div>

                    <div>
                      <Label className="text-foreground mb-2">Pain Points</Label>
                      <Textarea
                        value={formData.painPoints}
                        onChange={(e) => updateFormData('painPoints', e.target.value)}
                        placeholder="Welche Probleme löst Ihr Produkt?"
                        rows={3}
                        className="bg-input border-border text-foreground w-full max-w-full"
                      />
                    </div>

                    <div className="bg-muted rounded-lg p-4 border border-border w-full max-w-full overflow-hidden">
                      <div className="flex items-start gap-3 min-w-0">
                        <Brain className="w-5 h-5 text-primary mt-1 shrink-0" />
                        <div className="min-w-0 flex-1">
                          <h3 className="text-foreground mb-1">KI-Empfehlung</h3>
                          <p className="text-sm text-muted-foreground break-words">
                            Basierend auf Ihren Eingaben empfehlen wir zusätzliche Targeting-Optionen:
                            "Personen die kürzlich Fitness-Apps installiert haben" und "Online-Käufer im
                            Health-Segment"
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 3: Ad Creative */}
              {currentStep === 3 && (
                <div>
                  <div className="flex items-center gap-3 mb-6 min-w-0">
                    <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center shrink-0">
                      <ImageIcon className="w-6 h-6 text-primary-foreground" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h2 className="text-foreground truncate">Ad Creative Generierung</h2>
                      <p className="text-muted-foreground text-sm break-words">KI-generierte Copy & Visuals</p>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-3">
                        <Label className="text-foreground">Ad Copy Varianten</Label>
                        <Button
                          onClick={generateCopy}
                          size="sm"
                          className="bg-primary hover:bg-primary/90 text-primary-foreground w-full sm:w-auto"
                        >
                          <Zap className="w-4 h-4 mr-2" />
                          KI generieren
                        </Button>
                      </div>

                      {generatedCopy.length > 0 ? (
                        <div className="space-y-3">
                          {generatedCopy.map((copy, index) => (
                            <div
                              key={index}
                              onClick={() => setSelectedCopy(index)}
                              className={`p-4 rounded-lg border-2 cursor-pointer transition-all min-w-0 ${
                                selectedCopy === index
                                  ? 'border-primary bg-primary/10'
                                  : 'border-border bg-card hover:border-muted-foreground'
                              }`}
                            >
                              {/* FIX 7: Anti-Overflow in Copy Cards */}
                              <div className="flex items-start justify-between min-w-0 gap-2">
                                <div className="flex-1 min-w-0">
                                  <div className="text-xs text-muted-foreground mb-1">Variante {index + 1}</div>
                                  <p className="text-foreground break-words">{copy.headline}</p>
                                  <p className="text-foreground text-sm break-words">{copy.description}</p>
                                </div>
                                {selectedCopy === index && (
                                  <Check className="w-5 h-5 text-primary shrink-0 ml-2" />
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="bg-muted rounded-lg p-8 text-center border border-border">
                          <Sparkles className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                          <p className="text-muted-foreground break-words">
                            Klicken Sie auf "KI generieren" um automatische Ad Copy zu erstellen
                          </p>
                        </div>
                      )}
                    </div>

                    <div>
                      <Label className="text-foreground mb-3">Visual Style</Label>
                      {/* FIX 5B: Responsive 3-column grid */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        {[
                          { name: 'Modern & Clean', gradient: 'from-blue-500 to-cyan-400' },
                          { name: 'Bold & Vibrant', gradient: 'from-primary to-orange-500' },
                          { name: 'Minimalistisch', gradient: 'from-gray-800 to-gray-600' }
                        ].map((style) => (
                          <div
                            key={style.name}
                            onClick={() => setSelectedVisualStyle(style.name)}
                            className={`border-2 rounded-lg p-4 text-center cursor-pointer transition-all w-full min-w-0 ${
                              selectedVisualStyle === style.name
                                ? 'border-primary bg-primary/10'
                                : 'border-border bg-card hover:border-muted-foreground'
                            }`}
                          >
                            <div className={`w-full h-20 bg-gradient-to-br ${style.gradient} rounded mb-2 relative`}>
                              {selectedVisualStyle === style.name && (
                                <div className="absolute inset-0 flex items-center justify-center">
                                  <Check className="w-8 h-8 text-white drop-shadow-lg" />
                                </div>
                              )}
                            </div>
                            <p className="text-sm text-foreground font-medium truncate">{style.name}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <Label className="text-foreground mb-3">Call-to-Action</Label>
                      {/* FIX 5A: Responsive 2-column grid */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {['Jetzt kaufen', 'Mehr erfahren', 'Kostenlos testen', 'Angebot sichern'].map(
                          (cta) => (
                            <div
                              key={cta}
                              onClick={() => setSelectedCTA(cta)}
                              className={`border-2 rounded-lg p-4 text-center cursor-pointer transition-all w-full min-w-0 ${
                                selectedCTA === cta
                                  ? 'border-primary bg-primary/10'
                                  : 'border-border bg-card hover:border-muted-foreground'
                              }`}
                            >
                              <div className="flex items-center justify-center gap-2">
                                <p className="text-foreground font-medium truncate">{cta}</p>
                                {selectedCTA === cta && <Check className="w-5 h-5 text-primary shrink-0" />}
                              </div>
                            </div>
                          )
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 5: Performance Prediction */}
              {currentStep === 5 && (
                <div>
                  <div className="flex items-center gap-3 mb-6 min-w-0">
                    <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center shrink-0">
                      <TrendingUp className="w-6 h-6 text-primary-foreground" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h2 className="text-foreground truncate">Performance Prediction</h2>
                      <p className="text-muted-foreground text-sm break-words">KI-basierte Erfolgs-Prognose</p>
                    </div>
                  </div>

                  <div className="space-y-6">
                    {/* FIX 5C: Responsive 3-column grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <Card className="bg-primary border-0 p-4 w-full min-w-0">
                        <div className="text-primary-foreground/80 text-sm mb-1">Erwartete CTR</div>
                        <div className="text-3xl text-primary-foreground font-bold tabular-nums">2.8%</div>
                        <div className="text-primary-foreground/80 text-xs mt-2">+38% vs. Branche</div>
                      </Card>
                      <Card className="bg-foreground border-0 p-4 w-full min-w-0">
                        <div className="text-background/80 text-sm mb-1">Erwartete CVR</div>
                        <div className="text-3xl text-background font-bold tabular-nums">4.2%</div>
                        <div className="text-background/80 text-xs mt-2">Hochwertige Leads</div>
                      </Card>
                      <Card className="bg-muted border-border p-4 w-full min-w-0">
                        <div className="text-muted-foreground text-sm mb-1">Prognostizierter ROAS</div>
                        <div className="text-3xl text-foreground font-bold tabular-nums">5.2x</div>
                        <div className="text-muted-foreground text-xs mt-2">Excellent ROI</div>
                      </Card>
                    </div>

                    <Card className="bg-muted border-border p-5 w-full max-w-full overflow-hidden">
                      <h3 className="text-foreground mb-4">Audience Insights</h3>
                      <div className="space-y-3">
                        <div>
                          <div className="flex justify-between text-sm mb-1 min-w-0 gap-2">
                            <span className="text-muted-foreground truncate">Potentielle Reichweite</span>
                            <span className="text-foreground tabular-nums shrink-0">2.4M - 3.2M</span>
                          </div>
                          <Progress value={75} className="h-2" />
                        </div>
                        <div>
                          <div className="flex justify-between text-sm mb-1 min-w-0 gap-2">
                            <span className="text-muted-foreground truncate">Kaufbereitschaft</span>
                            <span className="text-primary tabular-nums shrink-0">Hoch (82%)</span>
                          </div>
                          <Progress value={82} className="h-2" />
                        </div>
                        <div>
                          <div className="flex justify-between text-sm mb-1 min-w-0 gap-2">
                            <span className="text-muted-foreground truncate">Wettbewerbsintensität</span>
                            <span className="text-foreground tabular-nums shrink-0">Mittel (65%)</span>
                          </div>
                          <Progress value={65} className="h-2" />
                        </div>
                      </div>
                    </Card>

                    {/* FIX 5D: 7-column grid with horizontal scroll */}
                    <Card className="bg-muted border-border p-5 w-full max-w-full overflow-hidden">
                      <h3 className="text-foreground mb-4">Beste Performance-Zeiträume</h3>
                      <div className="w-full max-w-full overflow-x-auto">
                        <div className="grid grid-cols-7 gap-2 min-w-[420px]">
                          {['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].map((day, index) => (
                            <div key={day} className="text-center">
                              <div className="text-xs text-muted-foreground mb-2">{day}</div>
                              <div
                                className={`h-16 rounded ${
                                  index >= 4
                                    ? 'bg-primary'
                                    : index >= 2
                                    ? 'bg-foreground'
                                    : 'bg-border'
                                }`}
                              ></div>
                            </div>
                          ))}
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mt-3 break-words">
                        Beste Performance: Freitag-Sonntag, 18:00-22:00 Uhr
                      </p>
                    </Card>
                  </div>
                </div>
              )}

              {/* Step 6: Review & Launch */}
              {currentStep === 6 && (
                <div>
                  <div className="flex items-center gap-3 mb-6 min-w-0">
                    <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center shrink-0">
                      <Rocket className="w-6 h-6 text-primary-foreground" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h2 className="text-foreground truncate">Review & Launch</h2>
                      <p className="text-muted-foreground text-sm break-words">Finale Übersicht & Kampagnenstart</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <Card className="bg-muted border-border p-5 w-full max-w-full overflow-hidden">
                      <h3 className="text-foreground mb-3">Kampagnen-Zusammenfassung</h3>
                      {/* FIX 5A: Responsive 2-column grid */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="min-w-0">
                          <div className="text-sm text-muted-foreground">Produkt</div>
                          <div className="text-foreground truncate">{formData.productName || 'Nicht angegeben'}</div>
                        </div>
                        <div className="min-w-0">
                          <div className="text-sm text-muted-foreground">Zielgruppe</div>
                          <div className="text-foreground truncate">
                            {formData.targetAudience || 'Nicht angegeben'}
                          </div>
                        </div>
                        <div className="min-w-0">
                          <div className="text-sm text-muted-foreground">Budget</div>
                          <div className="text-foreground truncate">€{formData.budget || '0'} / Tag</div>
                        </div>
                        <div className="min-w-0">
                          <div className="text-sm text-muted-foreground">Laufzeit</div>
                          <div className="text-foreground truncate">{formData.duration || '0'} Tage</div>
                        </div>
                      </div>
                    </Card>

                    <Card className="bg-primary/10 border-primary p-5 w-full max-w-full overflow-hidden">
                      <div className="flex items-center gap-3 mb-3 min-w-0">
                        <Check className="w-6 h-6 text-primary shrink-0" />
                        <h3 className="text-foreground truncate">Kampagne bereit zum Start!</h3>
                      </div>
                      <p className="text-foreground/80 text-sm break-words">
                        Alle Einstellungen wurden überprüft. Ihre Kampagne kann jetzt gestartet werden.
                      </p>
                    </Card>

                    <div className="bg-muted border border-border rounded-lg p-4 w-full max-w-full overflow-hidden">
                      <h4 className="text-foreground mb-3">Was passiert nach dem Launch?</h4>
                      <ul className="space-y-2 text-sm text-foreground/80">
                        <li className="flex items-start gap-2 min-w-0">
                          <Check className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                          <span className="break-words">Kampagne wird bei Meta zur Freigabe eingereicht</span>
                        </li>
                        <li className="flex items-start gap-2 min-w-0">
                          <Check className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                          <span className="break-words">Automatisches A/B Testing startet</span>
                        </li>
                        <li className="flex items-start gap-2 min-w-0">
                          <Check className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                          <span className="break-words">Echtzeit-Performance-Tracking aktiviert</span>
                        </li>
                        <li className="flex items-start gap-2 min-w-0">
                          <Check className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                          <span className="break-words">KI-Optimierung läuft kontinuierlich im Hintergrund</span>
                        </li>
                      </ul>
                    </div>

                    <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground h-12">
                      <Rocket className="w-5 h-5 mr-2" />
                      Kampagne jetzt starten
                    </Button>

                    <Button
                      onClick={() => {
                        // Save ad to localStorage
                        const savedAds = JSON.parse(localStorage.getItem('savedAds') || '[]');
                        const selectedCopyData = selectedCopy !== null ? generatedCopy[selectedCopy] : null;
                        const newAd = {
                          id: Date.now().toString(),
                          name: formData.productName || 'Untitled Ad',
                          headline: selectedCopyData?.headline || 'No headline',
                          description: selectedCopyData?.description || 'No description',
                          cta: selectedCopyData?.cta || 'Learn More',
                          productName: formData.productName,
                          targetAudience: formData.targetAudience,
                          objective: formData.objective,
                          budget: `€${formData.budget}/day`,
                          status: 'draft',
                          createdAt: new Date().toISOString(),
                          performance: {
                            impressions: 0,
                            clicks: 0,
                            ctr: 0,
                            conversions: 0,
                            roas: 0,
                            spent: 0
                          }
                        };
                        savedAds.push(newAd);
                        localStorage.setItem('savedAds', JSON.stringify(savedAds));
                        
                        // Show toast notification (you'll need to add toast import)
                        alert('Ad saved to Saved Ads!');
                      }}
                      variant="outline"
                      className="w-full border-border text-foreground hover:bg-muted h-12"
                    >
                      Als Entwurf speichern
                    </Button>
                  </div>
                </div>
              )}

              {/* FIX 6: Navigation Buttons - Mobile Stack */}
              {currentStep !== 4 && (
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mt-8 pt-6 border-t border-border">
                  <Button
                    onClick={handleBack}
                    disabled={currentStep === 1}
                    variant="outline"
                    className="border-border text-foreground hover:bg-muted w-full sm:w-auto"
                  >
                    <ChevronLeft className="w-4 h-4 mr-2" />
                    Zurück
                  </Button>
                  <Button
                    onClick={handleNext}
                    disabled={currentStep === steps.length}
                    className="bg-primary hover:bg-primary/90 text-primary-foreground w-full sm:w-auto"
                  >
                    {getNextButtonLabel()}
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              )}
            </Card>
          </div>

          {/* FIX 3: Right Column - Mobile full width + min-w-0 */}
          <div className="lg:col-span-1 space-y-4 lg:space-y-6 min-w-0">
            <AdPreview
              copy={selectedCopy !== null ? generatedCopy[selectedCopy] : undefined}
              productName={formData.productName}
            />
            <ConversionScore score={94} />
          </div>

          {/* FIX 4: AI Copy Generator Sidebar - Mobile Collapsible */}
          <div className="lg:col-span-1 min-w-0">
            {/* Mobile: Collapsible Section */}
            <details className="lg:hidden rounded-xl border border-border bg-card">
              <summary className="px-4 py-3 cursor-pointer text-foreground font-medium flex items-center gap-2">
                <Brain className="w-5 h-5 text-primary" />
                AI Copy Generator öffnen
              </summary>
              <div className="p-4 border-t border-border">
                <AIAdCopyGenerator
                  productName={formData.productName}
                  productDescription={formData.productDescription}
                  targetAudience={formData.targetAudience}
                  uniqueSellingPoint={formData.uniqueSellingPoint}
                  onSelectCopy={(copy) => {
                    // Add selected AI copy to generatedCopy list
                    const newCopy = {
                      headline: copy.headline,
                      description: copy.description,
                      cta: copy.cta
                    };
                    setGeneratedCopy(prev => [...prev, newCopy]);
                    setSelectedCopy(generatedCopy.length); // Select the newly added copy
                  }}
                />
              </div>
            </details>

            {/* Desktop: Full Sidebar */}
            <div className="hidden lg:block h-auto lg:h-[800px]">
              <Card className="bg-card border-border h-full overflow-hidden min-w-0">
                <AIAdCopyGenerator
                  productName={formData.productName}
                  productDescription={formData.productDescription}
                  targetAudience={formData.targetAudience}
                  uniqueSellingPoint={formData.uniqueSellingPoint}
                  onSelectCopy={(copy) => {
                    // Add selected AI copy to generatedCopy list
                    const newCopy = {
                      headline: copy.headline,
                      description: copy.description,
                      cta: copy.cta
                    };
                    setGeneratedCopy(prev => [...prev, newCopy]);
                    setSelectedCopy(generatedCopy.length); // Select the newly added copy
                  }}
                />
              </Card>
            </div>
          </div>
        </div>
      )}
    </PageShell>
  );
}