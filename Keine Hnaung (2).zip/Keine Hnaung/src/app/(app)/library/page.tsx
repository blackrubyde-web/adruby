export default function LibraryPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Assets & Library</h1>
      <p className="text-sm text-muted-foreground mt-1">Route scaffold.</p>
    </div>
  );
}

