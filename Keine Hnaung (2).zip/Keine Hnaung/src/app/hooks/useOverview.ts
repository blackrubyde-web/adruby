import { useEffect, useState } from 'react';
import { OverviewResponse } from '../types/overview';

export function useOverview(range: 'today' | '7d' | '30d', channel: string) {
  const [data, setData] = useState<OverviewResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    // Mock API call for now - replace with real API later
    // fetch(`/api/overview?range=${range}&channel=${channel}`)
    //   .then(async (r) => {
    //     if (!r.ok) throw new Error(await r.text());
    //     return r.json();
    //   })
    //   .then((json) => !cancelled && setData(json))
    //   .catch((e) => !cancelled && setError(e.message ?? 'Failed to load'))
    //   .finally(() => !cancelled && setLoading(false));

    // MOCK DATA (replace with real API)
    setTimeout(() => {
      if (cancelled) return;

      const mockData: OverviewResponse = {
        kpis: {
          spend: 24800,
          revenue: 186400,
          roas: 7.52,
          activeCampaigns: 24,
          spendChangePct: 12.5,
          revenueChangePct: 18.2,
          roasChangePct: 10.6,
        },
        timeseries: generateMockTimeseries(range),
        topCampaign: {
          id: 'camp-1',
          name: 'Summer Sale 2024',
          roas: 12.4,
          spend: 3200,
          revenue: 39680,
        },
        bestCreative: {
          id: 'creative-1',
          name: 'Video Ad - Product Demo',
          aiScore: 94,
          ctr: 4.2,
          conversions: 234,
        },
        onboarding: {
          completedSteps: 0,
          totalSteps: 4,
          steps: [
            {
              id: 'connect-meta',
              title: 'Connect Meta Ads account',
              description: 'Link your Facebook Business account to import campaigns',
              completed: false,
              actionLabel: 'Connect',
            },
            {
              id: 'create-campaign',
              title: 'Create your first campaign',
              description: 'Launch a campaign to start getting results',
              completed: false,
              actionLabel: 'Create',
            },
            {
              id: 'generate-creatives',
              title: 'Generate AI ad creatives',
              description: 'Use AI to create high-performing ad variations',
              completed: false,
              actionLabel: 'Generate',
            },
            {
              id: 'enable-optimization',
              title: 'Enable AI optimization rules',
              description: 'Let AI automatically optimize your campaigns',
              completed: false,
              actionLabel: 'Enable',
            },
          ],
        },
      };

      setData(mockData);
      setLoading(false);
    }, 800);

    return () => {
      cancelled = true;
    };
  }, [range, channel]);

  return { data, loading, error };
}

// Helper: Generate mock timeseries based on range
function generateMockTimeseries(range: 'today' | '7d' | '30d') {
  const now = new Date();
  const points = [];

  if (range === 'today') {
    // 24 hourly buckets
    for (let i = 23; i >= 0; i--) {
      const ts = new Date(now);
      ts.setHours(ts.getHours() - i);
      const spend = 800 + Math.random() * 400;
      const revenue = spend * (6 + Math.random() * 3);
      points.push({
        ts: ts.toISOString(),
        spend,
        revenue,
        roas: revenue / spend,
      });
    }
  } else if (range === '7d') {
    // 7 daily buckets
    for (let i = 6; i >= 0; i--) {
      const ts = new Date(now);
      ts.setDate(ts.getDate() - i);
      ts.setHours(12, 0, 0, 0);
      const spend = 2800 + Math.random() * 1200;
      const revenue = spend * (6.5 + Math.random() * 2.5);
      points.push({
        ts: ts.toISOString(),
        spend,
        revenue,
        roas: revenue / spend,
      });
    }
  } else {
    // 30d = 30 daily buckets
    for (let i = 29; i >= 0; i--) {
      const ts = new Date(now);
      ts.setDate(ts.getDate() - i);
      ts.setHours(12, 0, 0, 0);
      const spend = 2400 + Math.random() * 1600;
      const revenue = spend * (6 + Math.random() * 3.5);
      points.push({
        ts: ts.toISOString(),
        spend,
        revenue,
        roas: revenue / spend,
      });
    }
  }

  return points;
}
