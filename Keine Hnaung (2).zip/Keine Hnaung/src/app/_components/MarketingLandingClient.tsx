"use client";

import { useRouter } from "next/navigation";
import { LandingPage } from "@/app/components/LandingPage";

export function MarketingLandingClient() {
  const router = useRouter();

  return (
    <LandingPage
      onGetStarted={() => router.push("/register")}
      onLogin={() => router.push("/login")}
    />
  );
}

