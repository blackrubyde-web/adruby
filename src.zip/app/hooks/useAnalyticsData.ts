import { useEffect, useState } from 'react';
import { AnalyticsData } from '../types/analytics';

export function useAnalyticsData(
  range: '7d' | '30d' | '90d' | 'custom',
  compare: boolean,
  channel: string
) {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    // Real API call (commented out for now)
    // fetch(`/api/analytics?range=${range}&compare=${compare ? 1 : 0}&channel=${channel}`)
    //   .then(async (r) => {
    //     if (!r.ok) throw new Error(await r.text());
    //     return r.json();
    //   })
    //   .then((json) => { if (!cancelled) setData(json); })
    //   .catch((e) => { if (!cancelled) setError(e?.message ?? 'Failed'); })
    //   .finally(() => { if (!cancelled) setLoading(false); });

    // MOCK DATA (replace with real API)
    setTimeout(() => {
      if (cancelled) return;

      const mockData = generateMockAnalyticsData(range, compare, channel);
      setData(mockData);
      setLoading(false);
    }, 800);

    return () => {
      cancelled = true;
    };
  }, [range, compare, channel]);

  return { data, loading, error };
}

// ============================================================================
// MOCK DATA GENERATOR
// ============================================================================

function generateMockAnalyticsData(
  range: '7d' | '30d' | '90d' | 'custom',
  compare: boolean,
  channel: string
): AnalyticsData {
  const days = range === '7d' ? 7 : range === '30d' ? 30 : range === '90d' ? 90 : 14;

  // 1) Summary KPIs
  const summary = {
    impressions: 2400000,
    clicks: 89000,
    spend: 42000,
    revenue: 201600,
    conversions: 1240,
    ctr: 3.71,              // percentage
    roas: 4.8,
    cpa: 33.87,
    deltas: compare ? {
      impressions: 0.12,    // +12%
      clicks: 0.08,         // +8%
      spend: 0.15,          // +15%
      revenue: 0.22,        // +22%
      conversions: 0.18,    // +18%
      ctr: 0.04,            // +4%
      roas: 0.10,           // +10%
      cpa: -0.05,           // -5%
    } : undefined,
  };

  // 2) Timeseries
  const timeseries = {
    current: generateTimeseries(days, false),
    previous: compare ? generateTimeseries(days, true) : undefined,
  };

  // 3) Campaigns
  const campaigns = [
    {
      id: 'camp-1',
      name: 'Summer Sale 2024',
      status: 'active' as const,
      spend: 12400,
      revenue: 89600,
      roas: 7.23,
      ctr: 4.2,
      conversions: 456,
      budget: 15000,
      budgetUsed: 82,
    },
    {
      id: 'camp-2',
      name: 'Black Friday Pre-Launch',
      status: 'active' as const,
      spend: 18200,
      revenue: 73400,
      roas: 4.03,
      ctr: 3.8,
      conversions: 389,
      budget: 20000,
      budgetUsed: 91,
    },
    {
      id: 'camp-3',
      name: 'Product Launch Q4',
      status: 'active' as const,
      spend: 11400,
      revenue: 38600,
      roas: 3.39,
      ctr: 3.1,
      conversions: 395,
      budget: 25000,
      budgetUsed: 45,
    },
    {
      id: 'camp-4',
      name: 'Brand Awareness',
      status: 'paused' as const,
      spend: 8200,
      revenue: 12400,
      roas: 1.51,
      ctr: 2.4,
      conversions: 124,
      budget: 10000,
      budgetUsed: 82,
    },
  ];

  // 4) Breakdowns
  const breakdowns = {
    audience: {
      byAge: [
        { age: '18-24', male: 18, female: 22 },
        { age: '25-34', male: 28, female: 32 },
        { age: '35-44', male: 22, female: 24 },
        { age: '45-54', male: 12, female: 14 },
        { age: '55+', male: 8, female: 10 },
      ],
      byGender: { male: 48, female: 50, other: 2 },
    },
    funnel: [
      { stage: 'Impressions', count: 2400000, percentage: 100 },
      { stage: 'Clicks', count: 89000, percentage: 3.71 },
      { stage: 'Landing Page', count: 67200, percentage: 75.5 },
      { stage: 'Add to Cart', count: 18900, percentage: 28.1 },
      { stage: 'Checkout', count: 2480, percentage: 13.1 },
      { stage: 'Purchase', count: 1240, percentage: 50.0 },
    ],
    heatmap: generateHeatmap(),
  };

  // 5) AI Insights
  const ai = {
    insights: [
      {
        id: 'insight-1',
        title: 'CTR increased 18% in age group 25-34',
        impact: 'high' as const,
        summary: 'Your creative resonates strongly with millennials. Consider increasing budget allocation to this segment.',
      },
      {
        id: 'insight-2',
        title: 'Weekend performance drops by 23%',
        impact: 'medium' as const,
        summary: 'Campaigns perform significantly better on weekdays. Adjust scheduling for optimal results.',
      },
      {
        id: 'insight-3',
        title: 'Mobile CTR outperforms desktop by 34%',
        impact: 'high' as const,
        summary: 'Mobile-optimized creatives are driving better engagement. Prioritize mobile-first content.',
      },
    ],
    strategy: [
      {
        id: 'strat-1',
        title: 'Increase budget for top performer',
        reason: 'Campaign "Summer Sale 2024" has 7.2x ROAS',
        action: 'Scale budget by 30% while maintaining current targeting',
      },
      {
        id: 'strat-2',
        title: 'Pause underperforming ad sets',
        reason: '3 ad sets have ROAS below 2.0x for 5+ days',
        action: 'Pause and reallocate €1,200 budget to winners',
      },
    ],
    forecast: {
      predictions: generateForecast(7),
    },
  };

  // 6) Performance Score
  const performance = {
    score: 87,
    quality: 92,
    relevance: 85,
    engagement: 84,
  };

  // 7) Budget
  const budget = {
    total: 70000,
    spent: 42000,
    remaining: 28000,
    dailyAverage: 6000,
    projectedEnd: new Date(Date.now() + 4.67 * 24 * 60 * 60 * 1000).toISOString(),
  };

  return {
    range,
    compare,
    granularity: 'day',
    summary,
    timeseries,
    campaigns,
    breakdowns,
    ai,
    performance,
    budget,
  };
}

// Helper: Generate timeseries
function generateTimeseries(days: number, isPrevious: boolean) {
  const now = new Date();
  const points = [];

  for (let i = days - 1; i >= 0; i--) {
    const ts = new Date(now);
    if (isPrevious) {
      ts.setDate(ts.getDate() - days - i);
    } else {
      ts.setDate(ts.getDate() - i);
    }
    ts.setHours(12, 0, 0, 0);

    const baseImpressions = isPrevious ? 70000 : 80000;
    const impressions = baseImpressions + Math.random() * 40000;
    const clicks = impressions * (0.03 + Math.random() * 0.02);
    const spend = 1400 + Math.random() * 800;
    const revenue = spend * (isPrevious ? 3.8 : 4.5) * (0.8 + Math.random() * 0.4);
    const conversions = clicks * (0.01 + Math.random() * 0.015);

    points.push({
      ts: ts.toISOString(),
      impressions: Math.round(impressions),
      clicks: Math.round(clicks),
      spend: Math.round(spend),
      revenue: Math.round(revenue),
      conversions: Math.round(conversions),
      ctr: (clicks / impressions) * 100,
      roas: revenue / spend,
      cpa: spend / conversions,
      aiScore: 75 + Math.random() * 25,
    });
  }

  return points;
}

// Helper: Generate heatmap
function generateHeatmap() {
  const heatmap = [];
  for (let day = 0; day < 7; day++) {
    for (let hour = 0; hour < 24; hour++) {
      // Higher values during business hours (9-17) and weekdays
      const isWeekday = day < 5;
      const isBusinessHour = hour >= 9 && hour <= 17;
      const base = 50;
      const weekdayBonus = isWeekday ? 20 : 0;
      const hourBonus = isBusinessHour ? 25 : 0;
      const value = base + weekdayBonus + hourBonus + Math.random() * 15;

      heatmap.push({
        day,
        hour,
        value: Math.round(value),
      });
    }
  }
  return heatmap;
}

// Helper: Generate forecast
function generateForecast(days: number) {
  const now = new Date();
  const predictions = [];

  for (let i = 1; i <= days; i++) {
    const ts = new Date(now);
    ts.setDate(ts.getDate() + i);
    ts.setHours(12, 0, 0, 0);

    const spend = 1500 + Math.random() * 700;
    const revenue = spend * (4.8 + Math.random() * 1.2);

    predictions.push({
      ts: ts.toISOString(),
      revenue: Math.round(revenue),
      spend: Math.round(spend),
      confidence: 0.75 + Math.random() * 0.2,
    });
  }

  return predictions;
}
