import { useState } from 'react';
import {
  User,
  Mail,
  Lock,
  Bell,
  Palette,
  CreditCard,
  Shield,
  Trash2,
  Check,
  X,
  ExternalLink,
  AlertCircle,
  Save,
  Facebook,
  Link2,
  Globe,
  Zap,
  DollarSign,
  Eye,
  EyeOff,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import { toast } from 'sonner';
import { PageShell, HeroHeader, Card, Chip } from './layout';

type SettingsTab = 'account' | 'integrations' | 'notifications' | 'appearance' | 'billing' | 'security';

export function SettingsPage() {
  const [activeTab, setActiveTab] = useState<SettingsTab>('account');
  const [isSaving, setIsSaving] = useState(false);

  // Account Settings State
  const [accountData, setAccountData] = useState({
    name: 'Max Mustermann',
    email: 'max@example.com',
    company: 'My Company GmbH',
    timezone: 'Europe/Berlin',
  });

  // Facebook Integration State
  const [facebookConnected, setFacebookConnected] = useState(false);
  const [facebookAccount, setFacebookAccount] = useState({
    name: 'Max Mustermann',
    adAccountId: '123456789',
    accessToken: 'EAABwz...',
    connectedAt: '2024-01-15',
  });

  // Notification Settings State
  const [notifications, setNotifications] = useState({
    emailAlerts: true,
    budgetAlerts: true,
    performanceAlerts: true,
    weeklyReport: true,
    campaignUpdates: false,
  });

  // Appearance Settings State
  const [appearance, setAppearance] = useState({
    theme: 'dark',
    language: 'de',
    compactMode: false,
  });

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      toast.success('Settings saved successfully!');
    }, 1000);
  };

  const handleFacebookConnect = () => {
    // Simulate OAuth flow
    toast.info('Opening Facebook OAuth...');
    setTimeout(() => {
      setFacebookConnected(true);
      toast.success('Facebook account connected successfully!');
    }, 2000);
  };

  const handleFacebookDisconnect = () => {
    setFacebookConnected(false);
    toast.success('Facebook account disconnected');
  };

  const tabs: { id: SettingsTab; label: string; icon: React.ReactNode }[] = [
    { id: 'account', label: 'Account', icon: <User className="w-5 h-5" /> },
    { id: 'integrations', label: 'Integrations', icon: <Link2 className="w-5 h-5" /> },
    { id: 'notifications', label: 'Notifications', icon: <Bell className="w-5 h-5" /> },
    { id: 'appearance', label: 'Appearance', icon: <Palette className="w-5 h-5" /> },
    { id: 'billing', label: 'Billing', icon: <CreditCard className="w-5 h-5" /> },
    { id: 'security', label: 'Security', icon: <Shield className="w-5 h-5" /> },
  ];

  return (
    <PageShell>
      <HeroHeader
        title="Settings"
        subtitle="Manage your account settings and integrations"
      />

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar Navigation */}
        <div className="lg:col-span-1">
          <div className="backdrop-blur-xl bg-card/60 rounded-2xl border border-border/50 shadow-xl p-2 sticky top-24">
            <nav className="space-y-1">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                    activeTab === tab.id
                      ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/30'
                      : 'text-muted-foreground hover:bg-muted/50 hover:text-foreground'
                  }`}
                >
                  {tab.icon}
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Content Area */}
        <div className="lg:col-span-3">
          <div className="backdrop-blur-xl bg-card/60 rounded-2xl border border-border/50 shadow-xl">
            {/* Account Settings */}
            {activeTab === 'account' && (
              <div className="p-8">
                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-foreground mb-2">Account Settings</h2>
                  <p className="text-sm text-muted-foreground">Manage your personal information</p>
                </div>

                <div className="space-y-6">
                  {/* Profile Picture */}
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-3">Profile Picture</label>
                    <div className="flex items-center gap-4">
                      <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center text-primary text-2xl font-bold">
                        MM
                      </div>
                      <div>
                        <button className="px-4 py-2 bg-muted hover:bg-muted/80 rounded-lg text-sm font-semibold transition-all">
                          Upload New
                        </button>
                        <p className="text-xs text-muted-foreground mt-2">JPG, PNG or GIF. Max 2MB.</p>
                      </div>
                    </div>
                  </div>

                  {/* Name */}
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">Full Name</label>
                    <input
                      type="text"
                      value={accountData.name}
                      onChange={(e) => setAccountData({ ...accountData, name: e.target.value })}
                      className="w-full px-4 py-3 bg-muted/50 border border-border/50 rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    />
                  </div>

                  {/* Email */}
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">Email Address</label>
                    <input
                      type="email"
                      value={accountData.email}
                      onChange={(e) => setAccountData({ ...accountData, email: e.target.value })}
                      className="w-full px-4 py-3 bg-muted/50 border border-border/50 rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    />
                  </div>

                  {/* Company */}
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">Company Name</label>
                    <input
                      type="text"
                      value={accountData.company}
                      onChange={(e) => setAccountData({ ...accountData, company: e.target.value })}
                      className="w-full px-4 py-3 bg-muted/50 border border-border/50 rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    />
                  </div>

                  {/* Timezone */}
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">Timezone</label>
                    <select
                      value={accountData.timezone}
                      onChange={(e) => setAccountData({ ...accountData, timezone: e.target.value })}
                      className="w-full px-4 py-3 bg-muted/50 border border-border/50 rounded-xl text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    >
                      <option value="Europe/Berlin">Europe/Berlin (GMT+1)</option>
                      <option value="Europe/London">Europe/London (GMT+0)</option>
                      <option value="America/New_York">America/New York (GMT-5)</option>
                      <option value="America/Los_Angeles">America/Los Angeles (GMT-8)</option>
                    </select>
                  </div>

                  {/* Save Button */}
                  <button
                    onClick={handleSave}
                    disabled={isSaving}
                    className="w-full md:w-auto px-6 py-3 bg-primary text-primary-foreground rounded-xl font-semibold hover:scale-105 transition-all shadow-lg shadow-primary/30 disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isSaving ? (
                      <>
                        <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="w-5 h-5" />
                        Save Changes
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* Integrations */}
            {activeTab === 'integrations' && (
              <div className="p-8">
                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-foreground mb-2">Integrations</h2>
                  <p className="text-sm text-muted-foreground">Connect your advertising accounts and platforms</p>
                </div>

                <div className="space-y-6">
                  {/* Facebook/Meta Integration */}
                  <div className="p-6 bg-gradient-to-br from-blue-500/10 to-transparent border-2 border-blue-500/20 rounded-2xl">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 bg-[#1877F2] rounded-2xl flex items-center justify-center">
                          <Facebook className="w-8 h-8 text-white" />
                        </div>
                        <div>
                          <h3 className="text-lg font-bold text-foreground flex items-center gap-2">
                            Facebook Ads
                            {facebookConnected && (
                              <span className="flex items-center gap-1 px-2 py-1 bg-green-500/20 text-green-500 rounded-full text-xs font-semibold">
                                <CheckCircle2 className="w-3 h-3" />
                                Connected
                              </span>
                            )}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            Connect your Facebook Ad Account to import campaigns and metrics
                          </p>
                        </div>
                      </div>
                    </div>

                    {facebookConnected ? (
                      <div className="space-y-4">
                        {/* Connected Account Info */}
                        <div className="p-4 bg-background/50 rounded-xl space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-muted-foreground">Account Name</span>
                            <span className="text-sm font-semibold text-foreground">{facebookAccount.name}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-muted-foreground">Ad Account ID</span>
                            <span className="text-sm font-mono font-semibold text-foreground">{facebookAccount.adAccountId}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-muted-foreground">Connected Since</span>
                            <span className="text-sm font-semibold text-foreground">{facebookAccount.connectedAt}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-muted-foreground">Status</span>
                            <span className="flex items-center gap-1 text-sm font-semibold text-green-500">
                              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                              Active
                            </span>
                          </div>
                        </div>

                        {/* Permissions */}
                        <div className="p-4 bg-background/50 rounded-xl">
                          <h4 className="text-sm font-semibold text-foreground mb-3">Granted Permissions</h4>
                          <div className="space-y-2">
                            {[
                              'Read ad campaigns',
                              'Read ad insights',
                              'Access ad account data',
                              'View billing information',
                            ].map((permission, i) => (
                              <div key={i} className="flex items-center gap-2 text-sm">
                                <Check className="w-4 h-4 text-green-500" />
                                <span className="text-muted-foreground">{permission}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex gap-3">
                          <button className="flex-1 px-4 py-2.5 bg-muted hover:bg-muted/80 rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-2">
                            <Zap className="w-4 h-4" />
                            Sync Now
                          </button>
                          <button
                            onClick={handleFacebookDisconnect}
                            className="flex-1 px-4 py-2.5 bg-red-500/10 hover:bg-red-500/20 text-red-500 rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-2"
                          >
                            <X className="w-4 h-4" />
                            Disconnect
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="p-4 bg-background/50 rounded-xl">
                          <h4 className="text-sm font-semibold text-foreground mb-2">What you'll get:</h4>
                          <ul className="space-y-2">
                            {[
                              'Automatic campaign data sync',
                              'Real-time performance metrics',
                              'AI-powered optimization insights',
                              'Automated reporting',
                            ].map((feature, i) => (
                              <li key={i} className="flex items-center gap-2 text-sm text-muted-foreground">
                                <Check className="w-4 h-4 text-primary" />
                                {feature}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <button
                          onClick={handleFacebookConnect}
                          className="w-full px-6 py-3 bg-[#1877F2] hover:bg-[#1877F2]/90 text-white rounded-xl font-semibold transition-all shadow-lg flex items-center justify-center gap-2"
                        >
                          <Facebook className="w-5 h-5" />
                          Connect Facebook Account
                        </button>

                        <p className="text-xs text-muted-foreground text-center">
                          By connecting, you agree to share your ad data with our platform
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Google Ads Integration (Placeholder) */}
                  <div className="p-6 bg-gradient-to-br from-red-500/10 to-transparent border-2 border-border/30 rounded-2xl opacity-60">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 bg-muted rounded-2xl flex items-center justify-center">
                          <Globe className="w-8 h-8 text-muted-foreground" />
                        </div>
                        <div>
                          <h3 className="text-lg font-bold text-foreground flex items-center gap-2">
                            Google Ads
                            <span className="px-2 py-1 bg-muted rounded-full text-xs font-semibold text-muted-foreground">
                              Coming Soon
                            </span>
                          </h3>
                          <p className="text-sm text-muted-foreground">Google Ads integration will be available soon</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* TikTok Ads Integration (Placeholder) */}
                  <div className="p-6 bg-gradient-to-br from-pink-500/10 to-transparent border-2 border-border/30 rounded-2xl opacity-60">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 bg-muted rounded-2xl flex items-center justify-center">
                          <Zap className="w-8 h-8 text-muted-foreground" />
                        </div>
                        <div>
                          <h3 className="text-lg font-bold text-foreground flex items-center gap-2">
                            TikTok Ads
                            <span className="px-2 py-1 bg-muted rounded-full text-xs font-semibold text-muted-foreground">
                              Coming Soon
                            </span>
                          </h3>
                          <p className="text-sm text-muted-foreground">TikTok Ads integration will be available soon</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Notifications */}
            {activeTab === 'notifications' && (
              <div className="p-8">
                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-foreground mb-2">Notifications</h2>
                  <p className="text-sm text-muted-foreground">Manage how you receive notifications</p>
                </div>

                <div className="space-y-6">
                  {/* Email Notifications */}
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-4">Email Notifications</h3>
                    <div className="space-y-4">
                      {[
                        { id: 'emailAlerts', label: 'Email Alerts', description: 'Receive important alerts via email' },
                        { id: 'budgetAlerts', label: 'Budget Alerts', description: 'Get notified when budget limits are reached' },
                        { id: 'performanceAlerts', label: 'Performance Alerts', description: 'Alerts for significant performance changes' },
                        { id: 'weeklyReport', label: 'Weekly Report', description: 'Weekly summary of your campaigns' },
                        { id: 'campaignUpdates', label: 'Campaign Updates', description: 'Updates when campaigns start or end' },
                      ].map((item) => (
                        <div key={item.id} className="flex items-center justify-between p-4 bg-muted/30 rounded-xl">
                          <div>
                            <div className="font-semibold text-foreground">{item.label}</div>
                            <div className="text-sm text-muted-foreground">{item.description}</div>
                          </div>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              checked={notifications[item.id as keyof typeof notifications]}
                              onChange={(e) =>
                                setNotifications({ ...notifications, [item.id]: e.target.checked })
                              }
                              className="sr-only peer"
                            />
                            <div className="w-11 h-6 bg-muted peer-focus:ring-2 peer-focus:ring-primary/50 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={handleSave}
                    className="w-full md:w-auto px-6 py-3 bg-primary text-primary-foreground rounded-xl font-semibold hover:scale-105 transition-all shadow-lg shadow-primary/30 flex items-center justify-center gap-2"
                  >
                    <Save className="w-5 h-5" />
                    Save Preferences
                  </button>
                </div>
              </div>
            )}

            {/* Appearance */}
            {activeTab === 'appearance' && (
              <div className="p-8">
                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-foreground mb-2">Appearance</h2>
                  <p className="text-sm text-muted-foreground">Customize how the platform looks</p>
                </div>

                <div className="space-y-6">
                  {/* Theme */}
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-3">Theme</label>
                    <div className="grid grid-cols-3 gap-4">
                      {[
                        { id: 'light', label: 'Light', icon: '☀️' },
                        { id: 'dark', label: 'Dark', icon: '🌙' },
                        { id: 'auto', label: 'Auto', icon: '⚡' },
                      ].map((theme) => (
                        <button
                          key={theme.id}
                          onClick={() => setAppearance({ ...appearance, theme: theme.id })}
                          className={`p-4 rounded-xl border-2 transition-all ${
                            appearance.theme === theme.id
                              ? 'border-primary bg-primary/10'
                              : 'border-border/30 bg-muted/30 hover:bg-muted/50'
                          }`}
                        >
                          <div className="text-3xl mb-2">{theme.icon}</div>
                          <div className="font-semibold text-foreground">{theme.label}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Language */}
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">Language</label>
                    <select
                      value={appearance.language}
                      onChange={(e) => setAppearance({ ...appearance, language: e.target.value })}
                      className="w-full px-4 py-3 bg-muted/50 border border-border/50 rounded-xl text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    >
                      <option value="de">Deutsch</option>
                      <option value="en">English</option>
                      <option value="es">Español</option>
                      <option value="fr">Français</option>
                    </select>
                  </div>

                  {/* Compact Mode */}
                  <div className="flex items-center justify-between p-4 bg-muted/30 rounded-xl">
                    <div>
                      <div className="font-semibold text-foreground">Compact Mode</div>
                      <div className="text-sm text-muted-foreground">Reduce spacing and padding</div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={appearance.compactMode}
                        onChange={(e) => setAppearance({ ...appearance, compactMode: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-muted peer-focus:ring-2 peer-focus:ring-primary/50 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                    </label>
                  </div>

                  <button
                    onClick={handleSave}
                    className="w-full md:w-auto px-6 py-3 bg-primary text-primary-foreground rounded-xl font-semibold hover:scale-105 transition-all shadow-lg shadow-primary/30 flex items-center justify-center gap-2"
                  >
                    <Save className="w-5 h-5" />
                    Save Preferences
                  </button>
                </div>
              </div>
            )}

            {/* Billing */}
            {activeTab === 'billing' && (
              <div className="p-8">
                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-foreground mb-2">Billing & Subscription</h2>
                  <p className="text-sm text-muted-foreground">Manage your subscription and payment methods</p>
                </div>

                <div className="space-y-6">
                  {/* Current Plan */}
                  <div className="p-6 bg-gradient-to-br from-primary/10 to-transparent border-2 border-primary/20 rounded-2xl">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-bold text-foreground">Professional Plan</h3>
                        <p className="text-sm text-muted-foreground">Billed monthly</p>
                      </div>
                      <div className="text-right">
                        <div className="text-3xl font-bold text-foreground">€99</div>
                        <div className="text-sm text-muted-foreground">per month</div>
                      </div>
                    </div>

                    <div className="space-y-2 mb-4">
                      {[
                        'Unlimited campaigns',
                        'AI-powered insights',
                        'Priority support',
                        'Advanced analytics',
                      ].map((feature, i) => (
                        <div key={i} className="flex items-center gap-2 text-sm">
                          <Check className="w-4 h-4 text-primary" />
                          <span className="text-foreground">{feature}</span>
                        </div>
                      ))}
                    </div>

                    <div className="flex gap-3">
                      <button className="flex-1 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:scale-105 transition-all">
                        Upgrade Plan
                      </button>
                      <button className="flex-1 px-4 py-2.5 bg-muted hover:bg-muted/80 rounded-xl text-sm font-semibold transition-all">
                        View All Plans
                      </button>
                    </div>
                  </div>

                  {/* Payment Method */}
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-4">Payment Method</h3>
                    <div className="p-4 bg-muted/30 rounded-xl flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
                          <CreditCard className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <div className="font-semibold text-foreground">Visa •••• 4242</div>
                          <div className="text-sm text-muted-foreground">Expires 12/2025</div>
                        </div>
                      </div>
                      <button className="px-4 py-2 bg-muted hover:bg-muted/80 rounded-lg text-sm font-semibold transition-all">
                        Update
                      </button>
                    </div>
                  </div>

                  {/* Billing History */}
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-4">Billing History</h3>
                    <div className="space-y-3">
                      {[
                        { date: 'Jan 1, 2024', amount: '€99.00', status: 'Paid' },
                        { date: 'Dec 1, 2023', amount: '€99.00', status: 'Paid' },
                        { date: 'Nov 1, 2023', amount: '€99.00', status: 'Paid' },
                      ].map((invoice, i) => (
                        <div key={i} className="p-4 bg-muted/30 rounded-xl flex items-center justify-between">
                          <div>
                            <div className="font-semibold text-foreground">{invoice.date}</div>
                            <div className="text-sm text-muted-foreground">{invoice.amount}</div>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="px-3 py-1 bg-green-500/20 text-green-500 rounded-full text-xs font-semibold">
                              {invoice.status}
                            </span>
                            <button className="text-sm text-primary hover:underline flex items-center gap-1">
                              Download
                              <ExternalLink className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Security */}
            {activeTab === 'security' && (
              <div className="p-8">
                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-foreground mb-2">Security</h2>
                  <p className="text-sm text-muted-foreground">Manage your account security settings</p>
                </div>

                <div className="space-y-6">
                  {/* Change Password */}
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-4">Change Password</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-semibold text-foreground mb-2">Current Password</label>
                        <input
                          type="password"
                          placeholder="Enter current password"
                          className="w-full px-4 py-3 bg-muted/50 border border-border/50 rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-semibold text-foreground mb-2">New Password</label>
                        <input
                          type="password"
                          placeholder="Enter new password"
                          className="w-full px-4 py-3 bg-muted/50 border border-border/50 rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-semibold text-foreground mb-2">Confirm Password</label>
                        <input
                          type="password"
                          placeholder="Confirm new password"
                          className="w-full px-4 py-3 bg-muted/50 border border-border/50 rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                        />
                      </div>
                      <button className="px-6 py-3 bg-primary text-primary-foreground rounded-xl font-semibold hover:scale-105 transition-all shadow-lg shadow-primary/30">
                        Update Password
                      </button>
                    </div>
                  </div>

                  {/* Two-Factor Authentication */}
                  <div className="p-6 bg-muted/30 rounded-xl">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-lg font-semibold text-foreground mb-1">Two-Factor Authentication</h3>
                        <p className="text-sm text-muted-foreground">Add an extra layer of security to your account</p>
                      </div>
                      <span className="px-3 py-1 bg-red-500/20 text-red-500 rounded-full text-xs font-semibold">
                        Disabled
                      </span>
                    </div>
                    <button className="px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:scale-105 transition-all">
                      Enable 2FA
                    </button>
                  </div>

                  {/* Danger Zone */}
                  <div className="p-6 bg-red-500/5 border-2 border-red-500/20 rounded-2xl">
                    <div className="flex items-start gap-3 mb-4">
                      <AlertCircle className="w-6 h-6 text-red-500 flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="text-lg font-semibold text-foreground mb-1">Danger Zone</h3>
                        <p className="text-sm text-muted-foreground mb-4">
                          Once you delete your account, there is no going back. Please be certain.
                        </p>
                        <button className="px-4 py-2.5 bg-red-500/10 hover:bg-red-500/20 text-red-500 rounded-xl text-sm font-semibold transition-all flex items-center gap-2">
                          <Trash2 className="w-4 h-4" />
                          Delete Account
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </PageShell>
  );
}