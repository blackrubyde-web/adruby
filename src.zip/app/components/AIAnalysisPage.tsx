import { useState } from 'react';
import {
  Brain,
  ChevronDown,
  ChevronRight,
  Search,
  Filter,
  Download,
  RefreshCw,
  Trash2,
  Copy,
  TrendingUp,
  TrendingDown,
  Minus,
  Target,
  Eye,
  MousePointerClick,
  DollarSign,
  ShoppingCart,
  Zap,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Info,
  BarChart3,
  Sparkles,
  Activity,
  Users,
  Settings,
} from 'lucide-react';
import { toast } from 'sonner';
import { PageShell, HeroHeader, Card, Chip } from './layout';

type AIRecommendation = 'kill' | 'duplicate' | 'increase' | 'decrease';

interface AIAnalysis {
  id: string;
  recommendation: AIRecommendation;
  confidence: number;
  reason: string;
  expectedImpact: string;
  details: string[];
}

interface Ad {
  id: string;
  name: string;
  status: 'active' | 'paused' | 'learning';
  impressions: number;
  clicks: number;
  ctr: number;
  cpc: number;
  conversions: number;
  spend: number;
  revenue: number;
  roas: number;
  performanceScore: number;
  aiAnalysis: AIAnalysis;
  strategyId?: string;
}

interface AdSet {
  id: string;
  name: string;
  status: 'active' | 'paused' | 'learning';
  impressions: number;
  clicks: number;
  ctr: number;
  cpc: number;
  conversions: number;
  spend: number;
  revenue: number;
  roas: number;
  performanceScore: number;
  ads: Ad[];
  expanded?: boolean;
  strategyId?: string;
}

interface Campaign {
  id: string;
  name: string;
  status: 'active' | 'paused' | 'learning';
  impressions: number;
  clicks: number;
  ctr: number;
  cpc: number;
  conversions: number;
  spend: number;
  revenue: number;
  roas: number;
  performanceScore: number;
  adSets: AdSet[];
  expanded?: boolean;
  strategyId?: string;
}

interface Strategy {
  id: string;
  name: string;
  createdAt: string;
  targetAudience: string;
}

export function AIAnalysisPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'paused' | 'learning'>('all');
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [showAIPanel, setShowAIPanel] = useState(true);

  // Mock Strategies from Ad Strategy Builder
  const strategies: Strategy[] = [
    { id: 'strat-1', name: 'Summer Sale Strategy', createdAt: '2024-01-15', targetAudience: 'Women 25-40' },
    { id: 'strat-2', name: 'Product Launch Q1', createdAt: '2024-02-01', targetAudience: 'Tech Enthusiasts' },
    { id: 'strat-3', name: 'Black Friday Campaign', createdAt: '2024-03-10', targetAudience: 'All Demographics' },
    { id: 'strat-4', name: 'Retargeting Strategy', createdAt: '2024-03-15', targetAudience: 'Cart Abandoners' },
  ];

  // Mock Campaign Data (Facebook Ads Manager Style)
  const [campaigns, setCampaigns] = useState<Campaign[]>([
    {
      id: 'camp-1',
      name: 'Summer Sale 2024',
      status: 'active',
      impressions: 2456000,
      clicks: 68567,
      ctr: 2.79,
      cpc: 0.42,
      conversions: 1234,
      spend: 28798,
      revenue: 142340,
      roas: 4.94,
      performanceScore: 87,
      strategyId: 'strat-1',
      expanded: false,
      adSets: [
        {
          id: 'adset-1',
          name: 'Women 25-40 - Interests',
          status: 'active',
          impressions: 1234000,
          clicks: 34567,
          ctr: 2.8,
          cpc: 0.45,
          conversions: 678,
          spend: 15554,
          revenue: 78900,
          roas: 5.07,
          performanceScore: 92,
          strategyId: 'strat-1',
          expanded: false,
          ads: [
            {
              id: 'ad-1',
              name: 'Carousel Ad - Beach Collection',
              status: 'active',
              impressions: 567000,
              clicks: 18900,
              ctr: 3.33,
              cpc: 0.38,
              conversions: 389,
              spend: 7182,
              revenue: 45670,
              roas: 6.36,
              performanceScore: 95,
              strategyId: 'strat-1',
              aiAnalysis: {
                id: 'analysis-1',
                recommendation: 'duplicate',
                confidence: 94,
                reason: 'Exceptional ROAS (6.36x) and CTR (3.33%) - 82% above campaign average',
                expectedImpact: '+€38.2K revenue in 30 days',
                details: [
                  'CTR 82% above campaign average',
                  'ROAS 29% higher than target (4.9x)',
                  'Conversion rate trending +15% week-over-week',
                  'Low frequency (2.1) indicates fresh audience'
                ]
              }
            },
            {
              id: 'ad-2',
              name: 'Single Image - Discount Code',
              status: 'active',
              impressions: 445000,
              clicks: 11234,
              ctr: 2.52,
              cpc: 0.52,
              conversions: 201,
              spend: 5841,
              revenue: 24890,
              roas: 4.26,
              performanceScore: 78,
              strategyId: 'strat-1',
              aiAnalysis: {
                id: 'analysis-2',
                recommendation: 'increase',
                confidence: 87,
                reason: 'Steady performance with growth potential - increasing budget could scale linearly',
                expectedImpact: '+€12.1K revenue with +50% budget',
                details: [
                  'Consistent ROAS of 4.2x for 14 days',
                  'CPC stable at €0.52 (no auction saturation)',
                  'Audience size allows 3x scale without overlap',
                  'Learning phase completed successfully'
                ]
              }
            },
            {
              id: 'ad-3',
              name: 'Video Ad - Product Showcase',
              status: 'active',
              impressions: 222000,
              clicks: 4433,
              ctr: 2.0,
              cpc: 0.48,
              conversions: 88,
              spend: 2128,
              revenue: 8340,
              roas: 3.92,
              performanceScore: 71,
              strategyId: 'strat-1',
              aiAnalysis: {
                id: 'analysis-3',
                recommendation: 'decrease',
                confidence: 82,
                reason: 'Below-target ROAS (3.92x vs 4.9x) and declining engagement trend',
                expectedImpact: 'Save €850/month, reallocate to top performers',
                details: [
                  'ROAS 20% below campaign average',
                  'CTR declining -8% week-over-week',
                  'Video completion rate only 35% (target: 50%)',
                  'CPC increasing trend (+12% in 7 days)'
                ]
              }
            }
          ]
        },
        {
          id: 'adset-2',
          name: 'Lookalike 1% - Purchase',
          status: 'learning',
          impressions: 678000,
          clicks: 18900,
          ctr: 2.79,
          cpc: 0.41,
          conversions: 334,
          spend: 7749,
          revenue: 38940,
          roas: 5.02,
          performanceScore: 85,
          strategyId: 'strat-1',
          expanded: false,
          ads: [
            {
              id: 'ad-4',
              name: 'Dynamic Product Ads',
              status: 'learning',
              impressions: 378000,
              clicks: 10890,
              ctr: 2.88,
              cpc: 0.39,
              conversions: 198,
              spend: 4247,
              revenue: 22340,
              roas: 5.26,
              performanceScore: 88,
              aiAnalysis: {
                id: 'analysis-4',
                recommendation: 'increase',
                confidence: 91,
                reason: 'Strong early performance in learning phase - accelerating budget will exit learning faster',
                expectedImpact: '+€15.8K revenue after learning phase',
                details: [
                  'ROAS 7% above campaign average already',
                  'CTR improving +5% daily',
                  'Still in learning phase (Day 4 of 7)',
                  'Low cost per result indicates efficiency'
                ]
              }
            },
            {
              id: 'ad-5',
              name: 'Collection Ad - Full Catalog',
              status: 'learning',
              impressions: 300000,
              clicks: 8010,
              ctr: 2.67,
              cpc: 0.44,
              conversions: 136,
              spend: 3524,
              revenue: 16600,
              roas: 4.71,
              performanceScore: 81,
              aiAnalysis: {
                id: 'analysis-5',
                recommendation: 'increase',
                confidence: 79,
                reason: 'Moderate performance with upward trend - likely to improve post-learning',
                expectedImpact: '+€8.4K revenue potential',
                details: [
                  'ROAS trending upward (+18% in 3 days)',
                  'Collection format showing strong engagement',
                  'Product clicks improving daily',
                  'Exit learning in ~3 days'
                ]
              }
            }
          ]
        },
        {
          id: 'adset-3',
          name: 'Retargeting - 30 Days',
          status: 'paused',
          impressions: 544000,
          clicks: 15100,
          ctr: 2.78,
          cpc: 0.38,
          conversions: 222,
          spend: 5738,
          revenue: 24500,
          roas: 4.27,
          performanceScore: 76,
          expanded: false,
          ads: [
            {
              id: 'ad-6',
              name: 'Reminder - Cart Abandoners',
              status: 'paused',
              impressions: 544000,
              clicks: 15100,
              ctr: 2.78,
              cpc: 0.38,
              conversions: 222,
              spend: 5738,
              revenue: 24500,
              roas: 4.27,
              performanceScore: 76,
              aiAnalysis: {
                id: 'analysis-6',
                recommendation: 'kill',
                confidence: 88,
                reason: 'Audience exhausted with high frequency (6.8) and declining performance',
                expectedImpact: 'Prevent €2.1K wasted spend this month',
                details: [
                  'Frequency at 6.8 (optimal: 2-3)',
                  'CTR dropped 42% in last 7 days',
                  'Audience saturation reached',
                  'Better to create fresh retargeting ad'
                ]
              }
            }
          ]
        }
      ]
    },
    {
      id: 'camp-2',
      name: 'Product Launch - Smart Watch',
      status: 'active',
      impressions: 1234000,
      clicks: 34567,
      ctr: 2.8,
      cpc: 0.51,
      conversions: 567,
      spend: 17629,
      revenue: 68340,
      roas: 3.88,
      performanceScore: 74,
      strategyId: 'strat-2',
      expanded: false,
      adSets: [
        {
          id: 'adset-4',
          name: 'Tech Enthusiasts - Cold',
          status: 'active',
          impressions: 789000,
          clicks: 21890,
          ctr: 2.77,
          cpc: 0.49,
          conversions: 345,
          spend: 10726,
          revenue: 41670,
          roas: 3.88,
          performanceScore: 73,
          expanded: false,
          ads: [
            {
              id: 'ad-7',
              name: 'Video - Features Highlight',
              status: 'active',
              impressions: 456000,
              clicks: 12890,
              ctr: 2.83,
              cpc: 0.47,
              conversions: 201,
              spend: 6058,
              revenue: 24270,
              roas: 4.01,
              performanceScore: 78,
              strategyId: 'strat-2',
              aiAnalysis: {
                id: 'analysis-7',
                recommendation: 'duplicate',
                confidence: 86,
                reason: 'Best performer in campaign - strong creative engagement',
                expectedImpact: '+€24.2K monthly revenue',
                details: [
                  'Highest ROAS in campaign (4.01x)',
                  'Video watch time 68% (excellent)',
                  'Strong conversion rate 1.56%',
                  'Audience not saturated yet'
                ]
              }
            },
            {
              id: 'ad-8',
              name: 'Carousel - Use Cases',
              status: 'active',
              impressions: 333000,
              clicks: 9000,
              ctr: 2.7,
              cpc: 0.52,
              conversions: 144,
              spend: 4680,
              revenue: 17400,
              roas: 3.72,
              performanceScore: 68,
              strategyId: 'strat-2',
              aiAnalysis: {
                id: 'analysis-8',
                recommendation: 'kill',
                confidence: 91,
                reason: 'Underperforming with negative trend - better to reallocate budget',
                expectedImpact: 'Save €4.6K/month, prevent ROAS decline',
                details: [
                  'ROAS 24% below campaign average',
                  'CTR declining -15% weekly',
                  'CPC 16% higher than other ads',
                  'Poor carousel swipe-through rate (12%)'
                ]
              }
            }
          ]
        }
      ]
    }
  ]);

  // AI Recommendation Colors & Icons
  const getRecommendationStyle = (rec: AIRecommendation) => {
    switch (rec) {
      case 'kill':
        return {
          color: '#ef4444',
          bg: 'bg-red-500/10',
          border: 'border-red-500/30',
          icon: <Trash2 className="w-4 h-4" />,
          label: 'Kill Ad',
          actionLabel: 'Pause Ad'
        };
      case 'duplicate':
        return {
          color: '#10b981',
          bg: 'bg-green-500/10',
          border: 'border-green-500/30',
          icon: <Copy className="w-4 h-4" />,
          label: 'Duplicate Ad',
          actionLabel: 'Duplicate'
        };
      case 'increase':
        return {
          color: '#3b82f6',
          bg: 'bg-blue-500/10',
          border: 'border-blue-500/30',
          icon: <TrendingUp className="w-4 h-4" />,
          label: 'Increase Budget',
          actionLabel: 'Increase +50%'
        };
      case 'decrease':
        return {
          color: '#f59e0b',
          bg: 'bg-orange-500/10',
          border: 'border-orange-500/30',
          icon: <TrendingDown className="w-4 h-4" />,
          label: 'Decrease Budget',
          actionLabel: 'Decrease -30%'
        };
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-500 bg-green-500/20';
      case 'paused': return 'text-orange-500 bg-orange-500/20';
      case 'learning': return 'text-blue-500 bg-blue-500/20';
      default: return 'text-muted-foreground bg-muted/20';
    }
  };

  const getPerformanceColor = (score: number) => {
    if (score >= 85) return 'text-green-500';
    if (score >= 70) return 'text-blue-500';
    if (score >= 50) return 'text-orange-500';
    return 'text-red-500';
  };

  const toggleCampaign = (campaignId: string) => {
    setCampaigns(campaigns.map(c =>
      c.id === campaignId ? { ...c, expanded: !c.expanded } : c
    ));
  };

  const toggleAdSet = (campaignId: string, adSetId: string) => {
    setCampaigns(campaigns.map(c =>
      c.id === campaignId
        ? {
            ...c,
            adSets: c.adSets.map(as =>
              as.id === adSetId ? { ...as, expanded: !as.expanded } : as
            )
          }
        : c
    ));
  };

  const handleStrategyChange = (itemId: string, strategyId: string, level: 'campaign' | 'adset' | 'ad') => {
    toast.success(`Strategy updated for ${level}`);
    // Update strategy in state
  };

  const handleAIAction = (action: string, itemName: string) => {
    toast.success(`${action} applied to: ${itemName}`);
  };

  // Get all AI recommendations for the panel
  const getAllRecommendations = () => {
    const recommendations: { ad: Ad; campaign: string; adSet: string }[] = [];
    campaigns.forEach(campaign => {
      campaign.adSets.forEach(adSet => {
        adSet.ads.forEach(ad => {
          recommendations.push({ ad, campaign: campaign.name, adSet: adSet.name });
        });
      });
    });
    return recommendations;
  };

  const allRecommendations = getAllRecommendations();
  const killAds = allRecommendations.filter(r => r.ad.aiAnalysis.recommendation === 'kill');
  const duplicateAds = allRecommendations.filter(r => r.ad.aiAnalysis.recommendation === 'duplicate');
  const increaseAds = allRecommendations.filter(r => r.ad.aiAnalysis.recommendation === 'increase');
  const decreaseAds = allRecommendations.filter(r => r.ad.aiAnalysis.recommendation === 'decrease');

  return (
    <PageShell>
      <HeroHeader
        title="AI Campaign Analysis"
        subtitle={`AI-powered insights analyzing ${campaigns.length} campaigns, ${campaigns.reduce((acc, c) => acc + c.adSets.length, 0)} ad sets, and ${campaigns.reduce((acc, c) => acc + c.adSets.reduce((a, s) => a + s.ads.length, 0), 0)} ads`}
        chips={
          <>
            <Chip>€{(campaigns.reduce((acc, c) => acc + c.spend, 0) / 1000).toFixed(1)}K Spend</Chip>
            <Chip>€{(campaigns.reduce((acc, c) => acc + c.revenue, 0) / 1000).toFixed(1)}K Revenue</Chip>
            <Chip>{(campaigns.reduce((acc, c) => acc + c.revenue, 0) / campaigns.reduce((acc, c) => acc + c.spend, 0)).toFixed(2)}x ROAS</Chip>
            <Chip>{allRecommendations.length} AI Insights</Chip>
          </>
        }
        actions={
          <>
            <button className="px-4 py-2.5 bg-muted hover:bg-muted/80 rounded-xl font-semibold transition-all flex items-center gap-2">
              <RefreshCw className="w-4 h-4" />
              <span className="text-sm font-medium">Sync Data</span>
            </button>
            <button className="px-6 py-3 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground rounded-xl hover:scale-105 transition-all duration-300 shadow-lg shadow-primary/30 flex items-center gap-2">
              <Download className="w-4 h-4" />
              <span>Export Report</span>
            </button>
          </>
        }
      />

      {/* FIX 1: Outer Layout - Responsive Stack (NO calc!) */}
      <div className="flex flex-col lg:flex-row gap-4 lg:gap-6 w-full max-w-[100vw] overflow-x-hidden">
        {/* Main Content Area */}
        <div className="flex-1 min-w-0">
          {/* FIX 2: Filters - Mobile Wrap + Full Width Controls */}
          <Card className="p-4 mb-6">
            <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4 min-w-0">
              <div className="flex-1 relative min-w-0">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search campaigns, ad sets, or ads..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full max-w-full pl-10 pr-4 py-2.5 bg-muted/50 border border-border/50 rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
              </div>

              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="w-full sm:w-auto px-4 py-2.5 bg-muted/50 border border-border/50 rounded-xl text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
              >
                <option value="all">All Status</option>
                <option value="active">Active</option>
                <option value="paused">Paused</option>
                <option value="learning">Learning</option>
              </select>

              <button
                onClick={() => setShowAIPanel(!showAIPanel)}
                className={`w-full sm:w-auto px-4 py-2.5 rounded-xl font-semibold transition-all flex items-center justify-center gap-2 ${
                  showAIPanel
                    ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/30'
                    : 'bg-muted hover:bg-muted/80'
                }`}
              >
                <Brain className="w-5 h-5" />
                AI Panel
              </button>
            </div>
          </Card>

          {/* FIX 4A: Desktop Table - Hidden on Mobile */}
          <Card className="hidden lg:block overflow-hidden p-0">
            {/* Table Header */}
            <div className="bg-muted/30 border-b border-border/30 p-4">
              <div className="grid grid-cols-12 gap-4 text-sm font-semibold text-muted-foreground">
                <div className="col-span-3">Campaign / Ad Set / Ad</div>
                <div className="col-span-1 text-center">Status</div>
                <div className="col-span-1 text-right">Impressions</div>
                <div className="col-span-1 text-right">CTR</div>
                <div className="col-span-1 text-right">CPC</div>
                <div className="col-span-1 text-right">Conv.</div>
                <div className="col-span-1 text-right">Spend</div>
                <div className="col-span-1 text-right">ROAS</div>
                <div className="col-span-1 text-center">Score</div>
                <div className="col-span-1 text-center">Strategy</div>
              </div>
            </div>

            {/* Campaign Rows */}
            <div className="divide-y divide-border/30">
              {campaigns.map((campaign) => (
                <div key={campaign.id}>
                  {/* Campaign Row */}
                  <div className="hover:bg-muted/20 transition-colors">
                    <div className="p-4">
                      <div className="grid grid-cols-12 gap-4 items-center text-sm">
                        <div className="col-span-3 flex items-center gap-2">
                          <button
                            onClick={() => toggleCampaign(campaign.id)}
                            className="p-1 hover:bg-muted/50 rounded transition-colors"
                          >
                            {campaign.expanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                          </button>
                          <Target className="w-4 h-4 text-primary" />
                          <span className="font-semibold text-foreground">{campaign.name}</span>
                        </div>
                        <div className="col-span-1 flex justify-center">
                          <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusColor(campaign.status)}`}>
                            {campaign.status}
                          </span>
                        </div>
                        <div className="col-span-1 text-right font-mono text-foreground">{(campaign.impressions / 1000000).toFixed(2)}M</div>
                        <div className="col-span-1 text-right font-mono text-foreground">{campaign.ctr.toFixed(2)}%</div>
                        <div className="col-span-1 text-right font-mono text-foreground">€{campaign.cpc.toFixed(2)}</div>
                        <div className="col-span-1 text-right font-mono text-foreground">{campaign.conversions}</div>
                        <div className="col-span-1 text-right font-mono text-foreground">€{(campaign.spend / 1000).toFixed(1)}K</div>
                        <div className="col-span-1 text-right font-mono font-bold text-foreground">{campaign.roas.toFixed(2)}x</div>
                        <div className="col-span-1 flex justify-center">
                          <span className={`font-bold ${getPerformanceColor(campaign.performanceScore)}`}>
                            {campaign.performanceScore}
                          </span>
                        </div>
                        <div className="col-span-1 flex justify-center">
                          <select
                            value={campaign.strategyId || ''}
                            onChange={(e) => handleStrategyChange(campaign.id, e.target.value, 'campaign')}
                            className="px-2 py-1 bg-muted/50 border border-border/50 rounded text-xs focus:outline-none focus:ring-1 focus:ring-primary/50"
                          >
                            <option value="">No Strategy</option>
                            {strategies.map(s => (
                              <option key={s.id} value={s.id}>{s.name}</option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Ad Sets (if expanded) */}
                  {campaign.expanded && campaign.adSets.map((adSet) => (
                    <div key={adSet.id}>
                      <div className="bg-muted/10 hover:bg-muted/20 transition-colors">
                        <div className="p-4 pl-12">
                          <div className="grid grid-cols-12 gap-4 items-center text-sm">
                            <div className="col-span-3 flex items-center gap-2">
                              <button
                                onClick={() => toggleAdSet(campaign.id, adSet.id)}
                                className="p-1 hover:bg-muted/50 rounded transition-colors"
                              >
                                {adSet.expanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                              </button>
                              <Users className="w-4 h-4 text-blue-500" />
                              <span className="font-medium text-foreground">{adSet.name}</span>
                            </div>
                            <div className="col-span-1 flex justify-center">
                              <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusColor(adSet.status)}`}>
                                {adSet.status}
                              </span>
                            </div>
                            <div className="col-span-1 text-right font-mono text-muted-foreground">{(adSet.impressions / 1000000).toFixed(2)}M</div>
                            <div className="col-span-1 text-right font-mono text-muted-foreground">{adSet.ctr.toFixed(2)}%</div>
                            <div className="col-span-1 text-right font-mono text-muted-foreground">€{adSet.cpc.toFixed(2)}</div>
                            <div className="col-span-1 text-right font-mono text-muted-foreground">{adSet.conversions}</div>
                            <div className="col-span-1 text-right font-mono text-muted-foreground">€{(adSet.spend / 1000).toFixed(1)}K</div>
                            <div className="col-span-1 text-right font-mono font-bold text-muted-foreground">{adSet.roas.toFixed(2)}x</div>
                            <div className="col-span-1 flex justify-center">
                              <span className={`font-bold ${getPerformanceColor(adSet.performanceScore)}`}>
                                {adSet.performanceScore}
                              </span>
                            </div>
                            <div className="col-span-1 flex justify-center">
                              <select
                                value={adSet.strategyId || campaign.strategyId || ''}
                                onChange={(e) => handleStrategyChange(adSet.id, e.target.value, 'adset')}
                                className="px-2 py-1 bg-muted/50 border border-border/50 rounded text-xs focus:outline-none focus:ring-1 focus:ring-primary/50"
                              >
                                <option value="">Inherit</option>
                                {strategies.map(s => (
                                  <option key={s.id} value={s.id}>{s.name}</option>
                                ))}
                              </select>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Ads (if expanded) */}
                      {adSet.expanded && adSet.ads.map((ad) => {
                        const recStyle = getRecommendationStyle(ad.aiAnalysis.recommendation);
                        
                        return (
                          <div key={ad.id} className="bg-muted/5 hover:bg-muted/15 transition-colors border-l-4" style={{ borderColor: recStyle.color }}>
                            <div className="p-4 pl-20">
                              <div className="grid grid-cols-12 gap-4 items-center text-sm">
                                <div className="col-span-3 flex items-center gap-2">
                                  <Activity className="w-4 h-4 text-green-500" />
                                  <span className="text-foreground">{ad.name}</span>
                                  <div className={`px-2 py-1 rounded-full text-xs font-semibold flex items-center gap-1 ${recStyle.bg} border ${recStyle.border}`} style={{ color: recStyle.color }}>
                                    {recStyle.icon}
                                    {recStyle.label}
                                  </div>
                                </div>
                                <div className="col-span-1 flex justify-center">
                                  <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusColor(ad.status)}`}>
                                    {ad.status}
                                  </span>
                                </div>
                                <div className="col-span-1 text-right font-mono text-muted-foreground">{(ad.impressions / 1000).toFixed(0)}K</div>
                                <div className="col-span-1 text-right font-mono text-muted-foreground">{ad.ctr.toFixed(2)}%</div>
                                <div className="col-span-1 text-right font-mono text-muted-foreground">€{ad.cpc.toFixed(2)}</div>
                                <div className="col-span-1 text-right font-mono text-muted-foreground">{ad.conversions}</div>
                                <div className="col-span-1 text-right font-mono text-muted-foreground">€{(ad.spend / 1000).toFixed(1)}K</div>
                                <div className="col-span-1 text-right font-mono font-bold text-muted-foreground">{ad.roas.toFixed(2)}x</div>
                                <div className="col-span-1 flex justify-center">
                                  <span className={`font-bold ${getPerformanceColor(ad.performanceScore)}`}>
                                    {ad.performanceScore}
                                  </span>
                                </div>
                                <div className="col-span-1 flex justify-center">
                                  <select
                                    value={ad.strategyId || adSet.strategyId || campaign.strategyId || ''}
                                    onChange={(e) => handleStrategyChange(ad.id, e.target.value, 'ad')}
                                    className="px-2 py-1 bg-muted/50 border border-border/50 rounded text-xs focus:outline-none focus:ring-1 focus:ring-primary/50"
                                  >
                                    <option value="">Inherit</option>
                                    {strategies.map(s => (
                                      <option key={s.id} value={s.id}>{s.name}</option>
                                    ))}
                                  </select>
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </Card>

          {/* FIX 4B: Mobile Card View */}
          <div className="lg:hidden space-y-3">
            {campaigns.map((campaign) => (
              <Card key={campaign.id} className="overflow-hidden p-0">
                <div className="p-4">
                  <div className="flex items-start gap-3 min-w-0">
                    <button
                      onClick={() => toggleCampaign(campaign.id)}
                      className="p-1 hover:bg-muted/50 rounded shrink-0"
                    >
                      {campaign.expanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                    </button>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 min-w-0">
                        <Target className="w-4 h-4 text-primary shrink-0" />
                        <div className="font-semibold text-foreground truncate">{campaign.name}</div>
                      </div>

                      <div className="mt-2 flex flex-wrap gap-2">
                        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusColor(campaign.status)}`}>
                          {campaign.status}
                        </span>
                        <span className="text-xs text-muted-foreground">Impr: <span className="text-foreground font-mono">{(campaign.impressions/1000000).toFixed(2)}M</span></span>
                        <span className="text-xs text-muted-foreground">CTR: <span className="text-foreground font-mono">{campaign.ctr.toFixed(2)}%</span></span>
                        <span className="text-xs text-muted-foreground">ROAS: <span className="text-foreground font-mono font-bold">{campaign.roas.toFixed(2)}x</span></span>
                        <span className="text-xs text-muted-foreground">Spend: <span className="text-foreground font-mono">€{(campaign.spend/1000).toFixed(1)}K</span></span>
                      </div>

                      <div className="mt-3">
                        <select
                          value={campaign.strategyId || ''}
                          onChange={(e) => handleStrategyChange(campaign.id, e.target.value, 'campaign')}
                          className="w-full px-3 py-2 bg-muted/50 border border-border/50 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-primary/50"
                        >
                          <option value="">No Strategy</option>
                          {strategies.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                        </select>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Expanded: AdSets/Ads as Cards */}
                {campaign.expanded && (
                  <div className="border-t border-border/30">
                    {campaign.adSets.map((adSet) => (
                      <div key={adSet.id} className="p-4 border-b border-border/20">
                        <div className="flex items-start gap-3 min-w-0">
                          <button
                            onClick={() => toggleAdSet(campaign.id, adSet.id)}
                            className="p-1 hover:bg-muted/50 rounded shrink-0"
                          >
                            {adSet.expanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                          </button>

                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2 min-w-0">
                              <Users className="w-4 h-4 text-blue-500 shrink-0" />
                              <div className="font-medium text-foreground truncate">{adSet.name}</div>
                            </div>

                            <div className="mt-2 flex flex-wrap gap-2">
                              <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusColor(adSet.status)}`}>
                                {adSet.status}
                              </span>
                              <span className="text-xs text-muted-foreground">ROAS: <span className="text-foreground font-mono font-bold">{adSet.roas.toFixed(2)}x</span></span>
                              <span className="text-xs text-muted-foreground">Spend: <span className="text-foreground font-mono">€{(adSet.spend/1000).toFixed(1)}K</span></span>
                            </div>

                            <div className="mt-3">
                              <select
                                value={adSet.strategyId || campaign.strategyId || ''}
                                onChange={(e) => handleStrategyChange(adSet.id, e.target.value, 'adset')}
                                className="w-full px-3 py-2 bg-muted/50 border border-border/50 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-primary/50"
                              >
                                <option value="">Inherit</option>
                                {strategies.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                              </select>
                            </div>

                            {adSet.expanded && (
                              <div className="mt-3 space-y-2">
                                {adSet.ads.map((ad) => {
                                  const recStyle = getRecommendationStyle(ad.aiAnalysis.recommendation);
                                  return (
                                    <div key={ad.id} className="rounded-xl border border-border/40 bg-muted/10 p-3">
                                      <div className="flex items-start gap-2 min-w-0">
                                        <Activity className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                                        <div className="min-w-0 flex-1">
                                          <div className="font-medium text-foreground truncate">{ad.name}</div>
                                          <div className="mt-1 flex flex-wrap gap-2 text-xs">
                                            <span className={`px-2 py-1 rounded-full ${getStatusColor(ad.status)}`}>{ad.status}</span>
                                            <span className="text-muted-foreground">CTR <span className="text-foreground font-mono">{ad.ctr.toFixed(2)}%</span></span>
                                            <span className="text-muted-foreground">ROAS <span className="text-foreground font-mono font-bold">{ad.roas.toFixed(2)}x</span></span>
                                          </div>
                                          <div className="mt-2">
                                            <select
                                              value={ad.strategyId || adSet.strategyId || campaign.strategyId || ''}
                                              onChange={(e) => handleStrategyChange(ad.id, e.target.value, 'ad')}
                                              className="w-full px-3 py-2 bg-muted/50 border border-border/50 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-primary/50"
                                            >
                                              <option value="">Inherit</option>
                                              {strategies.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                                            </select>
                                          </div>
                                        </div>

                                        <div className="shrink-0">
                                          <span className={`text-xs font-semibold px-2 py-1 rounded-full border ${recStyle.border} ${recStyle.bg}`} style={{ color: recStyle.color }}>
                                            {recStyle.label}
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </Card>
            ))}
          </div>
        </div>

        {/* FIX 3: AI Panel - Mobile Accordion, Desktop Sidebar */}
        {showAIPanel && (
          <>
            {/* Mobile: Collapsible Accordion */}
            <div className="lg:hidden mt-4 w-full max-w-full min-w-0">
              <Card className="overflow-hidden p-0">
                <details className="overflow-hidden">
                <summary className="px-4 py-3 cursor-pointer flex items-center justify-between">
                  <span className="font-semibold text-foreground flex items-center gap-2">
                    <Brain className="w-5 h-5 text-primary" />
                    AI Recommendations
                  </span>
                  <span className="text-xs text-muted-foreground">Tap to view</span>
                </summary>
                <div className="p-4 border-t border-border/30 space-y-4">
                  {/* Panel Content - Summary Cards */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="backdrop-blur-xl bg-red-500/10 rounded-xl border border-red-500/30 p-4">
                      <div className="flex items-center justify-between mb-2">
                        <Trash2 className="w-5 h-5 text-red-500" />
                        <span className="text-2xl font-bold text-red-500">{killAds.length}</span>
                      </div>
                      <div className="text-xs font-semibold text-red-500">Kill Ads</div>
                    </div>

                    <div className="backdrop-blur-xl bg-green-500/10 rounded-xl border border-green-500/30 p-4">
                      <div className="flex items-center justify-between mb-2">
                        <Copy className="w-5 h-5 text-green-500" />
                        <span className="text-2xl font-bold text-green-500">{duplicateAds.length}</span>
                      </div>
                      <div className="text-xs font-semibold text-green-500">Duplicate</div>
                    </div>

                    <div className="backdrop-blur-xl bg-blue-500/10 rounded-xl border border-blue-500/30 p-4">
                      <div className="flex items-center justify-between mb-2">
                        <TrendingUp className="w-5 h-5 text-blue-500" />
                        <span className="text-2xl font-bold text-blue-500">{increaseAds.length}</span>
                      </div>
                      <div className="text-xs font-semibold text-blue-500">Increase</div>
                    </div>

                    <div className="backdrop-blur-xl bg-orange-500/10 rounded-xl border border-orange-500/30 p-4">
                      <div className="flex items-center justify-between mb-2">
                        <TrendingDown className="w-5 h-5 text-orange-500" />
                        <span className="text-2xl font-bold text-orange-500">{decreaseAds.length}</span>
                      </div>
                      <div className="text-xs font-semibold text-orange-500">Decrease</div>
                    </div>
                  </div>

                  {/* Recommendations List */}
                  <div className="space-y-3">
                    {allRecommendations.map(({ ad, campaign, adSet }) => {
                      const recStyle = getRecommendationStyle(ad.aiAnalysis.recommendation);
                      
                      return (
                        <div
                          key={ad.id}
                          className={`backdrop-blur-xl bg-card/60 rounded-xl border-2 ${recStyle.border} shadow-xl overflow-hidden`}
                        >
                          <div className="p-4">
                            {/* Header */}
                            <div className="flex items-start gap-3 mb-3">
                              <div className={`p-2 ${recStyle.bg} rounded-lg flex-shrink-0`} style={{ color: recStyle.color }}>
                                {recStyle.icon}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="font-bold text-foreground text-sm mb-1 truncate">{ad.name}</div>
                                <div className="text-xs text-muted-foreground truncate">
                                  {campaign} → {adSet}
                                </div>
                              </div>
                            </div>

                            {/* Recommendation */}
                            <div className="mb-3">
                              <div className="text-xs font-semibold mb-1" style={{ color: recStyle.color }}>
                                {recStyle.label}
                              </div>
                              <div className="text-xs text-muted-foreground leading-relaxed">
                                {ad.aiAnalysis.reason}
                              </div>
                            </div>

                            {/* Impact */}
                            <div className="mb-3 p-2 bg-muted/30 rounded-lg">
                              <div className="text-xs text-muted-foreground mb-1">Expected Impact</div>
                              <div className="text-sm font-bold text-foreground">{ad.aiAnalysis.expectedImpact}</div>
                            </div>

                            {/* Confidence */}
                            <div className="mb-3">
                              <div className="flex items-center justify-between text-xs mb-1">
                                <span className="text-muted-foreground">AI Confidence</span>
                                <span className="font-bold" style={{ color: recStyle.color }}>{ad.aiAnalysis.confidence}%</span>
                              </div>
                              <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                                <div
                                  className="h-full rounded-full transition-all duration-1000"
                                  style={{
                                    width: `${ad.aiAnalysis.confidence}%`,
                                    backgroundColor: recStyle.color
                                  }}
                                />
                              </div>
                            </div>

                            {/* Details */}
                            <div className="mb-3 space-y-1">
                              {ad.aiAnalysis.details.slice(0, 2).map((detail, idx) => (
                                <div key={idx} className="flex items-start gap-1 text-xs text-muted-foreground">
                                  <CheckCircle2 className="w-3 h-3 flex-shrink-0 mt-0.5" style={{ color: recStyle.color }} />
                                  <span className="leading-tight">{detail}</span>
                                </div>
                              ))}
                            </div>

                            {/* Action Button */}
                            <button
                              onClick={() => handleAIAction(recStyle.actionLabel, ad.name)}
                              className={`w-full px-4 py-2 rounded-lg font-semibold text-sm transition-all shadow-lg`}
                              style={{
                                backgroundColor: recStyle.color,
                                color: 'white'
                              }}
                            >
                              {recStyle.actionLabel}
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </details>
              </Card>
            </div>

            {/* Desktop: Sidebar (unchanged) */}
            <div className="hidden lg:block w-[380px] flex-shrink-0 space-y-4 sticky top-24 h-fit max-h-[calc(100vh-8rem)] overflow-y-auto">
            {/* Panel Header */}
            <Card className="bg-gradient-to-br from-primary/10 to-card border-primary/30 p-6">
              <div className="flex items-center gap-3 mb-3">
                <div className="p-3 bg-primary/20 rounded-xl">
                  <Brain className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold text-foreground">AI Recommendations</h3>
                  <p className="text-xs text-muted-foreground">Real-time analysis</p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                <span className="text-muted-foreground">Updated 30 seconds ago</span>
              </div>
            </Card>

            {/* Summary Cards */}
            <div className="grid grid-cols-2 gap-3">
              <div className="backdrop-blur-xl bg-red-500/10 rounded-xl border border-red-500/30 p-4">
                <div className="flex items-center justify-between mb-2">
                  <Trash2 className="w-5 h-5 text-red-500" />
                  <span className="text-2xl font-bold text-red-500">{killAds.length}</span>
                </div>
                <div className="text-xs font-semibold text-red-500">Kill Ads</div>
              </div>

              <div className="backdrop-blur-xl bg-green-500/10 rounded-xl border border-green-500/30 p-4">
                <div className="flex items-center justify-between mb-2">
                  <Copy className="w-5 h-5 text-green-500" />
                  <span className="text-2xl font-bold text-green-500">{duplicateAds.length}</span>
                </div>
                <div className="text-xs font-semibold text-green-500">Duplicate</div>
              </div>

              <div className="backdrop-blur-xl bg-blue-500/10 rounded-xl border border-blue-500/30 p-4">
                <div className="flex items-center justify-between mb-2">
                  <TrendingUp className="w-5 h-5 text-blue-500" />
                  <span className="text-2xl font-bold text-blue-500">{increaseAds.length}</span>
                </div>
                <div className="text-xs font-semibold text-blue-500">Increase</div>
              </div>

              <div className="backdrop-blur-xl bg-orange-500/10 rounded-xl border border-orange-500/30 p-4">
                <div className="flex items-center justify-between mb-2">
                  <TrendingDown className="w-5 h-5 text-orange-500" />
                  <span className="text-2xl font-bold text-orange-500">{decreaseAds.length}</span>
                </div>
                <div className="text-xs font-semibold text-orange-500">Decrease</div>
              </div>
            </div>

            {/* Recommendations List */}
            <div className="space-y-3">
              {allRecommendations.map(({ ad, campaign, adSet }) => {
                const recStyle = getRecommendationStyle(ad.aiAnalysis.recommendation);
                
                return (
                  <Card
                    key={ad.id}
                    className={`border-2 ${recStyle.border} overflow-hidden hover:scale-105 transition-all p-0`}
                  >
                    <div className="p-4">
                      {/* Header */}
                      <div className="flex items-start gap-3 mb-3">
                        <div className={`p-2 ${recStyle.bg} rounded-lg flex-shrink-0`} style={{ color: recStyle.color }}>
                          {recStyle.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-bold text-foreground text-sm mb-1 truncate">{ad.name}</div>
                          <div className="text-xs text-muted-foreground truncate">
                            {campaign} → {adSet}
                          </div>
                        </div>
                      </div>

                      {/* Recommendation */}
                      <div className="mb-3">
                        <div className="text-xs font-semibold mb-1" style={{ color: recStyle.color }}>
                          {recStyle.label}
                        </div>
                        <div className="text-xs text-muted-foreground leading-relaxed">
                          {ad.aiAnalysis.reason}
                        </div>
                      </div>

                      {/* Impact */}
                      <div className="mb-3 p-2 bg-muted/30 rounded-lg">
                        <div className="text-xs text-muted-foreground mb-1">Expected Impact</div>
                        <div className="text-sm font-bold text-foreground">{ad.aiAnalysis.expectedImpact}</div>
                      </div>

                      {/* Confidence */}
                      <div className="mb-3">
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="text-muted-foreground">AI Confidence</span>
                          <span className="font-bold" style={{ color: recStyle.color }}>{ad.aiAnalysis.confidence}%</span>
                        </div>
                        <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-1000"
                            style={{
                              width: `${ad.aiAnalysis.confidence}%`,
                              backgroundColor: recStyle.color
                            }}
                          />
                        </div>
                      </div>

                      {/* Details */}
                      <div className="mb-3 space-y-1">
                        {ad.aiAnalysis.details.slice(0, 2).map((detail, idx) => (
                          <div key={idx} className="flex items-start gap-1 text-xs text-muted-foreground">
                            <CheckCircle2 className="w-3 h-3 flex-shrink-0 mt-0.5" style={{ color: recStyle.color }} />
                            <span className="leading-tight">{detail}</span>
                          </div>
                        ))}
                      </div>

                      {/* Action Button */}
                      <button
                        onClick={() => handleAIAction(recStyle.actionLabel, ad.name)}
                        className={`w-full px-4 py-2 rounded-lg font-semibold text-sm transition-all hover:scale-105 shadow-lg`}
                        style={{
                          backgroundColor: recStyle.color,
                          color: 'white'
                        }}
                      >
                        {recStyle.actionLabel}
                      </button>
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>
        </>
        )}
      </div>
    </PageShell>
  );
}