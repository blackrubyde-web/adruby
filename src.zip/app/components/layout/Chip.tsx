export function Chip({ children }: { children: React.ReactNode }) {
  return (
    <span className="px-3 py-1.5 rounded-full text-xs font-medium border border-border/60 bg-background/50">
      {children}
    </span>
  );
}
