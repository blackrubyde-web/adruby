import { useState, useEffect } from 'react';
import { Loader2, Sparkles, CheckCircle, XCircle, Home, LogOut } from 'lucide-react';

interface PaymentVerificationPageProps {
  sessionId?: string;
  onVerificationSuccess: () => void;
  onVerificationError?: () => void;
  onGoHome?: () => void;
  onLogout?: () => void;
}

export function PaymentVerificationPage({
  sessionId,
  onVerificationSuccess,
  onVerificationError,
  onGoHome,
  onLogout,
}: PaymentVerificationPageProps) {
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [message, setMessage] = useState('Verifying your payment...');

  useEffect(() => {
    // Simulate verification process
    const verify = async () => {
      try {
        // If there's a sessionId, verify it
        if (sessionId) {
          // Call your verification API here
          // const result = await verifyPayment(sessionId);
          
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 2000));
          
          // Simulate success (you'll replace this with actual API response)
          const isSuccess = true; // Replace with: result.success
          
          if (isSuccess) {
            setStatus('success');
            setMessage('Payment verified successfully!');
            setTimeout(() => {
              onVerificationSuccess();
            }, 1500);
          } else {
            throw new Error('Payment verification failed');
          }
        } else {
          // No session ID, check DB flag
          // const dbCheck = await checkUserPaymentStatus();
          
          // Simulate DB check
          await new Promise(resolve => setTimeout(resolve, 1500));
          
          // Simulate result
          const isPaid = false; // Replace with: dbCheck.isPaid
          
          if (isPaid) {
            setStatus('success');
            setMessage('Account verified!');
            setTimeout(() => {
              onVerificationSuccess();
            }, 1500);
          } else {
            throw new Error('Payment required');
          }
        }
      } catch (error) {
        setStatus('error');
        setMessage('Payment verification failed');
        if (onVerificationError) {
          onVerificationError();
        }
      }
    };

    verify();
  }, [sessionId, onVerificationSuccess, onVerificationError]);

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background px-4">
      <div className="text-center max-w-md">
        {/* Logo */}
        <div className="flex items-center justify-center gap-2 mb-12">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-red-600 flex items-center justify-center">
            <Sparkles className="w-7 h-7 text-white" />
          </div>
          <span className="font-bold text-2xl">AdRuby</span>
        </div>

        {/* Status Icon */}
        <div className="mb-8 flex items-center justify-center">
          {status === 'loading' && (
            <Loader2 className="w-16 h-16 text-primary animate-spin" />
          )}
          {status === 'success' && (
            <div className="relative">
              <CheckCircle className="w-16 h-16 text-green-600 animate-pulse" />
              <div className="absolute inset-0 bg-green-600/20 rounded-full animate-ping" />
            </div>
          )}
          {status === 'error' && (
            <XCircle className="w-16 h-16 text-red-600 animate-pulse" />
          )}
        </div>

        {/* Message */}
        <h2 className="text-2xl font-bold mb-4">
          {status === 'loading' && 'Verifying Payment'}
          {status === 'success' && 'Verification Complete!'}
          {status === 'error' && 'Verification Failed'}
        </h2>
        <p className="text-muted-foreground mb-8">
          {message}
        </p>

        {/* Loading Progress */}
        {status === 'loading' && (
          <div className="w-full max-w-xs mx-auto">
            <div className="h-2 bg-muted rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-primary to-red-600 rounded-full animate-pulse" />
            </div>
          </div>
        )}

        {/* Error Actions */}
        {status === 'error' && (
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-8">
            {onGoHome && (
              <button
                onClick={onGoHome}
                className="w-full sm:w-auto px-6 py-3 border-2 border-border rounded-xl font-medium hover:bg-accent transition-colors flex items-center justify-center gap-2"
              >
                <Home className="w-5 h-5" />
                Go Home
              </button>
            )}
            {onLogout && (
              <button
                onClick={onLogout}
                className="w-full sm:w-auto px-6 py-3 bg-primary text-white rounded-xl font-medium hover:bg-primary/90 transition-colors flex items-center justify-center gap-2"
              >
                <LogOut className="w-5 h-5" />
                Logout
              </button>
            )}
          </div>
        )}

        {/* Success Message */}
        {status === 'success' && (
          <div className="mt-8 p-4 bg-green-500/10 border border-green-500/20 rounded-xl">
            <p className="text-sm text-green-600">
              Redirecting you to your dashboard...
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
