import { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { AdMetricsCard } from './components/AdMetricsCard';
import { PerformanceChart } from './components/PerformanceChart';
import { AudienceBreakdown } from './components/AudienceBreakdown';
import { CampaignsTable } from './components/CampaignsTable';
import { StrategyInsights } from './components/StrategyInsights';
import { AdBuilderPage } from './components/AdBuilderPage';
import { AnalyticsPage } from './components/AnalyticsPage';
import { AdsStrategiesPage } from './components/AdsStrategiesPage';
import { CampaignsPage } from './components/CampaignsPage';
import { AIAnalysisPage } from './components/AIAnalysisPage';
import { SettingsPage } from './components/SettingsPage';
import { AffiliatePage } from './components/AffiliatePage';
import { ProfilePage } from './components/ProfilePage';
import { HelpSupportPage } from './components/HelpSupportPage';
import { OverviewPage } from './components/OverviewPage';
import { LandingPage } from './components/LandingPage';
import { FeaturesPage } from './components/FeaturesPage';
import { PricingPage } from './components/PricingPage';
import { MarketingShell } from './components/MarketingShell';
import { AppShell } from './components/AppShell';
import { 
  LoginPage, 
  RegisterPage, 
  AuthProcessingPage, 
  PaymentVerificationPage,
  PaymentSuccessPage,
  PaymentCancelledPage 
} from './components/auth';
import { ThemeProvider } from './components/ThemeProvider';
import { TimeRangeFilter } from './components/TimeRangeFilter';
import { PerformanceScore } from './components/PerformanceScore';
import { BudgetTracker } from './components/BudgetTracker';
import { AIInsightsPanel } from './components/AIInsightsPanel';
import { PerformanceHeatmap } from './components/PerformanceHeatmap';
import { ConversionFunnel } from './components/ConversionFunnel';
import { PredictiveAnalytics } from './components/PredictiveAnalytics';
import { QuickActionsButton } from './components/QuickActionsButton';
import { NotificationBanner } from './components/NotificationBanner';
import { DashboardCustomizer, DashboardSection } from './components/DashboardCustomizer';
import { ReorderableWidget } from './components/ReorderableWidget';
import { GridDashboard } from './components/GridDashboard';
import { AppleGridDashboard } from './components/AppleGridDashboard';
import { GettingStartedChecklist } from './components/GettingStartedChecklist';
import { MobileKPICarousel } from './components/MobileKPICarousel';
import { Eye, MousePointerClick, DollarSign, TrendingUp, LayoutGrid, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import { Toaster } from './components/ui/sonner';

// Page type - Extended with auth pages
export type PageType = 
  | 'landing' 
  | 'features'
  | 'pricing'
  | 'login' 
  | 'register' 
  | 'auth-processing' 
  | 'payment-verification' 
  | 'payment-success' 
  | 'payment-cancelled'
  | 'dashboard' 
  | 'analytics' 
  | 'adbuilder' 
  | 'strategies' 
  | 'campaigns' 
  | 'aianalysis' 
  | 'settings' 
  | 'affiliate' 
  | 'profile' 
  | 'help';

// Default Dashboard Configuration - Only Essential HIGH-LEVEL Sections
const DEFAULT_SECTIONS: DashboardSection[] = [
  {
    id: 'ai-insights',
    name: 'AI-Powered Insights',
    description: 'Smart recommendations and anomaly detection',
    category: 'essential',
    isVisible: true
  },
  {
    id: 'performance-chart',
    name: 'Performance Trend',
    description: 'High-level performance over time',
    category: 'essential',
    isVisible: true
  },
  {
    id: 'campaigns-table',
    name: 'Recent Campaigns',
    description: 'Quick overview of active campaigns',
    category: 'essential',
    isVisible: false
  },
  {
    id: 'metrics',
    name: 'Detailed Metrics',
    description: 'Deep dive into performance numbers',
    category: 'analytics',
    isVisible: false
  },
  {
    id: 'notifications',
    name: 'Alerts & Notifications',
    description: 'Critical alerts about budget and performance',
    category: 'essential',
    isVisible: false
  },
  {
    id: 'performance-score',
    name: 'Performance Score',
    description: 'Overall campaign health score (0-100)',
    category: 'essential',
    isVisible: false
  },
  {
    id: 'budget-tracker',
    name: 'Budget Tracker',
    description: 'Track spending and remaining budget',
    category: 'essential',
    isVisible: false
  },
  {
    id: 'audience-breakdown',
    name: 'Audience Demographics',
    description: 'Age and gender distribution of your audience',
    category: 'analytics',
    isVisible: false
  },
  {
    id: 'conversion-funnel',
    name: 'Conversion Funnel',
    description: 'Track user journey from impression to purchase',
    category: 'analytics',
    isVisible: false
  },
  {
    id: 'performance-heatmap',
    name: 'Performance Heatmap',
    description: 'Best times to run ads by day and hour',
    category: 'advanced',
    isVisible: false
  },
  {
    id: 'predictive-analytics',
    name: 'Predictive Analytics',
    description: '7-day forecast with AI-powered predictions',
    category: 'advanced',
    isVisible: false
  },
  {
    id: 'strategy-insights',
    name: 'Strategy Insights',
    description: 'Additional strategic recommendations',
    category: 'advanced',
    isVisible: false
  }
];

function AppContent() {
  const [currentPage, setCurrentPage] = useState<PageType>('landing'); // Start with landing page
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(true);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  
  // Smart Detection: New vs Returning User
  const [isFirstTimeUser, setIsFirstTimeUser] = useState(() => {
    const hasVisited = localStorage.getItem('hasVisitedDashboard');
    const checklistDismissed = localStorage.getItem('checklistDismissed');
    return !hasVisited && !checklistDismissed;
  });
  
  const [showChecklist, setShowChecklist] = useState(() => {
    const checklistDismissed = localStorage.getItem('checklistDismissed');
    const checklistCompleted = localStorage.getItem('checklistCompleted');
    return !checklistDismissed && !checklistCompleted;
  });
  
  const [useGridLayout, setUseGridLayout] = useState(() => {
    const saved = localStorage.getItem('useGridLayout');
    return saved ? JSON.parse(saved) : false;
  });
  const [dashboardSections, setDashboardSections] = useState<DashboardSection[]>(() => {
    const saved = localStorage.getItem('dashboardSections');
    return saved ? JSON.parse(saved) : DEFAULT_SECTIONS;
  });
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d' | 'custom'>('7d');
  const [isComparing, setIsComparing] = useState(false);
  const sidebarWidth = isSidebarCollapsed ? 80 : 256;

  // Mark as visited on mount
  useEffect(() => {
    if (currentPage === 'dashboard') {
      localStorage.setItem('hasVisitedDashboard', 'true');
    }
  }, [currentPage]);

  const handleToggleGridLayout = () => {
    const newValue = !useGridLayout;
    setUseGridLayout(newValue);
    localStorage.setItem('useGridLayout', JSON.stringify(newValue));
    toast.success(
      newValue ? 'Switched to Grid Layout' : 'Switched to List Layout',
      { duration: 2000 }
    );
  };

  const handleToggleSection = (id: string) => {
    const updated = dashboardSections.map(section =>
      section.id === id ? { ...section, isVisible: !section.isVisible } : section
    );
    setDashboardSections(updated);
    localStorage.setItem('dashboardSections', JSON.stringify(updated));
    
    const section = updated.find(s => s.id === id);
    toast.success(
      section?.isVisible ? `${section.name} activated` : `${section?.name} hidden`,
      { duration: 2000 }
    );
  };

  const handleResetToDefaults = () => {
    setDashboardSections(DEFAULT_SECTIONS);
    localStorage.setItem('dashboardSections', JSON.stringify(DEFAULT_SECTIONS));
    toast.success('Dashboard reset to default settings', { duration: 2000 });
  };

  const isVisible = (id: string) => {
    return dashboardSections.find(s => s.id === id)?.isVisible ?? false;
  };

  // Reorder: Move widget up or down
  const handleMoveUp = (index: number) => {
    if (index === 0) return; // Already at top
    
    const visibleSections = dashboardSections.filter(s => s.isVisible);
    const newVisibleSections = [...visibleSections];
    
    // Swap with previous item
    [newVisibleSections[index], newVisibleSections[index - 1]] = 
    [newVisibleSections[index - 1], newVisibleSections[index]];
    
    // Merge back with hidden sections
    const hiddenSections = dashboardSections.filter(s => !s.isVisible);
    const updatedSections = [...newVisibleSections, ...hiddenSections];
    
    setDashboardSections(updatedSections);
    localStorage.setItem('dashboardSections', JSON.stringify(updatedSections));
    
    toast.success(`Moved ${visibleSections[index].name} up`, { duration: 1500 });
  };

  const handleMoveDown = (index: number) => {
    const visibleSections = dashboardSections.filter(s => s.isVisible);
    if (index === visibleSections.length - 1) return; // Already at bottom
    
    const newVisibleSections = [...visibleSections];
    
    // Swap with next item
    [newVisibleSections[index], newVisibleSections[index + 1]] = 
    [newVisibleSections[index + 1], newVisibleSections[index]];
    
    // Merge back with hidden sections
    const hiddenSections = dashboardSections.filter(s => !s.isVisible);
    const updatedSections = [...newVisibleSections, ...hiddenSections];
    
    setDashboardSections(updatedSections);
    localStorage.setItem('dashboardSections', JSON.stringify(updatedSections));
    
    toast.success(`Moved ${visibleSections[index].name} down`, { duration: 1500 });
  };

  // Get visible sections in order
  const visibleSections = dashboardSections.filter(s => s.isVisible);

  // Track scroll direction for visual indicators
  const [scrollDirection, setScrollDirection] = useState<'up' | 'down' | null>(null);

  const handleCreateAd = () => {
    setCurrentPage('adbuilder');
  };

  // Render individual widget content based on section ID
  const renderWidgetContent = (sectionId: string) => {
    switch (sectionId) {
      case 'notifications':
        return (
          <div className="hidden md:block bg-card border border-border rounded-xl transition-colors hover:border-border/80 overflow-hidden">
            <NotificationBanner />
          </div>
        );
      
      case 'performance-score':
        return (
          <div className="hidden md:block bg-card border border-border rounded-xl p-6 transition-colors hover:border-border/80">
            <PerformanceScore />
          </div>
        );
      
      case 'budget-tracker':
        return (
          <div className="hidden md:block bg-card border border-border rounded-xl p-6 transition-colors hover:border-border/80">
            <BudgetTracker />
          </div>
        );
      
      case 'metrics':
        return (
          <div className="bg-card border border-border rounded-xl p-6 md:p-8 transition-colors hover:border-border/80">
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-3">
              <div className="min-w-0">
                <h3 className="text-lg font-bold text-foreground mb-1">Campaign Performance</h3>
                <p className="text-sm text-muted-foreground">Real-time analytics overview</p>
              </div>
              <div className="px-3 py-1.5 bg-muted border border-border rounded-lg w-fit">
                <span className="text-xs text-foreground font-medium whitespace-nowrap">● Live</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 mb-6 md:mb-8">
              <div className="p-5 md:p-6 rounded-lg bg-muted/30 border border-border">
                <div className="text-3xl md:text-4xl text-foreground mb-2 font-bold">$1,953.43</div>
                <div className="text-sm text-muted-foreground mb-2">Total Ad Spend</div>
                <div className="text-xs text-muted-foreground">Daily avg: $278.35</div>
              </div>
              <div className="p-5 md:p-6 rounded-lg bg-muted/30 border border-border">
                <div className="text-3xl md:text-4xl text-foreground mb-2 font-bold">$28,765.98</div>
                <div className="text-sm text-muted-foreground mb-2">Total Revenue</div>
                <div className="text-xs text-muted-foreground">Return on investment: 14.7x</div>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
              <AdMetricsCard
                title="Impressions"
                value="4.2M"
                subValue="Daily avg: 600K"
                percentage={3.5}
                isPositive={true}
                icon={<Eye className="w-5 h-5" />}
                color="#3b82f6"
                tooltip="Total number of times your ads were shown to users"
              />
              <AdMetricsCard
                title="Click-through rate"
                value="2.8%"
                subValue="Industry avg: 1.9%"
                percentage={1.9}
                isPositive={true}
                icon={<MousePointerClick className="w-5 h-5" />}
                color="#10b981"
                tooltip="Percentage of impressions that resulted in clicks"
              />
              <AdMetricsCard
                title="Cost per click"
                value="$0.46"
                subValue="Decreased from $0.52"
                percentage={1.2}
                isPositive={false}
                icon={<DollarSign className="w-5 h-5" />}
                color="#f59e0b"
                tooltip="Average cost you pay for each click on your ads"
              />
              <AdMetricsCard
                title="Return on ad spend"
                value="4.8x"
                subValue="Above target: 3.5x"
                percentage={1.5}
                isPositive={true}
                icon={<TrendingUp className="w-5 h-5" />}
                color="#8b5cf6"
                tooltip="Revenue generated for every dollar spent on advertising"
              />
            </div>
          </div>
        );
      
      case 'ai-insights':
        return (
          <div className="bg-card border border-border rounded-xl transition-colors hover:border-border/80 overflow-hidden">
            <AIInsightsPanel />
          </div>
        );
      
      case 'performance-chart':
        return (
          <div className="bg-card border border-border rounded-xl transition-colors hover:border-border/80 overflow-hidden">
            <PerformanceChart />
          </div>
        );
      
      case 'audience-breakdown':
        return (
          <div className="bg-card border border-border rounded-xl p-6 transition-colors hover:border-border/80">
            <AudienceBreakdown />
          </div>
        );
      
      case 'conversion-funnel':
        return (
          <div className="bg-card border border-border rounded-xl p-6 transition-colors hover:border-border/80">
            <ConversionFunnel />
          </div>
        );
      
      case 'performance-heatmap':
        return (
          <div className="bg-card border border-border rounded-xl p-6 transition-colors hover:border-border/80">
            <PerformanceHeatmap />
          </div>
        );
      
      case 'predictive-analytics':
        return (
          <div className="bg-card border border-border rounded-xl p-6 transition-colors hover:border-border/80">
            <PredictiveAnalytics />
          </div>
        );
      
      case 'strategy-insights':
        return (
          <div className="bg-card border border-border rounded-xl transition-colors hover:border-border/80">
            <StrategyInsights />
          </div>
        );
      
      case 'campaigns-table':
        return (
          <div className="bg-card border border-border rounded-xl transition-colors hover:border-border/80 overflow-hidden">
            <CampaignsTable />
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen w-full max-w-[100vw] overflow-x-hidden">
      {/* Auth Pages - Full Screen, No Sidebar/Header */}
      {(currentPage === 'landing' || 
        currentPage === 'features' ||
        currentPage === 'pricing' ||
        currentPage === 'login' || 
        currentPage === 'register' || 
        currentPage === 'auth-processing' || 
        currentPage === 'payment-verification' || 
        currentPage === 'payment-success' || 
        currentPage === 'payment-cancelled') && (
        <>
          {currentPage === 'landing' && (
            <LandingPage 
              onGetStarted={() => setCurrentPage('register')}
              onLogin={() => setCurrentPage('login')}
            />
          )}
          
          {currentPage === 'features' && (
            <FeaturesPage
              onNavigate={(page) => setCurrentPage(page as PageType)}
              onSignIn={() => setCurrentPage('login')}
              onGetStarted={() => setCurrentPage('register')}
            />
          )}
          
          {currentPage === 'pricing' && (
            <PricingPage
              onNavigate={(page) => setCurrentPage(page as PageType)}
              onSignIn={() => setCurrentPage('login')}
              onGetStarted={() => setCurrentPage('register')}
            />
          )}
          
          {currentPage === 'login' && (
            <LoginPage
              onGoogleLogin={() => {
                toast.success('Google login initiated');
                setCurrentPage('auth-processing');
              }}
              onEmailLogin={(email, password) => {
                toast.success('Logging in...');
                setCurrentPage('auth-processing');
              }}
              onNavigateToRegister={() => setCurrentPage('register')}
              onForgotPassword={() => toast.info('Password reset email sent')}
            />
          )}
          
          {currentPage === 'register' && (
            <RegisterPage
              onGoogleRegister={() => {
                toast.success('Google registration initiated');
                setCurrentPage('auth-processing');
              }}
              onEmailRegister={(name, email, password) => {
                toast.success('Creating account...');
                setCurrentPage('auth-processing');
              }}
              onNavigateToLogin={() => setCurrentPage('login')}
            />
          )}
          
          {currentPage === 'auth-processing' && (
            <AuthProcessingPage
              message="Logging you in..."
              onComplete={() => setCurrentPage('dashboard')}
            />
          )}
          
          {currentPage === 'payment-verification' && (
            <PaymentVerificationPage
              sessionId={undefined} // You'll pass real sessionId from URL params
              onVerificationSuccess={() => setCurrentPage('payment-success')}
              onVerificationError={() => setCurrentPage('payment-cancelled')}
              onGoHome={() => setCurrentPage('landing')}
              onLogout={() => setCurrentPage('login')}
            />
          )}
          
          {currentPage === 'payment-success' && (
            <PaymentSuccessPage
              onGoToDashboard={() => setCurrentPage('dashboard')}
            />
          )}
          
          {currentPage === 'payment-cancelled' && (
            <PaymentCancelledPage
              onRetryCheckout={() => setCurrentPage('payment-verification')}
              onViewPricing={() => setCurrentPage('landing')}
              onGoHome={() => setCurrentPage('landing')}
            />
          )}
        </>
      )}

      {/* Dashboard Pages - With Sidebar/Header */}
      {currentPage !== 'landing' && 
       currentPage !== 'features' &&
       currentPage !== 'pricing' &&
       currentPage !== 'login' && 
       currentPage !== 'register' && 
       currentPage !== 'auth-processing' && 
       currentPage !== 'payment-verification' && 
       currentPage !== 'payment-success' && 
       currentPage !== 'payment-cancelled' && (
      <div className="flex min-h-screen" style={{ background: 'var(--background-gradient)' }}>
        {/* Sidebar */}
        <Sidebar 
          isCollapsed={isSidebarCollapsed} 
          onToggle={setIsSidebarCollapsed}
          currentPage={currentPage}
          onNavigate={(page) => {
            setCurrentPage(page);
            setIsMobileSidebarOpen(false); // Close sidebar when navigating
          }}
          isMobileOpen={isMobileSidebarOpen}
          onMobileClose={() => setIsMobileSidebarOpen(false)}
        />

        {/* Main Content - Blurred when mobile sidebar is open */}
        <div 
          className={`flex-1 transition-all duration-300 md:ml-0 ${isMobileSidebarOpen ? 'blur-sm pointer-events-none' : ''}`}
          style={{ marginLeft: window.innerWidth >= 768 ? `${sidebarWidth}px` : '0' }}
        >
          {/* Header */}
          <Header 
            sidebarWidth={window.innerWidth >= 768 ? sidebarWidth : 0} 
            onToggleMobileSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
            onNavigate={(page) => setCurrentPage(page)}
          />

          {/* Page Content */}
          {currentPage === 'dashboard' && (
            <div className="pt-16 min-h-screen">
              <OverviewPage onNavigate={(page) => setCurrentPage(page as PageType)} />
            </div>
          )}

          {currentPage === 'analytics' && (
            <div className="pt-16 min-h-screen">
              <AnalyticsPage />
              <Footer />
            </div>
          )}

          {currentPage === 'strategies' && (
            <div className="pt-16 min-h-screen">
              <AdsStrategiesPage />
              <Footer />
            </div>
          )}

          {currentPage === 'campaigns' && (
            <div className="pt-16 min-h-screen">
              <CampaignsPage />
              <Footer />
            </div>
          )}

          {currentPage === 'aianalysis' && (
            <div className="pt-16 min-h-screen">
              <AIAnalysisPage />
              <Footer />
            </div>
          )}

          {currentPage === 'settings' && (
            <div className="pt-16 min-h-screen">
              <SettingsPage />
              <Footer />
            </div>
          )}

          {currentPage === 'affiliate' && (
            <div className="pt-16 min-h-screen">
              <AffiliatePage />
              <Footer />
            </div>
          )}

          {currentPage === 'profile' && (
            <div className="pt-16 min-h-screen">
              <ProfilePage />
              <Footer />
            </div>
          )}

          {currentPage === 'help' && (
            <div className="pt-16 min-h-screen">
              <HelpSupportPage />
              <Footer />
            </div>
          )}

          {currentPage === 'adbuilder' && (
            <div className="pt-16 min-h-screen">
              <AdBuilderPage />
              <Footer />
            </div>
          )}
          
          {/* Quick Actions Button */}
          {currentPage === 'dashboard' && (
            <QuickActionsButton onCreateCampaign={handleCreateAd} />
          )}
        </div>
      </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <Toaster />
      <AppContent />
    </ThemeProvider>
  );
}