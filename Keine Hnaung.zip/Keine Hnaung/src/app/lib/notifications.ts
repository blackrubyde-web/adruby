import { toast } from 'sonner';

// Bloomberg-style analytical messaging
// No emojis, no hype, pure precision

export const notifications = {
  // Analysis
  analysisComplete: () => 
    toast.success('Analysis complete', {
      description: 'Decision tree generated. Review prioritized actions.'
    }),

  analysisRunning: () =>
    toast.loading('Processing campaign data', {
      description: 'Analyzing performance vectors and confidence intervals.'
    }),

  analysisError: () =>
    toast.error('Analysis interrupted', {
      description: 'Unable to complete operation. Verify data connection.'
    }),

  // Account operations
  accountSwitched: (accountName: string) =>
    toast.success('Account context updated', {
      description: `Now viewing: ${accountName}`
    }),

  accountConnected: (accountName: string) =>
    toast.success('Account connected', {
      description: `${accountName} integrated. Initializing data sync.`
    }),

  // Creative operations
  variantsGenerated: (count: number) =>
    toast.success(`${count} variants generated`, {
      description: 'Each variant targets specific hypothesis. Review comparison.'
    }),

  creativeDeployed: () =>
    toast.success('Creative deployed to Meta Ads', {
      description: 'Campaign active. Tracking initiated.'
    }),

  templateApplied: (templateName: string) =>
    toast.success('Template applied', {
      description: `${templateName} structure loaded. Customize as needed.`
    }),

  // Learning operations
  learningCaptured: () =>
    toast.success('Insight captured', {
      description: 'Pattern added to learning memory. Available across accounts.'
    }),

  testCompleted: (result: 'winner' | 'loser') =>
    toast.success(`Test concluded: ${result}`, {
      description: result === 'winner' 
        ? 'Performance improvement detected. Scaling recommended.'
        : 'Hypothesis rejected. Insights captured for future reference.'
    }),

  // Data operations
  dataRefreshed: () =>
    toast.success('Data synchronized', {
      description: 'Latest metrics integrated. Recommendations updated.'
    }),

  dataExported: (format: string) =>
    toast.success(`Export complete`, {
      description: `${format.toUpperCase()} file ready for download.`
    }),

  // Errors
  insufficientData: () =>
    toast.error('Insufficient data', {
      description: 'Minimum 48h activity and 1,000 impressions required.'
    }),

  connectionLost: () =>
    toast.error('Connection interrupted', {
      description: 'Meta Ads API unresponsive. Retrying connection.'
    }),

  operationFailed: (operation: string) =>
    toast.error('Operation failed', {
      description: `${operation} could not be completed. Review error log.`
    }),

  // Warnings
  highFrequency: (frequency: number) =>
    toast.warning('Creative fatigue risk', {
      description: `Frequency at ${frequency.toFixed(1)}. Prepare variant refresh.`
    }),

  budgetThreshold: (percentage: number) =>
    toast.warning('Budget threshold reached', {
      description: `${percentage}% of monthly allocation consumed.`
    }),

  // Success operations
  campaignLaunched: (campaignName: string) =>
    toast.success('Campaign activated', {
      description: `${campaignName} live. Performance tracking enabled.`
    }),

  optimizationApplied: () =>
    toast.success('Optimization deployed', {
      description: 'Changes propagated to active campaigns. Monitor for impact.'
    })
};
