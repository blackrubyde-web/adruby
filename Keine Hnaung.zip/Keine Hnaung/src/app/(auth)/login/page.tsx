export default function LoginPage() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center p-6">
      <div className="w-full max-w-md bg-card border border-border rounded-xl p-6">
        <h1 className="text-xl font-bold text-foreground">Sign in</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Auth scaffolding — wire to NextAuth in the next step.
        </p>
      </div>
    </div>
  );
}

