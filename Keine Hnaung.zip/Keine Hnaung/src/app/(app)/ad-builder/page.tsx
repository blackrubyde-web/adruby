export default function AdBuilderPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Ad Builder</h1>
      <p className="text-sm text-muted-foreground mt-1">Route scaffold.</p>
    </div>
  );
}

