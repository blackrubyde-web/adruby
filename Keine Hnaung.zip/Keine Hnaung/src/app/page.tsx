import { MarketingLandingClient } from "./_components/MarketingLandingClient";

export default function HomePage() {
  return <MarketingLandingClient />;
}

