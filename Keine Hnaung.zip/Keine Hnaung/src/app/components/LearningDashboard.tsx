import React, { useState } from 'react';
import { IterationTimeline } from './learning/IterationTimeline';
import { AccountLearnings } from './learning/AccountLearnings';
import { Brain, TrendingUp, Database, History } from 'lucide-react';
import { PhilosophyStatement } from './differentiation/PhilosophyStatement';
import { HowThisWorks } from './differentiation/HowThisWorks';

type ViewMode = 'timeline' | 'learnings';

export function LearningDashboard() {
  const [viewMode, setViewMode] = useState<ViewMode>('learnings');

  // Mock timeline data
  const timelineEntries: TimelineEntry[] = [
    {
      id: '1',
      date: 'Dec 16, 2024',
      testName: 'Pain-Point Hook Test',
      hypothesis: 'Pain-point hooks will outperform curiosity hooks for cold traffic',
      whatChanged: 'Replaced "Curious about ad automation?" with "Stop wasting $2,000/month on underperforming ads"',
      result: 'winner',
      confidence: 'high',
      metrics: {
        ctr: { before: '2.1%', after: '2.8%' },
        cpa: { before: '$12.50', after: '$9.30' },
        roas: { before: '3.2x', after: '4.8x' }
      },
      learnings: [
        'Direct cost references ($2,000/month) create stronger urgency than vague pain points',
        'Cold traffic needs immediate relevance - curiosity alone isn\'t enough',
        'Specific numbers outperform generic claims for this audience'
      ]
    },
    {
      id: '2',
      date: 'Dec 14, 2024',
      testName: 'Social Proof Position Test',
      hypothesis: 'Moving social proof above the fold will increase trust signals',
      whatChanged: 'Moved "10,000+ marketers" badge from footer to header',
      result: 'winner',
      confidence: 'high',
      metrics: {
        ctr: { before: '1.8%', after: '2.3%' },
        cpa: { before: '$14.20', after: '$11.80' }
      },
      learnings: [
        'Social proof needs to be seen immediately - below fold = invisible',
        'Numbers work better than testimonial quotes for this audience',
        'Badge format (10,000+) more scannable than written text'
      ]
    },
    {
      id: '3',
      date: 'Dec 12, 2024',
      testName: 'Discount vs Value Framing',
      hypothesis: 'Value-first framing will outperform discount-first for premium positioning',
      whatChanged: 'Changed "50% off" to "Get 2x results for half the cost"',
      result: 'loser',
      confidence: 'medium',
      metrics: {
        ctr: { before: '2.4%', after: '2.1%' },
        cpa: { before: '$10.50', after: '$13.20' }
      },
      learnings: [
        'This audience responds to direct discounts more than value reframing',
        'Price-sensitive segment - don\'t overcomplicate the offer',
        'Premium positioning doesn\'t resonate with this demographic'
      ]
    },
    {
      id: '4',
      date: 'Dec 10, 2024',
      testName: 'Lifestyle vs Product-in-Use Visuals',
      hypothesis: 'Product-in-use visuals will make value more tangible',
      whatChanged: 'Replaced lifestyle/office shots with dashboard screenshots',
      result: 'winner',
      confidence: 'high',
      metrics: {
        ctr: { before: '1.9%', after: '2.6%' },
        cpa: { before: '$15.30', after: '$10.90' }
      },
      learnings: [
        'B2B SaaS audience wants to see the actual product, not aspirational imagery',
        'Screenshots with clear UI outperform abstract "work scenes"',
        'Tangible > aspirational for this vertical'
      ]
    }
  ];

  // Mock learning data
  const learnings: Learning[] = [
    {
      id: '1',
      category: 'audience',
      insight: 'This account\'s audience is highly price-sensitive and responds 34% better to direct discount language than value reframing',
      confidence: 'high',
      impact: 'high',
      basedOn: '3 tests, 127k impressions, $8.5k spend',
      actionable: 'Always lead with clear discount percentages or dollar amounts. Avoid subtle value language like "better ROI" - use "$X saved" instead.'
    },
    {
      id: '2',
      category: 'creative',
      insight: 'Pain-point hooks outperform curiosity hooks by 33% CTR for cold traffic',
      confidence: 'high',
      impact: 'high',
      basedOn: '5 tests, 234k impressions, $12.3k spend',
      actionable: 'For cold traffic, always start with direct pain points (e.g., "Stop wasting $X"). Save curiosity hooks for warm/retargeting audiences only.'
    },
    {
      id: '3',
      category: 'creative',
      insight: 'Product screenshots outperform lifestyle visuals by 37% for this B2B SaaS audience',
      confidence: 'high',
      impact: 'high',
      basedOn: '4 tests, 189k impressions, $9.8k spend',
      actionable: 'Use actual dashboard/product screenshots instead of stock photos or lifestyle imagery. Show the tool in action, not people using computers.'
    },
    {
      id: '4',
      category: 'timing',
      insight: 'Creative fatigue hits at frequency 4.2, typically around day 18-21',
      confidence: 'medium',
      impact: 'high',
      basedOn: '8 campaigns tracked, 450k impressions',
      actionable: 'Prepare creative refresh at day 14-16. Don\'t wait for performance drop - be proactive. Keep winning copy, swap visuals first.'
    },
    {
      id: '5',
      category: 'creative',
      insight: 'Social proof numbers (10,000+) need to be above the fold to be effective',
      confidence: 'high',
      impact: 'medium',
      basedOn: '2 tests, 98k impressions, $5.2k spend',
      actionable: 'Place social proof badges/numbers in header or first screen. Below-fold placement = invisible. Badge format > written testimonials.'
    },
    {
      id: '6',
      category: 'audience',
      insight: 'Premium positioning language ("enterprise-grade", "professional") underperforms direct benefit language by 28%',
      confidence: 'medium',
      impact: 'medium',
      basedOn: '3 tests, 145k impressions, $7.1k spend',
      actionable: 'This audience cares about results and price, not status. Use "save money" over "join the pros". Focus on ROI and savings.'
    },
    {
      id: '7',
      category: 'timing',
      insight: 'Peak performance window is 6pm-9pm EST, with 23% higher CTR than morning slots',
      confidence: 'medium',
      impact: 'medium',
      basedOn: 'Dayparting analysis across 12 campaigns',
      actionable: 'Increase budget during evening hours. Consider reducing morning spend. Audience most engaged after work hours.'
    },
    {
      id: '8',
      category: 'offer',
      insight: 'Urgency CTAs ("Limited time") increase conversion 19% but only for warm traffic',
      confidence: 'medium',
      impact: 'medium',
      basedOn: '4 tests, 156k impressions, warm vs cold split',
      actionable: 'Use urgency language ("Limited time", "Last chance") only for retargeting/warm audiences. Cold traffic needs value-focused CTAs.'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-[1400px] mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-foreground mb-2">
            Learning Dashboard
          </h1>
          <p className="text-sm text-muted-foreground">
            AdRuby learns from every test and gets smarter over time
          </p>
        </div>

        {/* View Toggle */}
        <div className="flex items-center gap-2 mb-8 border-b border-border">
          <button
            onClick={() => setViewMode('learnings')}
            className={`px-4 py-3 font-semibold text-sm transition-colors relative flex items-center gap-2 ${
              viewMode === 'learnings'
                ? 'text-foreground'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Brain className="w-4 h-4" />
            Learning Memory
            {viewMode === 'learnings' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
            )}
          </button>
          <button
            onClick={() => setViewMode('timeline')}
            className={`px-4 py-3 font-semibold text-sm transition-colors relative flex items-center gap-2 ${
              viewMode === 'timeline'
                ? 'text-foreground'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <History className="w-4 h-4" />
            Iteration Timeline
            {viewMode === 'timeline' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
            )}
          </button>
        </div>

        {/* Content */}
        {viewMode === 'learnings' && <AccountLearnings learnings={learnings} />}
        {viewMode === 'timeline' && <IterationTimeline entries={timelineEntries} />}
      </div>
    </div>
  );
}