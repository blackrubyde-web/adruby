import React from 'react';
import { TrendingUp, TrendingDown, Target, Zap, AlertCircle } from 'lucide-react';

interface Learning {
  id: string;
  category: 'audience' | 'creative' | 'timing' | 'budget';
  insight: string;
  impact: 'high' | 'medium' | 'low';
  confidence: number;
  basedOn: {
    tests: number;
    impressions: number;
    timeframe: string;
  };
  recommendation: string;
}

const mockLearnings: Learning[] = [
  {
    id: '1',
    category: 'creative',
    insight: 'Pain-point hooks outperform benefit-first hooks by 34%',
    impact: 'high',
    confidence: 87,
    basedOn: {
      tests: 12,
      impressions: 450000,
      timeframe: 'Last 30 days'
    },
    recommendation: 'Lead with pain-point ("Struggling with X?") instead of benefit ("Get Y")'
  },
  {
    id: '2',
    category: 'audience',
    insight: 'Women 35-44 convert at 2.3x rate vs. 25-34 segment',
    impact: 'high',
    confidence: 92,
    basedOn: {
      tests: 8,
      impressions: 320000,
      timeframe: 'Last 60 days'
    },
    recommendation: 'Shift 40% of budget from 25-34 to 35-44 segment'
  },
  {
    id: '3',
    category: 'timing',
    insight: 'Tuesday-Thursday 6-9 PM shows 28% lower CPA',
    impact: 'medium',
    confidence: 78,
    basedOn: {
      tests: 15,
      impressions: 680000,
      timeframe: 'Last 90 days'
    },
    recommendation: 'Increase dayparting allocation for weekday evenings'
  },
  {
    id: '4',
    category: 'budget',
    insight: 'Campaigns plateau after $150/day spend threshold',
    impact: 'medium',
    confidence: 81,
    basedOn: {
      tests: 6,
      impressions: 210000,
      timeframe: 'Last 45 days'
    },
    recommendation: 'Cap individual campaign budgets at $150/day, scale horizontally'
  },
  {
    id: '5',
    category: 'creative',
    insight: 'Video ads under 12 seconds show 41% higher completion rate',
    impact: 'high',
    confidence: 89,
    basedOn: {
      tests: 18,
      impressions: 890000,
      timeframe: 'Last 60 days'
    },
    recommendation: 'Cut all video creatives to 8-10 second format'
  },
  {
    id: '6',
    category: 'audience',
    insight: 'Lookalike audiences from purchasers outperform lead-based by 56%',
    impact: 'high',
    confidence: 94,
    basedOn: {
      tests: 10,
      impressions: 520000,
      timeframe: 'Last 90 days'
    },
    recommendation: 'Prioritize purchaser-based lookalikes over lead-based audiences'
  }
];

const categoryConfig = {
  audience: { label: 'Audience', color: 'text-blue-600', bg: 'bg-blue-500/10', border: 'border-blue-500/20' },
  creative: { label: 'Creative', color: 'text-purple-600', bg: 'bg-purple-500/10', border: 'border-purple-500/20' },
  timing: { label: 'Timing', color: 'text-green-600', bg: 'bg-green-500/10', border: 'border-green-500/20' },
  budget: { label: 'Budget', color: 'text-orange-600', bg: 'bg-orange-500/10', border: 'border-orange-500/20' }
};

const impactConfig = {
  high: { label: 'High Impact', icon: TrendingUp, color: 'text-green-600' },
  medium: { label: 'Medium Impact', icon: Zap, color: 'text-yellow-600' },
  low: { label: 'Low Impact', icon: TrendingDown, color: 'text-gray-600' }
};

export function AccountLearnings() {
  return (
    <div className="space-y-4">
      {/* Stats Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-card border border-border rounded-xl p-4">
          <div className="text-2xl font-bold text-foreground mb-1">34</div>
          <div className="text-sm text-muted-foreground">Total Learnings</div>
        </div>
        <div className="bg-card border border-border rounded-xl p-4">
          <div className="text-2xl font-bold text-foreground mb-1">1.2M</div>
          <div className="text-sm text-muted-foreground">Impressions Analyzed</div>
        </div>
        <div className="bg-card border border-border rounded-xl p-4">
          <div className="text-2xl font-bold text-foreground mb-1">87%</div>
          <div className="text-sm text-muted-foreground">Avg. Confidence</div>
        </div>
        <div className="bg-card border border-border rounded-xl p-4">
          <div className="text-2xl font-bold text-foreground mb-1">12</div>
          <div className="text-sm text-muted-foreground">High Impact</div>
        </div>
      </div>

      {/* Learnings List */}
      <div className="space-y-3">
        {mockLearnings.map((learning) => {
          const category = categoryConfig[learning.category];
          const impact = impactConfig[learning.impact];
          const ImpactIcon = impact.icon;

          return (
            <div
              key={learning.id}
              className="bg-card border border-border rounded-xl p-5 hover:shadow-lg hover:-translate-y-0.5 transition-all"
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3 flex-1">
                  <div className={`px-2 py-1 rounded ${category.bg} ${category.border} border`}>
                    <span className={`text-xs font-bold ${category.color}`}>
                      {category.label}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <ImpactIcon className={`w-4 h-4 ${impact.color}`} />
                    <span className={`text-xs font-semibold ${impact.color}`}>
                      {impact.label}
                    </span>
                  </div>
                </div>

                {/* Confidence Score */}
                <div className="flex items-center gap-2">
                  <div className="text-right">
                    <div className="text-xs text-muted-foreground">Confidence</div>
                    <div className="text-sm font-bold text-foreground">{learning.confidence}%</div>
                  </div>
                  <div className="w-12 h-12 relative">
                    <svg className="transform -rotate-90 w-12 h-12">
                      <circle
                        cx="24"
                        cy="24"
                        r="20"
                        stroke="currentColor"
                        strokeWidth="3"
                        fill="transparent"
                        className="text-muted"
                      />
                      <circle
                        cx="24"
                        cy="24"
                        r="20"
                        stroke="currentColor"
                        strokeWidth="3"
                        fill="transparent"
                        strokeDasharray={`${2 * Math.PI * 20}`}
                        strokeDashoffset={`${2 * Math.PI * 20 * (1 - learning.confidence / 100)}`}
                        className="text-primary"
                      />
                    </svg>
                  </div>
                </div>
              </div>

              {/* Insight */}
              <div className="mb-4">
                <h3 className="font-bold text-foreground mb-2">
                  {learning.insight}
                </h3>
                <p className="text-sm text-muted-foreground">
                  Based on {learning.basedOn.tests} tests, {learning.basedOn.impressions.toLocaleString()} impressions
                  {' • '}{learning.basedOn.timeframe}
                </p>
              </div>

              {/* Recommendation */}
              <div className="bg-blue-500/5 border border-blue-500/10 rounded-lg p-3">
                <div className="flex items-start gap-2">
                  <Target className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <div className="text-xs font-bold text-blue-600 mb-1">
                      Recommended Action
                    </div>
                    <p className="text-sm text-foreground">
                      {learning.recommendation}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Info Footer */}
      <div className="bg-muted/30 border border-border rounded-xl p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-0.5" />
        <div>
          <div className="text-sm font-semibold text-foreground mb-1">
            How Learning Confidence Works
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">
            Confidence scores are calculated based on sample size, statistical significance, 
            and consistency across multiple tests. Scores above 80% indicate high reliability.
          </p>
        </div>
      </div>
    </div>
  );
}
