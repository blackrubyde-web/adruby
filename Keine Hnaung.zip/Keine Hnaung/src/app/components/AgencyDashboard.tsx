import React, { useState } from 'react';
import { AccountSwitcher, Account } from './agency/AccountSwitcher';
import { CrossAccountInsights, AccountPerformance } from './agency/CrossAccountInsights';
import { SharedLearningPool, SharedLearning } from './agency/SharedLearningPool';
import { TemplateLibrary, Template } from './agency/TemplateLibrary';
import { LayoutGrid, Database, FileText, BarChart3 } from 'lucide-react';
import { toast } from 'sonner';

type AgencyView = 'overview' | 'insights' | 'learnings' | 'templates';

export function AgencyDashboard() {
  const [currentView, setCurrentView] = useState<AgencyView>('overview');
  const [currentAccountId, setCurrentAccountId] = useState('acc-1');

  // Mock data
  const accounts: Account[] = [
    {
      id: 'acc-1',
      name: 'E-Commerce Client A',
      organization: 'ACME Digital Agency',
      spend30d: '$45.2k',
      roas30d: '4.8x',
      status: 'active'
    },
    {
      id: 'acc-2',
      name: 'SaaS Client B',
      organization: 'ACME Digital Agency',
      spend30d: '$28.9k',
      roas30d: '5.2x',
      status: 'active'
    },
    {
      id: 'acc-3',
      name: 'DTC Brand C',
      organization: 'ACME Digital Agency',
      spend30d: '$67.3k',
      roas30d: '3.4x',
      status: 'warning'
    },
    {
      id: 'acc-4',
      name: 'Local Services D',
      organization: 'ACME Digital Agency',
      spend30d: '$12.1k',
      roas30d: '2.8x',
      status: 'warning'
    },
    {
      id: 'acc-5',
      name: 'Info Product E',
      organization: 'ACME Digital Agency',
      spend30d: '$89.5k',
      roas30d: '6.1x',
      status: 'active'
    },
    {
      id: 'acc-6',
      name: 'Personal Project',
      spend30d: '$5.2k',
      roas30d: '4.2x',
      status: 'active'
    }
  ];

  const accountPerformances: AccountPerformance[] = [
    {
      id: 'acc-5',
      name: 'Info Product E',
      spend: '$89.5k',
      roas: 6.1,
      cpa: '$8.20',
      change: 24,
      status: 'outperforming'
    },
    {
      id: 'acc-2',
      name: 'SaaS Client B',
      spend: '$28.9k',
      roas: 5.2,
      cpa: '$11.50',
      change: 18,
      status: 'outperforming'
    },
    {
      id: 'acc-1',
      name: 'E-Commerce Client A',
      spend: '$45.2k',
      roas: 4.8,
      cpa: '$9.80',
      change: 12,
      status: 'outperforming'
    },
    {
      id: 'acc-6',
      name: 'Personal Project',
      spend: '$5.2k',
      roas: 4.2,
      cpa: '$14.30',
      change: 8,
      status: 'average'
    },
    {
      id: 'acc-3',
      name: 'DTC Brand C',
      spend: '$67.3k',
      roas: 3.4,
      cpa: '$18.90',
      change: -6,
      status: 'underperforming'
    },
    {
      id: 'acc-4',
      name: 'Local Services D',
      spend: '$12.1k',
      roas: 2.8,
      cpa: '$22.40',
      change: -12,
      status: 'underperforming'
    }
  ];

  const sharedLearnings: SharedLearning[] = [
    {
      id: 'sl-1',
      insight: 'Pain-point hooks outperform curiosity hooks by an average of 31% CTR across e-commerce and SaaS verticals',
      sourceAccounts: 4,
      confidence: 'high',
      impact: 'high',
      applicableTo: ['E-Commerce', 'SaaS', 'DTC'],
      basedOn: {
        tests: 18,
        impressions: '847k',
        spend: '$34.2k'
      },
      isPrivate: false
    },
    {
      id: 'sl-2',
      insight: 'Product screenshots outperform lifestyle imagery by 42% for B2B SaaS audiences but underperform by 18% for DTC fashion',
      sourceAccounts: 3,
      confidence: 'high',
      impact: 'high',
      applicableTo: ['SaaS', 'B2B'],
      basedOn: {
        tests: 12,
        impressions: '623k',
        spend: '$28.9k'
      },
      isPrivate: false
    },
    {
      id: 'sl-3',
      insight: 'Creative fatigue occurs at frequency 4.1 on average, with variance between 3.8 (info products) and 4.6 (physical goods)',
      sourceAccounts: 6,
      confidence: 'high',
      impact: 'medium',
      applicableTo: ['All'],
      basedOn: {
        tests: 34,
        impressions: '1.2M',
        spend: '$67.8k'
      },
      isPrivate: false
    },
    {
      id: 'sl-4',
      insight: 'Discount-first messaging underperforms value-first by 23% for premium products priced above $200',
      sourceAccounts: 2,
      confidence: 'medium',
      impact: 'high',
      applicableTo: ['E-Commerce', 'Premium', 'DTC'],
      basedOn: {
        tests: 8,
        impressions: '412k',
        spend: '$19.3k'
      },
      isPrivate: true
    },
    {
      id: 'sl-5',
      insight: 'Social proof positioned above the fold increases conversion rate by 28% across all tested verticals',
      sourceAccounts: 5,
      confidence: 'high',
      impact: 'high',
      applicableTo: ['All'],
      basedOn: {
        tests: 15,
        impressions: '734k',
        spend: '$31.4k'
      },
      isPrivate: false
    }
  ];

  const templates: Template[] = [
    {
      id: 'tmpl-1',
      name: 'Pain-Point Hook Framework',
      type: 'hook',
      description: 'Proven hook structure that leads with specific cost/time pain points. Works best for cold traffic.',
      performance: {
        accounts: 4,
        avgROAS: '5.1x',
        avgCTR: '2.8%'
      },
      isPrivate: false,
      createdBy: 'ACME Digital',
      lastUpdated: '2 days ago',
      tags: ['Cold Traffic', 'Pain-Point', 'B2B']
    },
    {
      id: 'tmpl-2',
      name: 'Product Demo Creative',
      type: 'creative',
      description: 'Screenshot-based creative showcasing product in use. Optimized for B2B SaaS.',
      performance: {
        accounts: 3,
        avgROAS: '4.9x',
        avgCTR: '2.4%'
      },
      isPrivate: false,
      createdBy: 'SaaS Client B',
      lastUpdated: '1 week ago',
      tags: ['SaaS', 'Screenshot', 'Demo']
    },
    {
      id: 'tmpl-3',
      name: 'Social Proof Campaign',
      type: 'campaign',
      description: 'Full campaign structure with testimonial-heavy creatives and trust-building copy.',
      performance: {
        accounts: 5,
        avgROAS: '5.4x',
        avgCTR: '3.1%'
      },
      isPrivate: false,
      createdBy: 'E-Commerce Client A',
      lastUpdated: '3 days ago',
      tags: ['Trust', 'Testimonials', 'Conversion']
    },
    {
      id: 'tmpl-4',
      name: 'Urgency-Based Retargeting',
      type: 'strategy',
      description: 'Retargeting strategy using time-limited offers and FOMO triggers. High conversion for warm traffic.',
      performance: {
        accounts: 4,
        avgROAS: '6.8x',
        avgCTR: '4.2%'
      },
      isPrivate: true,
      createdBy: 'Info Product E',
      lastUpdated: '5 days ago',
      tags: ['Retargeting', 'Urgency', 'Warm Traffic']
    },
    {
      id: 'tmpl-5',
      name: 'Value-First Premium Positioning',
      type: 'creative',
      description: 'Creative framework for premium products focusing on value and quality over price.',
      performance: {
        accounts: 2,
        avgROAS: '4.3x',
        avgCTR: '1.9%'
      },
      isPrivate: true,
      createdBy: 'DTC Brand C',
      lastUpdated: '1 week ago',
      tags: ['Premium', 'Value', 'Positioning']
    }
  ];

  const navigationItems = [
    { key: 'overview' as AgencyView, label: 'Portfolio Overview', icon: LayoutGrid },
    { key: 'insights' as AgencyView, label: 'Cross-Account Insights', icon: BarChart3 },
    { key: 'learnings' as AgencyView, label: 'Shared Learning Pool', icon: Database },
    { key: 'templates' as AgencyView, label: 'Template Library', icon: FileText }
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-[1600px] mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <AccountSwitcher
            accounts={accounts}
            currentAccountId={currentAccountId}
            onSwitch={(id) => {
              setCurrentAccountId(id);
              toast.success(`Switched to ${accounts.find(a => a.id === id)?.name}`);
            }}
            onAddAccount={() => toast.success('Opening account connection...')}
          />

          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-xs text-muted-foreground">Portfolio Scale</div>
              <div className="text-sm font-bold text-foreground">
                {accounts.length} accounts • $248.2k/mo
              </div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex items-center gap-2 mb-8 border-b border-border">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.key}
                onClick={() => setCurrentView(item.key)}
                className={`px-4 py-3 font-semibold text-sm transition-colors relative flex items-center gap-2 ${
                  currentView === item.key
                    ? 'text-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon className="w-4 h-4" />
                {item.label}
                {currentView === item.key && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
                )}
              </button>
            );
          })}
        </div>

        {/* Content */}
        {currentView === 'overview' && (
          <div className="space-y-8">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">Portfolio Overview</h1>
              <p className="text-sm text-muted-foreground">
                Performance distribution across managed accounts
              </p>
            </div>
            <CrossAccountInsights
              accounts={accountPerformances}
              aggregateMetrics={{
                totalSpend: '$248.2k',
                averageROAS: '4.4x',
                totalAccounts: 6,
                activeAccounts: 5
              }}
            />
          </div>
        )}

        {currentView === 'insights' && (
          <div className="space-y-8">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">Cross-Account Analysis</h1>
              <p className="text-sm text-muted-foreground">
                Comparative performance metrics and trend identification
              </p>
            </div>
            <CrossAccountInsights
              accounts={accountPerformances}
              aggregateMetrics={{
                totalSpend: '$248.2k',
                averageROAS: '4.4x',
                totalAccounts: 6,
                activeAccounts: 5
              }}
            />
          </div>
        )}

        {currentView === 'learnings' && (
          <SharedLearningPool
            learnings={sharedLearnings}
            organizationName="ACME Digital Agency"
            totalAccounts={5}
          />
        )}

        {currentView === 'templates' && (
          <TemplateLibrary
            templates={templates}
            onApplyTemplate={(id) => console.log('Apply', id)}
            onCloneTemplate={(id) => console.log('Clone', id)}
          />
        )}
      </div>
    </div>
  );
}
