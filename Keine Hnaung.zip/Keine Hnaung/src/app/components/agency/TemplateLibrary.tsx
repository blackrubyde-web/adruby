import React, { useState } from 'react';
import { FileText, Copy, Lock, TrendingUp, Download } from 'lucide-react';
import { toast } from 'sonner';

export interface Template {
  id: string;
  name: string;
  type: 'hook' | 'creative' | 'campaign' | 'strategy';
  description: string;
  performance: {
    accounts: number;
    avgROAS: string;
    avgCTR: string;
  };
  isPrivate: boolean;
  createdBy: string; // Account or organization
  lastUpdated: string;
  tags: string[];
}

interface TemplateLibraryProps {
  templates: Template[];
  onApplyTemplate?: (templateId: string) => void;
  onCloneTemplate?: (templateId: string) => void;
}

export function TemplateLibrary({ templates, onApplyTemplate, onCloneTemplate }: TemplateLibraryProps) {
  const [filterType, setFilterType] = useState<Template['type'] | 'all'>('all');

  const filteredTemplates = filterType === 'all'
    ? templates
    : templates.filter(t => t.type === filterType);

  const typeConfig: Record<Template['type'], { label: string; color: string; bg: string }> = {
    hook: { label: 'Hook', color: 'text-blue-600', bg: 'bg-blue-500/10' },
    creative: { label: 'Creative', color: 'text-purple-600', bg: 'bg-purple-500/10' },
    campaign: { label: 'Campaign', color: 'text-green-600', bg: 'bg-green-500/10' },
    strategy: { label: 'Strategy', color: 'text-primary', bg: 'bg-primary/10' }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-foreground mb-1">Template Library</h2>
          <p className="text-sm text-muted-foreground">
            Proven patterns from your portfolio
          </p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold text-foreground">{templates.length}</div>
          <div className="text-xs text-muted-foreground">Templates</div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setFilterType('all')}
          className={`px-4 py-2 rounded-lg font-semibold text-sm transition-all ${
            filterType === 'all'
              ? 'bg-foreground text-background'
              : 'bg-card border border-border text-foreground hover:bg-muted/50'
          }`}
        >
          All ({templates.length})
        </button>
        {(Object.keys(typeConfig) as Template['type'][]).map((type) => {
          const count = templates.filter(t => t.type === type).length;
          return (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-4 py-2 rounded-lg font-semibold text-sm transition-all ${
                filterType === type
                  ? 'bg-foreground text-background'
                  : 'bg-card border border-border text-foreground hover:bg-muted/50'
              }`}
            >
              {typeConfig[type].label} ({count})
            </button>
          );
        })}
      </div>

      {/* Template Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredTemplates.map((template) => {
          const config = typeConfig[template.type];
          
          return (
            <div
              key={template.id}
              className="bg-card border border-border rounded-xl p-5 hover:shadow-lg transition-all"
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 ${config.bg} rounded-lg flex items-center justify-center`}>
                    <FileText className={`w-4 h-4 ${config.color}`} />
                  </div>
                  <div>
                    <h3 className="font-bold text-foreground text-sm">{template.name}</h3>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className={`text-xs font-semibold ${config.color}`}>
                        {config.label}
                      </span>
                      {template.isPrivate && (
                        <>
                          <span className="text-xs text-muted-foreground">•</span>
                          <Lock className="w-3 h-3 text-muted-foreground" />
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Description */}
              <p className="text-xs text-muted-foreground mb-4 leading-relaxed">
                {template.description}
              </p>

              {/* Performance */}
              <div className="grid grid-cols-3 gap-3 mb-4 p-3 bg-muted/20 rounded-lg">
                <div>
                  <div className="text-xs text-muted-foreground mb-0.5">Accounts</div>
                  <div className="text-sm font-bold text-foreground">{template.performance.accounts}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground mb-0.5">Avg ROAS</div>
                  <div className="text-sm font-bold text-green-600">{template.performance.avgROAS}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground mb-0.5">Avg CTR</div>
                  <div className="text-sm font-bold text-foreground">{template.performance.avgCTR}</div>
                </div>
              </div>

              {/* Tags */}
              {template.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mb-4">
                  {template.tags.map((tag, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 bg-muted text-foreground rounded text-xs"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              )}

              {/* Meta */}
              <div className="flex items-center justify-between mb-4 pb-4 border-b border-border">
                <div className="text-xs text-muted-foreground">
                  by {template.createdBy}
                </div>
                <div className="text-xs text-muted-foreground">
                  {template.lastUpdated}
                </div>
              </div>

              {/* Actions */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    onApplyTemplate?.(template.id);
                    toast.success(`Applying ${template.name}...`);
                  }}
                  className="px-4 py-2 bg-foreground text-background rounded-lg text-xs font-bold hover:bg-foreground/90 transition-all flex items-center justify-center gap-2"
                >
                  <Download className="w-3 h-3" />
                  Apply
                </button>
                <button
                  onClick={() => {
                    onCloneTemplate?.(template.id);
                    toast.success(`Cloning ${template.name}...`);
                  }}
                  className="px-4 py-2 bg-card border border-border text-foreground rounded-lg text-xs font-bold hover:bg-muted/50 transition-all flex items-center justify-center gap-2"
                >
                  <Copy className="w-3 h-3" />
                  Clone
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
