import React, { useState } from 'react';
import { Building2, ChevronDown, Search, Plus, Check } from 'lucide-react';

export interface Account {
  id: string;
  name: string;
  organization?: string;
  spend30d: string;
  roas30d: string;
  status: 'active' | 'paused' | 'warning';
  isAgency?: boolean;
}

interface AccountSwitcherProps {
  accounts: Account[];
  currentAccountId: string;
  onSwitch: (accountId: string) => void;
  onAddAccount?: () => void;
}

export function AccountSwitcher({ accounts, currentAccountId, onSwitch, onAddAccount }: AccountSwitcherProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const currentAccount = accounts.find(a => a.id === currentAccountId);

  // Group by organization
  const groupedAccounts = accounts.reduce((acc, account) => {
    const org = account.organization || 'Personal';
    if (!acc[org]) acc[org] = [];
    acc[org].push(account);
    return acc;
  }, {} as Record<string, Account[]>);

  const filteredAccounts = searchQuery
    ? accounts.filter(a => 
        a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        a.organization?.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : accounts;

  const getStatusColor = (status: Account['status']) => {
    if (status === 'active') return 'bg-green-600';
    if (status === 'warning') return 'bg-yellow-600';
    return 'bg-gray-400';
  };

  if (!currentAccount) return null;

  return (
    <div className="relative">
      {/* Trigger */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-3 px-4 py-2.5 bg-card border border-border rounded-lg hover:border-border/60 transition-all min-w-[280px]"
      >
        <div className="w-8 h-8 bg-foreground text-background rounded flex items-center justify-center flex-shrink-0">
          <Building2 className="w-4 h-4" />
        </div>
        <div className="flex-1 text-left min-w-0">
          <div className="text-sm font-bold text-foreground truncate">
            {currentAccount.name}
          </div>
          {currentAccount.organization && (
            <div className="text-xs text-muted-foreground truncate">
              {currentAccount.organization}
            </div>
          )}
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <div className={`w-2 h-2 rounded-full ${getStatusColor(currentAccount.status)}`} />
          <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        </div>
      </button>

      {/* Dropdown */}
      {isOpen && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />

          {/* Menu */}
          <div className="absolute top-full left-0 right-0 mt-2 bg-card border border-border rounded-xl shadow-2xl z-50 overflow-hidden max-h-[600px] flex flex-col">
            {/* Search */}
            <div className="p-3 border-b border-border">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search accounts..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                  autoFocus
                />
              </div>
            </div>

            {/* Account List */}
            <div className="overflow-y-auto flex-1">
              {searchQuery ? (
                // Flat list when searching
                <div className="p-2">
                  {filteredAccounts.map((account) => (
                    <AccountItem
                      key={account.id}
                      account={account}
                      isActive={account.id === currentAccountId}
                      onClick={() => {
                        onSwitch(account.id);
                        setIsOpen(false);
                      }}
                    />
                  ))}
                </div>
              ) : (
                // Grouped by organization
                <div>
                  {Object.entries(groupedAccounts).map(([org, orgAccounts]) => (
                    <div key={org}>
                      <div className="px-4 py-2 bg-muted/30 border-b border-border">
                        <div className="text-xs font-bold text-foreground uppercase tracking-wide">
                          {org}
                        </div>
                      </div>
                      <div className="p-2">
                        {orgAccounts.map((account) => (
                          <AccountItem
                            key={account.id}
                            account={account}
                            isActive={account.id === currentAccountId}
                            onClick={() => {
                              onSwitch(account.id);
                              setIsOpen(false);
                            }}
                          />
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-3 border-t border-border bg-muted/20">
              <button
                onClick={() => {
                  onAddAccount?.();
                  setIsOpen(false);
                }}
                className="w-full px-3 py-2 bg-foreground text-background rounded-lg text-sm font-semibold hover:bg-foreground/90 transition-all flex items-center justify-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Connect New Account
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function AccountItem({ account, isActive, onClick }: { 
  account: Account; 
  isActive: boolean; 
  onClick: () => void;
}) {
  const getStatusColor = (status: Account['status']) => {
    if (status === 'active') return 'bg-green-600';
    if (status === 'warning') return 'bg-yellow-600';
    return 'bg-gray-400';
  };

  return (
    <button
      onClick={onClick}
      className={`w-full px-3 py-2.5 rounded-lg transition-all flex items-center gap-3 text-left ${
        isActive
          ? 'bg-primary/10 border border-primary/20'
          : 'hover:bg-muted/50'
      }`}
    >
      <div className={`w-8 h-8 rounded flex items-center justify-center flex-shrink-0 ${
        isActive ? 'bg-primary text-white' : 'bg-muted text-foreground'
      }`}>
        <Building2 className="w-4 h-4" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5">
          <span className="text-sm font-semibold text-foreground truncate">
            {account.name}
          </span>
          {isActive && <Check className="w-3 h-3 text-primary flex-shrink-0" />}
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span>Spend: {account.spend30d}</span>
          <span>•</span>
          <span>ROAS: {account.roas30d}</span>
        </div>
      </div>
      <div className={`w-2 h-2 rounded-full ${getStatusColor(account.status)} flex-shrink-0`} />
    </button>
  );
}
