import React from 'react';
import { SeverityBadge, SeverityLevel } from './SeverityBadge';
import { TrendingDown, TrendingUp, Minus } from 'lucide-react';

export interface DiagnosisCardProps {
  title: string;
  severity: SeverityLevel;
  impact: {
    metric: 'CPA' | 'CTR' | 'ROAS' | 'Spend';
    direction: 'increase' | 'decrease' | 'neutral';
    value: string;
  };
  explanation: string;
  recommendation: string;
  onTakeAction?: () => void;
}

export function DiagnosisCard({
  title,
  severity,
  impact,
  explanation,
  recommendation,
  onTakeAction
}: DiagnosisCardProps) {
  const ImpactIcon = impact.direction === 'increase' 
    ? TrendingUp 
    : impact.direction === 'decrease' 
    ? TrendingDown 
    : Minus;

  const impactColor = 
    impact.metric === 'CPA' 
      ? impact.direction === 'increase' ? 'text-red-600' : 'text-green-600'
      : impact.metric === 'ROAS'
      ? impact.direction === 'increase' ? 'text-green-600' : 'text-red-600'
      : impact.direction === 'increase' ? 'text-green-600' : 'text-red-600';

  return (
    <div className="bg-card border border-border rounded-xl p-6 hover:border-border/80 transition-all group">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="font-bold text-foreground mb-2 leading-tight">
            {title}
          </h3>
          <SeverityBadge level={severity} />
        </div>
      </div>

      {/* Impact */}
      <div className="mb-4 p-3 bg-muted/40 rounded-lg border border-border/40">
        <div className="flex items-center gap-2 mb-1">
          <ImpactIcon className={`w-4 h-4 ${impactColor}`} />
          <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
            Estimated Impact
          </span>
        </div>
        <div className={`text-lg font-bold ${impactColor}`}>
          {impact.value} {impact.metric}
        </div>
      </div>

      {/* Explanation */}
      <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
        {explanation}
      </p>

      {/* Recommendation */}
      <div className="mb-5 p-3 bg-blue-500/5 border border-blue-500/10 rounded-lg">
        <div className="text-xs font-semibold text-blue-600 mb-1 uppercase tracking-wide">
          Recommended Direction
        </div>
        <p className="text-sm text-foreground font-medium">
          {recommendation}
        </p>
      </div>

      {/* Action Button */}
      {onTakeAction && (
        <button
          onClick={onTakeAction}
          className="w-full px-4 py-2.5 bg-foreground text-background rounded-lg font-semibold text-sm hover:bg-foreground/90 transition-all group-hover:shadow-md"
        >
          Execute Fix →
        </button>
      )}
    </div>
  );
}
