import React, { useState } from 'react';
import { DecisionCard, ConfidenceLevel, ImpactLevel } from './DecisionCard';
import { NextActionPanel } from './NextActionPanel';
import { ProactiveLearningCard } from './ProactiveLearningCard';
import { ChevronDown, ChevronRight, MoreVertical } from 'lucide-react';
import { notifications } from '../../lib/notifications';

interface Decision {
  id: string;
  priority: number;
  decision: string;
  why: string;
  impact: ImpactLevel;
  confidence: ConfidenceLevel;
  estimatedChange: {
    metric: 'CPA' | 'CTR' | 'ROAS' | 'Revenue';
    value: string;
    direction: 'increase' | 'decrease';
  };
  actionLabel: string;
  onExecute: () => void;
}

interface AIAnalysisDashboardProps {
  onNavigateToBuilder?: () => void;
}

export function AIAnalysisDashboard({ onNavigateToBuilder }: AIAnalysisDashboardProps) {
  const [selectedCampaign, setSelectedCampaign] = useState('Summer Sale 2024');
  const [showInsights, setShowInsights] = useState(false);

  const campaigns = [
    'Summer Sale 2024',
    'Black Friday Pre-Launch',
    'Holiday Bundle Campaign',
    'Spring Collection Launch'
  ];

  // DECISIONS, not problems
  const decisions: Decision[] = [
    {
      id: '1',
      priority: 1,
      decision: 'Replace hooks in top-performing ads',
      why: 'Your best-performing creative loses 67% of viewers in the first 1.8 seconds. Competitors in your vertical hold attention for 3.5+ seconds. This is directly costing you $2.30 per conversion.',
      impact: 'high',
      confidence: 'high',
      estimatedChange: {
        metric: 'CPA',
        value: '-$2.30',
        direction: 'decrease'
      },
      actionLabel: 'Generate New Hooks',
      onExecute: () => {
        notifications.variantsGenerated(4);
        onNavigateToBuilder?.();
      }
    },
    {
      id: '2',
      priority: 2,
      decision: 'Add social proof to landing page creatives',
      why: 'Your offer converts 12% of clicks. Similar offers with testimonials convert at 34%. You\'re leaving money on the table because users don\'t trust the claim yet.',
      impact: 'high',
      confidence: 'high',
      estimatedChange: {
        metric: 'CTR',
        value: '+0.4%',
        direction: 'increase'
      },
      actionLabel: 'Add Proof Elements',
      onExecute: () => {
        notifications.templateApplied('Social Proof Template');
        onNavigateToBuilder?.();
      }
    },
    {
      id: '3',
      priority: 3,
      decision: 'Refresh visual style while keeping copy',
      why: 'Stock photo aesthetic underperforms product-in-use visuals by 23% for your demographic. Your copy is strong - don\'t touch it. Just update the visuals.',
      impact: 'medium',
      confidence: 'high',
      estimatedChange: {
        metric: 'CTR',
        value: '+0.3%',
        direction: 'increase'
      },
      actionLabel: 'Refresh Visuals',
      onExecute: () => {
        notifications.variantsGenerated(3);
        onNavigateToBuilder?.();
      }
    },
    {
      id: '4',
      priority: 4,
      decision: 'Prepare variant of winning creative now',
      why: 'Creative #3 (carousel) has been running at ROAS 5.2x for 18 days. Frequency is at 3.8. Historical data shows this format fatigues at 4.2 with sharp CPA spike within 48 hours.',
      impact: 'medium',
      confidence: 'medium',
      estimatedChange: {
        metric: 'ROAS',
        value: 'Prevent -0.8x drop',
        direction: 'decrease'
      },
      actionLabel: 'Clone & Prepare Variant',
      onExecute: () => {
        notifications.optimizationApplied();
        onNavigateToBuilder?.();
      }
    }
  ];

  const topDecision = decisions[0];
  const remainingDecisions = decisions.slice(1);

  const handleExecuteAll = () => {
    const highConfidenceCount = decisions.filter(d => d.confidence === 'high').length;
    notifications.optimizationApplied();
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-[1400px] mx-auto px-6 py-8">
        {/* Simplified Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            {/* Campaign Selector - Minimal */}
            <div className="flex items-center gap-4">
              <div className="relative">
                <select
                  value={selectedCampaign}
                  onChange={(e) => setSelectedCampaign(e.target.value)}
                  className="appearance-none pl-4 pr-10 py-2.5 bg-card border border-border rounded-lg font-semibold text-foreground text-sm cursor-pointer hover:border-border/60 transition-colors focus:outline-none focus:ring-2 focus:ring-primary/20"
                >
                  {campaigns.map((campaign) => (
                    <option key={campaign} value={campaign}>
                      {campaign}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              </div>

              {/* Status - Single Badge */}
              <div className="px-3 py-1.5 bg-green-500/10 border border-green-500/20 rounded-lg">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-600" />
                  <span className="text-sm font-semibold text-green-600">Scaling</span>
                </div>
              </div>
            </div>

            {/* Overflow Menu - Hidden unless needed */}
            <button className="p-2 hover:bg-muted/50 rounded-lg transition-colors">
              <MoreVertical className="w-5 h-5 text-muted-foreground" />
            </button>
          </div>

          {/* Page Title */}
          <h1 className="text-3xl font-bold text-foreground mb-2">
            What to Do Next
          </h1>
          <p className="text-sm text-muted-foreground">
            AI-analyzed decisions ranked by impact and confidence
          </p>
        </div>

        {/* 2-Column Layout (NOT 3) */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* MAIN COLUMN - Decisions (spans 2) */}
          <div className="lg:col-span-2 space-y-6">
            {/* Recommended Next Action */}
            <NextActionPanel
              topAction={{
                id: topDecision.id,
                title: topDecision.decision,
                confidence: topDecision.confidence,
                onExecute: topDecision.onExecute
              }}
              highConfidenceActions={decisions}
              onExecuteAll={handleExecuteAll}
            />

            {/* #1 Priority - HERO CARD */}
            <DecisionCard
              {...topDecision}
              isPrimary={true}
            />

            {/* Remaining Decisions */}
            <div className="space-y-3">
              {remainingDecisions.map((decision) => (
                <DecisionCard
                  key={decision.id}
                  {...decision}
                  isPrimary={false}
                />
              ))}
            </div>
          </div>

          {/* RIGHT COLUMN - Context (Collapsible) */}
          <div className="space-y-6">
            {/* Campaign Health - Simplified */}
            <div className="bg-card border border-border rounded-xl p-5">
              <h3 className="font-bold text-foreground mb-4 text-sm">Campaign Health</h3>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">CTR</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-foreground">2.8%</span>
                    <span className="text-xs text-green-600 font-semibold">↑12.5%</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">CPA</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-foreground">$8.45</span>
                    <span className="text-xs text-green-600 font-semibold">↓8.2%</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">ROAS</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-foreground">4.8x</span>
                    <span className="text-xs text-green-600 font-semibold">↑15.3%</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Spend</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-foreground">$2.3k</span>
                    <span className="text-xs text-blue-600 font-semibold">↑23.1%</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Insights - Collapsible */}
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              <button
                onClick={() => setShowInsights(!showInsights)}
                className="w-full p-5 flex items-center justify-between hover:bg-muted/30 transition-colors"
              >
                <h3 className="font-bold text-foreground text-sm">Additional Insights</h3>
                {showInsights ? (
                  <ChevronDown className="w-4 h-4 text-muted-foreground" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                )}
              </button>

              {showInsights && (
                <div className="px-5 pb-5 space-y-3 border-t border-border pt-4">
                  <div className="p-3 bg-muted/30 rounded-lg">
                    <div className="text-xs font-semibold text-foreground mb-1">
                      Creative Fatigue Risk
                    </div>
                    <div className="text-xs text-muted-foreground">
                      2 creatives showing early fatigue signs
                    </div>
                  </div>
                  <div className="p-3 bg-muted/30 rounded-lg">
                    <div className="text-xs font-semibold text-foreground mb-1">
                      Audience Overlap
                    </div>
                    <div className="text-xs text-muted-foreground">
                      18% overlap between ad sets detected
                    </div>
                  </div>
                  <div className="p-3 bg-muted/30 rounded-lg">
                    <div className="text-xs font-semibold text-foreground mb-1">
                      Best Performing Time
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Peak performance: 6pm - 9pm EST
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Proactive Learning Card */}
            <ProactiveLearningCard
              learnings={[
                'Pain-point hooks outperform curiosity hooks by 33% CTR for your cold traffic',
                'Product screenshots outperform lifestyle visuals by 37% for your B2B audience',
                'Creative fatigue hits at frequency 4.2 (around day 18-21) - prepare refreshes early'
              ]}
              onViewAll={() => notifications.dataRefreshed()}
            />
          </div>
        </div>
      </div>
    </div>
  );
}