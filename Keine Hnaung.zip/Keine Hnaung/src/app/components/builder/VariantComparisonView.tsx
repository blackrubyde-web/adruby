import React from 'react';
import { Check, TrendingUp, Copy } from 'lucide-react';

export interface Variant {
  id: string;
  name: string;
  purpose: string; // WHY this variant exists
  changes: string[]; // What changed from control
  isControl?: boolean;
  isWinner?: boolean;
  performance?: {
    ctr: string;
    cpa: string;
    improvement: string;
  };
}

interface VariantComparisonViewProps {
  variants: Variant[];
  onSelectVariant?: (id: string) => void;
  onDuplicateVariant?: (id: string) => void;
}

export function VariantComparisonView({ variants, onSelectVariant, onDuplicateVariant }: VariantComparisonViewProps) {
  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-bold text-foreground">Variant Comparison</h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            Each variant tests a specific hypothesis
          </p>
        </div>
        <div className="text-xs text-muted-foreground">
          {variants.length} variants generated
        </div>
      </div>

      {/* Variant Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {variants.map((variant) => (
          <div
            key={variant.id}
            className={`bg-card border rounded-xl p-4 transition-all hover:shadow-lg cursor-pointer ${
              variant.isWinner
                ? 'border-green-500 ring-2 ring-green-500/20'
                : variant.isControl
                ? 'border-blue-500'
                : 'border-border hover:border-primary/40'
            }`}
            onClick={() => onSelectVariant?.(variant.id)}
          >
            {/* Badges */}
            <div className="flex items-center gap-2 mb-3">
              {variant.isControl && (
                <div className="px-2 py-1 bg-blue-500/10 border border-blue-500/20 rounded text-[10px] font-bold text-blue-600 uppercase">
                  Control
                </div>
              )}
              {variant.isWinner && (
                <div className="px-2 py-1 bg-green-500/10 border border-green-500/20 rounded text-[10px] font-bold text-green-600 uppercase flex items-center gap-1">
                  <Check className="w-3 h-3" />
                  Winner
                </div>
              )}
              <div className="ml-auto text-xs font-bold text-muted-foreground">
                {variant.name}
              </div>
            </div>

            {/* Preview Placeholder */}
            <div className="aspect-square bg-gradient-to-br from-muted/40 to-muted/20 rounded-lg mb-3 flex items-center justify-center border border-border">
              <div className="text-4xl">🎨</div>
            </div>

            {/* Purpose */}
            <div className="mb-3">
              <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-wide mb-1">
                Testing Purpose
              </div>
              <p className="text-xs text-foreground font-medium leading-relaxed">
                {variant.purpose}
              </p>
            </div>

            {/* Changes */}
            <div className="mb-3">
              <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-wide mb-1.5">
                What Changed
              </div>
              <div className="space-y-1">
                {variant.changes.map((change, i) => (
                  <div key={i} className="flex items-start gap-2">
                    <div className="w-1 h-1 rounded-full bg-primary flex-shrink-0 mt-1.5" />
                    <span className="text-xs text-foreground">{change}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Performance (if available) */}
            {variant.performance && (
              <div className="pt-3 border-t border-border">
                <div className="grid grid-cols-2 gap-2 mb-2">
                  <div>
                    <div className="text-[10px] text-muted-foreground">CTR</div>
                    <div className="text-xs font-bold text-foreground">{variant.performance.ctr}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-muted-foreground">CPA</div>
                    <div className="text-xs font-bold text-foreground">{variant.performance.cpa}</div>
                  </div>
                </div>
                {variant.performance.improvement && (
                  <div className="flex items-center gap-1.5 text-xs font-bold text-green-600">
                    <TrendingUp className="w-3 h-3" />
                    {variant.performance.improvement}
                  </div>
                )}
              </div>
            )}

            {/* Actions */}
            <div className="mt-3 pt-3 border-t border-border flex items-center gap-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectVariant?.(variant.id);
                }}
                className="flex-1 px-3 py-2 bg-foreground text-background rounded-lg text-xs font-bold hover:bg-foreground/90 transition-all"
              >
                View Details
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDuplicateVariant?.(variant.id);
                }}
                className="px-3 py-2 bg-muted hover:bg-muted/70 rounded-lg transition-all"
              >
                <Copy className="w-4 h-4 text-foreground" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
