import React from 'react';
import { Target, TrendingUp, AlertCircle } from 'lucide-react';

interface VariantCardProps {
  variant: {
    id: string;
    hypothesis: string;
    description: string;
    testingContext: string;
    expectedImpact: 'high' | 'medium' | 'low';
    headline: string;
    bodyText: string;
    cta: string;
  };
  isSelected: boolean;
  onSelect: () => void;
}

export function VariantCard({ variant, isSelected, onSelect }: VariantCardProps) {
  const impactConfig = {
    high: { label: 'High Impact', color: 'text-green-600', bg: 'bg-green-500/10', border: 'border-green-500/20' },
    medium: { label: 'Medium Impact', color: 'text-yellow-600', bg: 'bg-yellow-500/10', border: 'border-yellow-500/20' },
    low: { label: 'Low Impact', color: 'text-gray-600', bg: 'bg-gray-500/10', border: 'border-gray-500/20' }
  };

  const impact = impactConfig[variant.expectedImpact];

  return (
    <div
      onClick={onSelect}
      className={`border-2 rounded-xl p-5 cursor-pointer transition-all ${
        isSelected
          ? 'border-primary bg-primary/5 shadow-lg'
          : 'border-border bg-card hover:border-border/80 hover:shadow-md'
      }`}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${impact.bg} ${impact.border} border`}>
            <Target className={`w-4 h-4 ${impact.color}`} />
          </div>
          <div className={`px-2 py-1 rounded ${impact.bg} ${impact.border} border`}>
            <span className={`text-xs font-bold ${impact.color}`}>
              {impact.label}
            </span>
          </div>
        </div>

        {/* Selection Indicator */}
        {isSelected && (
          <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
            <div className="text-white text-xs font-bold">✓</div>
          </div>
        )}
      </div>

      {/* Hypothesis */}
      <div className="mb-4">
        <div className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-1">
          Hypothesis
        </div>
        <h3 className="font-bold text-foreground mb-2">
          {variant.hypothesis}
        </h3>
        <p className="text-sm text-muted-foreground">
          {variant.description}
        </p>
      </div>

      {/* Testing Context */}
      <div className="bg-blue-500/5 border border-blue-500/10 rounded-lg p-3 mb-4">
        <div className="flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
          <div>
            <div className="text-xs font-bold text-blue-600 mb-1">
              What This Tests
            </div>
            <p className="text-xs text-foreground">
              {variant.testingContext}
            </p>
          </div>
        </div>
      </div>

      {/* Preview */}
      <div className="bg-muted/30 border border-border rounded-lg p-4">
        <div className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-2">
          Creative Preview
        </div>
        <div className="space-y-2">
          <div>
            <div className="text-xs text-muted-foreground mb-1">Headline</div>
            <div className="font-bold text-foreground text-sm">{variant.headline}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground mb-1">Body</div>
            <div className="text-sm text-foreground">{variant.bodyText}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground mb-1">CTA</div>
            <div className="inline-block px-3 py-1.5 bg-primary text-white rounded text-sm font-semibold">
              {variant.cta}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
