import React, { useState } from 'react';
import { ArrowLeft, Info, AlertCircle, CheckCircle2, TrendingUp } from 'lucide-react';
import { VariantCard } from './VariantCard';
import { PrecisionComparisonView } from './PrecisionComparisonView';
import { PhilosophyStatement } from '../differentiation/PhilosophyStatement';
import { HowThisWorks } from '../differentiation/HowThisWorks';
import { toast } from 'sonner';

interface CreativeBuilderPageProps {
  reason?: string;
  onBack?: () => void;
}

export function CreativeBuilderPage({ reason, onBack }: CreativeBuilderPageProps) {
  return <PrecisionCreativeBuilder reason={reason} onBack={onBack} />;
}

function PrecisionCreativeBuilder({ reason, onBack }: CreativeBuilderPageProps) {
  return (
    <div className="min-h-screen bg-background pb-16">
      <div className="max-w-[1400px] mx-auto px-6 py-8">
        {/* Back Button */}
        {onBack && (
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Analysis
          </button>
        )}

        {/* Header with Why Context */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Precision Creative Builder
          </h1>
          <p className="text-sm text-muted-foreground mb-4">
            Hypothesis-driven variant generation with testing context
          </p>

          {/* Why This Decision */}
          {reason && (
            <div className="bg-blue-500/5 border border-blue-500/10 rounded-xl p-4 flex items-start gap-3">
              <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <div className="text-sm font-semibold text-foreground mb-1">
                  Why you're here
                </div>
                <p className="text-sm text-muted-foreground">
                  {reason}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Philosophy Statement */}
        <div className="mb-8">
          <PhilosophyStatement context="creative-builder" />
        </div>

        {/* How This Works */}
        <div className="mb-8">
          <HowThisWorks
            title="How Hypothesis-Driven Generation Works"
            steps={[
              {
                label: 'Analyze your account patterns',
                description: 'System reviews your historical performance data to identify what works for your specific audience'
              },
              {
                label: 'Generate targeted hypotheses',
                description: 'Each variant tests a specific hypothesis (e.g., "Pain-point hooks outperform benefit-first hooks")'
              },
              {
                label: 'Provide testing context',
                description: 'You know exactly what each variant is testing and why it matters for your account'
              }
            ]}
            insight="This approach generates 3-5 variants with clear purpose instead of 100+ random variations"
          />
        </div>

        {/* Hypothesis Selection */}
      </div>
    </div>
  );
}