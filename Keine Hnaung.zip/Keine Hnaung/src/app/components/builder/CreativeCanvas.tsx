import React from 'react';
import { Maximize2, Copy } from 'lucide-react';

interface CreativeCanvasProps {
  selectedTemplate: string | null;
  format: '1:1' | '4:5' | '9:16';
  onFormatChange: (format: '1:1' | '4:5' | '9:16') => void;
  variantCount: number;
}

export function CreativeCanvas({
  selectedTemplate,
  format,
  onFormatChange,
  variantCount
}: CreativeCanvasProps) {
  const formatConfig = {
    '1:1': { label: 'Square', ratio: 'aspect-square' },
    '4:5': { label: 'Portrait', ratio: 'aspect-[4/5]' },
    '9:16': { label: 'Story', ratio: 'aspect-[9/16]' }
  };

  return (
    <div className="p-8">
      {/* Toolbar */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-foreground mb-1">Creative Canvas</h2>
          <p className="text-sm text-muted-foreground">
            {selectedTemplate ? `Template: ${selectedTemplate}` : 'Select a template to start'}
          </p>
        </div>

        {/* Format Selector */}
        <div className="flex items-center gap-2 bg-card border border-border rounded-lg p-1">
          {(Object.keys(formatConfig) as Array<keyof typeof formatConfig>).map((f) => (
            <button
              key={f}
              onClick={() => onFormatChange(f)}
              className={`px-3 py-1.5 rounded text-xs font-semibold transition-all ${
                format === f
                  ? 'bg-foreground text-background'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {formatConfig[f].label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Preview */}
      {selectedTemplate ? (
        <>
          <div className="mb-6 flex justify-center">
            <div className="relative group">
              <div className={`w-96 ${formatConfig[format].ratio} bg-card border-2 border-border rounded-xl overflow-hidden shadow-xl`}>
                {/* Mock Ad Preview */}
                <div className="h-full flex flex-col">
                  {/* Ad Header */}
                  <div className="p-3 border-b border-border flex items-center gap-2 bg-white">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center text-white font-bold text-xs">
                      AR
                    </div>
                    <div className="flex-1">
                      <div className="text-xs font-semibold text-foreground">AdRuby Brand</div>
                      <div className="text-[10px] text-muted-foreground">Sponsored</div>
                    </div>
                  </div>

                  {/* Ad Copy */}
                  <div className="p-4 bg-white">
                    <p className="text-sm text-foreground mb-2">
                      <strong>Transform your ad creative workflow</strong> with AI-powered analysis
                    </p>
                  </div>

                  {/* Ad Visual */}
                  <div className="flex-1 bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center">
                    <div className="text-center p-6">
                      <div className="text-6xl mb-3">🎨</div>
                      <div className="text-sm font-semibold text-foreground">Creative Preview</div>
                      <div className="text-xs text-muted-foreground mt-1">{format} Format</div>
                    </div>
                  </div>

                  {/* Ad CTA */}
                  <div className="p-4 bg-white border-t border-border">
                    <div className="text-xs font-bold text-foreground mb-2">Get Started Today</div>
                    <button className="w-full py-2 bg-primary text-white rounded text-xs font-semibold">
                      Learn More
                    </button>
                  </div>
                </div>
              </div>

              {/* Hover Actions */}
              <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity flex gap-2">
                <button className="p-2 bg-black/80 text-white rounded-lg hover:bg-black transition-colors">
                  <Maximize2 className="w-4 h-4" />
                </button>
                <button className="p-2 bg-black/80 text-white rounded-lg hover:bg-black transition-colors">
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Variant Thumbnails */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-foreground">
                Variants ({variantCount})
              </h3>
              <button className="text-xs font-semibold text-primary hover:underline">
                Compare Mode
              </button>
            </div>
            <div className="grid grid-cols-4 gap-3">
              {Array.from({ length: variantCount }).map((_, i) => (
                <div
                  key={i}
                  className="aspect-square bg-card border border-border rounded-lg overflow-hidden hover:border-primary/40 transition-all cursor-pointer group"
                >
                  <div className="h-full flex flex-col">
                    <div className="flex-1 bg-gradient-to-br from-blue-500/10 to-purple-500/10 flex items-center justify-center">
                      <div className="text-2xl">🎨</div>
                    </div>
                    <div className="p-2 bg-white border-t border-border">
                      <div className="text-[10px] font-semibold text-foreground">
                        Variant {i + 1}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      ) : (
        /* Empty State */
        <div className="h-96 flex items-center justify-center bg-muted/20 rounded-xl border-2 border-dashed border-border">
          <div className="text-center">
            <div className="text-6xl mb-4">🎨</div>
            <h3 className="font-bold text-foreground mb-2">No Template Selected</h3>
            <p className="text-sm text-muted-foreground">
              Choose a template from the library to start creating
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
