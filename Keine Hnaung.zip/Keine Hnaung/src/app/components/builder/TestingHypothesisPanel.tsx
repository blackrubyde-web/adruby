import React from 'react';
import { Target, AlertCircle } from 'lucide-react';

export type TestingFocus = 'hook' | 'visual' | 'copy' | 'cta' | 'proof' | 'offer';

interface TestingHypothesisPanelProps {
  focus: TestingFocus;
  hypothesis: string;
  controlElement: string;
  onChange?: (focus: TestingFocus, hypothesis: string) => void;
}

const focusConfig: Record<TestingFocus, { label: string; color: string; description: string }> = {
  hook: {
    label: 'Hook',
    color: 'text-blue-600',
    description: 'Testing different attention-grabbing openers'
  },
  visual: {
    label: 'Visual Style',
    color: 'text-purple-600',
    description: 'Testing visual approach while keeping copy constant'
  },
  copy: {
    label: 'Body Copy',
    color: 'text-green-600',
    description: 'Testing message angle and positioning'
  },
  cta: {
    label: 'Call to Action',
    color: 'text-orange-600',
    description: 'Testing CTA wording and urgency'
  },
  proof: {
    label: 'Social Proof',
    color: 'text-pink-600',
    description: 'Testing proof elements (testimonials, numbers, reviews)'
  },
  offer: {
    label: 'Offer Structure',
    color: 'text-primary',
    description: 'Testing offer presentation and framing'
  }
};

export function TestingHypothesisPanel({ focus, hypothesis, controlElement, onChange }: TestingHypothesisPanelProps) {
  const config = focusConfig[focus];

  return (
    <div className="bg-blue-500/5 border-l-4 border-blue-600 p-5 rounded-r-xl">
      {/* Header */}
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
          <Target className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="font-bold text-foreground text-sm">Testing Hypothesis</h3>
          <p className="text-xs text-muted-foreground">What you're testing and why</p>
        </div>
      </div>

      {/* Focus */}
      <div className="mb-4">
        <label className="text-xs font-semibold text-foreground mb-2 block uppercase tracking-wide">
          Testing Focus
        </label>
        <div className="grid grid-cols-3 gap-2">
          {(Object.keys(focusConfig) as TestingFocus[]).map((key) => (
            <button
              key={key}
              onClick={() => onChange?.(key, hypothesis)}
              className={`px-3 py-2 rounded-lg text-xs font-bold transition-all border ${
                focus === key
                  ? 'bg-primary text-white border-primary'
                  : 'bg-card border-border text-foreground hover:bg-muted/30'
              }`}
            >
              {focusConfig[key].label}
            </button>
          ))}
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          {config.description}
        </p>
      </div>

      {/* Hypothesis */}
      <div className="mb-4">
        <label className="text-xs font-semibold text-foreground mb-2 block uppercase tracking-wide">
          Hypothesis
        </label>
        <div className="p-3 bg-white rounded-lg border border-border">
          <p className="text-sm text-foreground font-medium">
            {hypothesis}
          </p>
        </div>
      </div>

      {/* Control Element */}
      <div className="p-3 bg-yellow-500/5 border border-yellow-500/20 rounded-lg">
        <div className="flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-yellow-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1 min-w-0">
            <div className="text-xs font-semibold text-yellow-600 mb-1">
              Control Element (Don't Change)
            </div>
            <div className="text-xs text-foreground">
              {controlElement}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
