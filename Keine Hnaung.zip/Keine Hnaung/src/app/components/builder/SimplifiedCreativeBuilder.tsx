import React, { useState } from 'react';
import { ArrowLeft, Sparkles, AlertTriangle, CheckCircle, Download, Settings } from 'lucide-react';
import { toast } from 'sonner';

interface SimplifiedCreativeBuilderProps {
  reason?: string;
  onBack?: () => void;
}

type ActiveView = 'edit' | 'quality' | 'export';

export function SimplifiedCreativeBuilder({ reason, onBack }: SimplifiedCreativeBuilderProps) {
  const [activeView, setActiveView] = useState<ActiveView>('edit');
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [variantCount, setVariantCount] = useState(4);

  // Templates grouped by intent
  const templateCategories = [
    {
      id: 'conversion',
      name: 'Conversion',
      emoji: '🎯',
      description: 'Direct offer with clear CTA',
      templates: ['Direct Offer', 'Discount Focus', 'Urgency']
    },
    {
      id: 'trust',
      name: 'Build Trust',
      emoji: '⭐',
      description: 'Social proof & testimonials',
      templates: ['Testimonial', 'Case Study', 'Review']
    },
    {
      id: 'awareness',
      name: 'Awareness',
      emoji: '💡',
      description: 'Problem/solution approach',
      templates: ['Pain Point', 'Before/After', 'Challenge']
    }
  ];

  // QA Issues
  const qaIssues = [
    { severity: 'error', title: 'Low contrast detected', autoFix: true },
    { severity: 'warning', title: 'Text too long (142 chars)', autoFix: true },
    { severity: 'warning', title: 'Claim may need proof', autoFix: false }
  ];

  const errorCount = qaIssues.filter(i => i.severity === 'error').length;
  const warningCount = qaIssues.filter(i => i.severity === 'warning').length;

  const handleGenerate = () => {
    if (!selectedTemplate) {
      toast.error('Select a template first');
      return;
    }
    toast.success(`Generating ${variantCount} variants...`);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Context Banner */}
      {reason && (
        <div className="bg-blue-500/10 border-b border-blue-500/20 px-6 py-3">
          <div className="max-w-[1600px] mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-white font-bold text-sm">→</span>
              </div>
              <div>
                <span className="text-xs font-semibold text-blue-600">You're here to fix: </span>
                <span className="text-sm font-semibold text-foreground">{reason}</span>
              </div>
            </div>
            {onBack && (
              <button
                onClick={onBack}
                className="px-3 py-1.5 bg-card border border-border rounded-lg text-xs font-semibold hover:bg-muted/50 transition-all flex items-center gap-2"
              >
                <ArrowLeft className="w-3 h-3" />
                Back
              </button>
            )}
          </div>
        </div>
      )}

      <div className="max-w-[1600px] mx-auto px-6 py-8">
        {/* Header with Primary Action */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold text-foreground mb-1">Creative Builder</h1>
              <p className="text-sm text-muted-foreground">
                Select template → Generate variants → Review quality → Export
              </p>
            </div>

            {/* Primary Action - Always Visible */}
            <button
              onClick={handleGenerate}
              disabled={!selectedTemplate}
              className="px-6 py-3 bg-primary text-white rounded-lg font-bold text-sm hover:bg-primary/90 transition-all shadow-md hover:shadow-lg flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Sparkles className="w-4 h-4" />
              Generate {variantCount} Variants
            </button>
          </div>

          {/* Simple 3-Tab Navigation */}
          <div className="flex items-center gap-2 border-b border-border">
            <button
              onClick={() => setActiveView('edit')}
              className={`px-4 py-2.5 font-semibold text-sm transition-colors relative ${
                activeView === 'edit'
                  ? 'text-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Edit
              {activeView === 'edit' && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
              )}
            </button>
            <button
              onClick={() => setActiveView('quality')}
              className={`px-4 py-2.5 font-semibold text-sm transition-colors relative flex items-center gap-2 ${
                activeView === 'quality'
                  ? 'text-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Quality Check
              {(errorCount > 0 || warningCount > 0) && (
                <span className="w-5 h-5 bg-red-600 text-white rounded-full text-[10px] font-bold flex items-center justify-center">
                  {errorCount + warningCount}
                </span>
              )}
              {activeView === 'quality' && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
              )}
            </button>
            <button
              onClick={() => setActiveView('export')}
              className={`px-4 py-2.5 font-semibold text-sm transition-colors relative ${
                activeView === 'export'
                  ? 'text-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Export
              {activeView === 'export' && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
              )}
            </button>
          </div>
        </div>

        {/* Content Area */}
        {activeView === 'edit' && (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Left - Template Selection */}
            <div className="lg:col-span-1">
              <div className="bg-card border border-border rounded-xl p-5 sticky top-6">
                <h3 className="font-bold text-foreground mb-4 text-sm">Choose Template</h3>
                
                {/* Variant Count */}
                <div className="mb-5 p-3 bg-muted/30 rounded-lg">
                  <label className="text-xs font-semibold text-foreground mb-2 block">
                    Variants to Generate
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {[4, 8, 12, 24].map((count) => (
                      <button
                        key={count}
                        onClick={() => setVariantCount(count)}
                        className={`px-2 py-1.5 rounded font-bold text-xs transition-all ${
                          variantCount === count
                            ? 'bg-primary text-white'
                            : 'bg-card border border-border text-foreground hover:bg-muted/50'
                        }`}
                      >
                        {count}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Template Categories */}
                <div className="space-y-2">
                  {templateCategories.map((category) => (
                    <button
                      key={category.id}
                      onClick={() => setSelectedTemplate(category.id)}
                      className={`w-full p-3 rounded-lg border transition-all text-left ${
                        selectedTemplate === category.id
                          ? 'border-primary bg-primary/5'
                          : 'border-border bg-card hover:bg-muted/30'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className="text-2xl">{category.emoji}</div>
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-sm text-foreground mb-0.5">
                            {category.name}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {category.description}
                          </div>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Center - Preview */}
            <div className="lg:col-span-3">
              {selectedTemplate ? (
                <div className="bg-card border border-border rounded-xl p-8">
                  <div className="max-w-md mx-auto">
                    {/* Mock Creative Preview */}
                    <div className="aspect-square bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-xl border-2 border-border flex items-center justify-center mb-6">
                      <div className="text-center">
                        <div className="text-6xl mb-3">🎨</div>
                        <div className="text-sm font-semibold text-foreground">
                          Template: {templateCategories.find(c => c.id === selectedTemplate)?.name}
                        </div>
                        <div className="text-xs text-muted-foreground mt-2">
                          Click "Generate" to create {variantCount} variants
                        </div>
                      </div>
                    </div>

                    {/* Quick Edit Controls */}
                    <div className="space-y-3">
                      <div>
                        <label className="text-xs font-semibold text-foreground mb-1.5 block">
                          Headline
                        </label>
                        <input
                          type="text"
                          placeholder="Enter headline..."
                          className="w-full px-3 py-2 bg-card border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                        />
                      </div>
                      <div>
                        <label className="text-xs font-semibold text-foreground mb-1.5 block">
                          Call to Action
                        </label>
                        <select className="w-full px-3 py-2 bg-card border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/20">
                          <option>Learn More</option>
                          <option>Shop Now</option>
                          <option>Get Started</option>
                          <option>Sign Up</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-muted/20 border-2 border-dashed border-border rounded-xl h-[600px] flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-6xl mb-4">👈</div>
                    <h3 className="font-bold text-foreground mb-2">Select a Template</h3>
                    <p className="text-sm text-muted-foreground">
                      Choose a template category to start creating
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {activeView === 'quality' && (
          <div className="max-w-3xl mx-auto">
            <div className="bg-card border border-border rounded-xl p-6">
              {/* QA Summary */}
              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg text-center">
                  <div className="text-2xl font-bold text-red-600">{errorCount}</div>
                  <div className="text-xs text-red-600 font-semibold">Errors</div>
                </div>
                <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg text-center">
                  <div className="text-2xl font-bold text-yellow-600">{warningCount}</div>
                  <div className="text-xs text-yellow-600 font-semibold">Warnings</div>
                </div>
                <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg text-center">
                  <div className="text-2xl font-bold text-green-600">2</div>
                  <div className="text-xs text-green-600 font-semibold">Passed</div>
                </div>
              </div>

              {/* Issues */}
              <div className="space-y-3 mb-6">
                {qaIssues.map((issue, i) => (
                  <div
                    key={i}
                    className={`p-4 rounded-lg border ${
                      issue.severity === 'error'
                        ? 'bg-red-500/5 border-red-500/20'
                        : 'bg-yellow-500/5 border-yellow-500/20'
                    }`}
                  >
                    <div className="flex items-start gap-3 mb-2">
                      <AlertTriangle
                        className={`w-5 h-5 flex-shrink-0 ${
                          issue.severity === 'error' ? 'text-red-600' : 'text-yellow-600'
                        }`}
                      />
                      <div className="flex-1">
                        <h4
                          className={`font-semibold text-sm ${
                            issue.severity === 'error' ? 'text-red-600' : 'text-yellow-600'
                          }`}
                        >
                          {issue.title}
                        </h4>
                      </div>
                    </div>
                    {issue.autoFix && (
                      <button className="ml-8 px-3 py-1.5 bg-foreground text-background rounded text-xs font-semibold hover:bg-foreground/90 transition-all">
                        Auto-Fix
                      </button>
                    )}
                  </div>
                ))}
              </div>

              {/* Primary Action */}
              <button className="w-full px-6 py-3 bg-primary text-white rounded-lg font-bold text-sm hover:bg-primary/90 transition-all">
                Fix All Auto-Fixable Issues
              </button>
            </div>
          </div>
        )}

        {activeView === 'export' && (
          <div className="max-w-2xl mx-auto">
            <div className="bg-card border border-border rounded-xl p-6">
              <h3 className="font-bold text-foreground mb-6">Export Settings</h3>
              
              {/* Format Selection */}
              <div className="space-y-3 mb-6">
                {['PNG (Web)', 'JPG (High Quality)', 'PDF (Print)', 'MP4 (Video)'].map((format) => (
                  <label
                    key={format}
                    className="flex items-center gap-3 p-4 bg-muted/30 border border-border rounded-lg cursor-pointer hover:bg-muted/50 transition-all"
                  >
                    <input type="radio" name="format" className="w-4 h-4" />
                    <span className="text-sm font-medium text-foreground">{format}</span>
                  </label>
                ))}
              </div>

              {/* Actions */}
              <div className="space-y-3">
                <button className="w-full px-6 py-3 bg-primary text-white rounded-lg font-bold text-sm hover:bg-primary/90 transition-all flex items-center justify-center gap-2">
                  <Download className="w-4 h-4" />
                  Export All Variants
                </button>
                <button className="w-full px-6 py-3 bg-foreground text-background rounded-lg font-bold text-sm hover:bg-foreground/90 transition-all">
                  Deploy to Meta Ads
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
