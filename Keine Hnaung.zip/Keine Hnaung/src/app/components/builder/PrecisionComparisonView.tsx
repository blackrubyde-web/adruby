import React from 'react';
import { TrendingUp, Target, Zap } from 'lucide-react';

interface Variant {
  id: string;
  hypothesis: string;
  description: string;
  testingContext: string;
  expectedImpact: 'high' | 'medium' | 'low';
  headline: string;
  bodyText: string;
  cta: string;
}

interface PrecisionComparisonViewProps {
  variants: Variant[];
  onDeploy: () => void;
}

export function PrecisionComparisonView({ variants, onDeploy }: PrecisionComparisonViewProps) {
  const impactConfig = {
    high: { label: 'High', color: 'text-green-600', bg: 'bg-green-500/10' },
    medium: { label: 'Medium', color: 'text-yellow-600', bg: 'bg-yellow-500/10' },
    low: { label: 'Low', color: 'text-gray-600', bg: 'bg-gray-500/10' }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/20 rounded-xl p-6">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-2">
              Variant Comparison
            </h2>
            <p className="text-sm text-muted-foreground">
              {variants.length} hypothesis-driven variants ready for testing
            </p>
          </div>
          <button
            onClick={onDeploy}
            className="px-6 py-3 bg-primary text-white rounded-lg font-semibold hover:bg-primary/90 transition-all"
          >
            Deploy All Variants
          </button>
        </div>
      </div>

      {/* Comparison Table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/20">
                <th className="px-4 py-3 text-left text-xs font-bold text-muted-foreground uppercase tracking-wide">
                  Variant
                </th>
                <th className="px-4 py-3 text-left text-xs font-bold text-muted-foreground uppercase tracking-wide">
                  Hypothesis
                </th>
                <th className="px-4 py-3 text-left text-xs font-bold text-muted-foreground uppercase tracking-wide">
                  Testing
                </th>
                <th className="px-4 py-3 text-left text-xs font-bold text-muted-foreground uppercase tracking-wide">
                  Impact
                </th>
                <th className="px-4 py-3 text-left text-xs font-bold text-muted-foreground uppercase tracking-wide">
                  Preview
                </th>
              </tr>
            </thead>
            <tbody>
              {variants.map((variant, index) => {
                const impact = impactConfig[variant.expectedImpact];
                return (
                  <tr key={variant.id} className="border-b border-border hover:bg-muted/10">
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                          <span className="text-sm font-bold text-primary">
                            {String.fromCharCode(65 + index)}
                          </span>
                        </div>
                        <span className="text-sm font-semibold text-foreground">
                          Variant {String.fromCharCode(65 + index)}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="max-w-xs">
                        <div className="text-sm font-semibold text-foreground mb-1">
                          {variant.hypothesis}
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {variant.description}
                        </p>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="max-w-xs">
                        <p className="text-xs text-muted-foreground">
                          {variant.testingContext}
                        </p>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className={`inline-flex items-center gap-1 px-2 py-1 rounded ${impact.bg}`}>
                        <TrendingUp className={`w-3 h-3 ${impact.color}`} />
                        <span className={`text-xs font-bold ${impact.color}`}>
                          {impact.label}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="max-w-xs">
                        <div className="text-xs font-semibold text-foreground mb-1 truncate">
                          {variant.headline}
                        </div>
                        <div className="text-xs text-muted-foreground truncate">
                          {variant.bodyText}
                        </div>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Testing Strategy Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-card border border-border rounded-xl p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
              <Target className="w-5 h-5 text-white" />
            </div>
            <div className="text-sm font-bold text-foreground">
              Clear Hypotheses
            </div>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">
            Each variant tests a specific hypothesis based on your account patterns
          </p>
        </div>

        <div className="bg-card border border-border rounded-xl p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-purple-600 rounded-xl flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <div className="text-sm font-bold text-foreground">
              Testing Context
            </div>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">
            You know exactly what each variant is testing and why it matters
          </p>
        </div>

        <div className="bg-card border border-border rounded-xl p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-green-600 rounded-xl flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <div className="text-sm font-bold text-foreground">
              Impact Prediction
            </div>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">
            Expected impact calculated from historical performance data
          </p>
        </div>
      </div>
    </div>
  );
}
