import React, { useState } from 'react';
import { Lightbulb, Sparkles, Target, TrendingUp, Plus } from 'lucide-react';
import { toast } from 'sonner';

type ViewMode = 'library' | 'research';

interface Hook {
  id: string;
  text: string;
  score: number; // 0-100
  angle: string;
  stage: 'cold' | 'warm' | 'hot';
}

export function SimplifiedHookBuilder() {
  const [viewMode, setViewMode] = useState<ViewMode>('library');
  const [selectedAngle, setSelectedAngle] = useState<string | null>(null);

  const hooks: Hook[] = [
    {
      id: '1',
      text: 'Stop wasting money on ads that don\'t convert',
      score: 87,
      angle: 'Pain Point',
      stage: 'cold'
    },
    {
      id: '2',
      text: 'Join 10,000+ marketers who scaled profitably',
      score: 92,
      angle: 'Social Proof',
      stage: 'warm'
    },
    {
      id: '3',
      text: 'What if you could predict ad fatigue before it happens?',
      score: 78,
      angle: 'Curiosity',
      stage: 'cold'
    },
    {
      id: '4',
      text: 'The secret to 4.8x ROAS (tested with $2M in ad spend)',
      score: 95,
      angle: 'Curiosity + Proof',
      stage: 'warm'
    },
    {
      id: '5',
      text: 'Your competitors are using AI. Here\'s how to stay ahead',
      score: 81,
      angle: 'FOMO',
      stage: 'cold'
    },
    {
      id: '6',
      text: 'Limited time: 50% off your first 3 months',
      score: 89,
      angle: 'Urgency',
      stage: 'hot'
    }
  ];

  const getStageBadge = (stage: Hook['stage']) => {
    const config = {
      cold: { label: 'COLD', color: 'text-blue-600', bg: 'bg-blue-500/10', border: 'border-blue-500/20' },
      warm: { label: 'WARM', color: 'text-green-600', bg: 'bg-green-500/10', border: 'border-green-500/20' },
      hot: { label: 'HOT', color: 'text-primary', bg: 'bg-primary/10', border: 'border-primary/20' }
    };
    return config[stage];
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 75) return 'text-blue-600';
    return 'text-yellow-600';
  };

  const handleGenerate = () => {
    toast.success('Generating new hooks based on top performers...');
  };

  const handleUseHook = (hook: Hook) => {
    toast.success(`Hook added to Creative Builder`);
  };

  // Sort by score by default
  const sortedHooks = [...hooks].sort((a, b) => b.score - a.score);

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-[1400px] mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <Lightbulb className="w-6 h-6 text-primary" />
                <h1 className="text-2xl font-bold text-foreground">Hook Builder</h1>
              </div>
              <p className="text-sm text-muted-foreground">
                AI-scored hooks ranked by performance potential
              </p>
            </div>

            {/* Primary Action */}
            <button
              onClick={handleGenerate}
              className="px-6 py-3 bg-primary text-white rounded-lg font-bold text-sm hover:bg-primary/90 transition-all shadow-md hover:shadow-lg flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              Generate New Hooks
            </button>
          </div>

          {/* Simple Toggle */}
          <div className="flex items-center gap-2 border-b border-border">
            <button
              onClick={() => setViewMode('library')}
              className={`px-4 py-2.5 font-semibold text-sm transition-colors relative ${
                viewMode === 'library'
                  ? 'text-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Hook Library
              {viewMode === 'library' && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
              )}
            </button>
            <button
              onClick={() => setViewMode('research')}
              className={`px-4 py-2.5 font-semibold text-sm transition-colors relative ${
                viewMode === 'research'
                  ? 'text-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Research & Patterns
              {viewMode === 'research' && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
              )}
            </button>
          </div>
        </div>

        {/* Content */}
        {viewMode === 'library' && (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Left - Quick Filters */}
            <div className="lg:col-span-1">
              <div className="bg-card border border-border rounded-xl p-5 sticky top-6">
                <h3 className="font-bold text-foreground mb-4 text-sm">Filter by Angle</h3>
                <div className="space-y-2">
                  {['All', 'Pain Point', 'Social Proof', 'Curiosity', 'FOMO', 'Urgency'].map((angle) => (
                    <button
                      key={angle}
                      onClick={() => setSelectedAngle(angle === 'All' ? null : angle)}
                      className={`w-full px-3 py-2 rounded-lg text-left text-sm font-medium transition-all ${
                        (angle === 'All' && !selectedAngle) || selectedAngle === angle
                          ? 'bg-primary text-white'
                          : 'bg-muted/30 text-foreground hover:bg-muted/50'
                      }`}
                    >
                      {angle}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Right - Hook Cards */}
            <div className="lg:col-span-3 space-y-4">
              {sortedHooks
                .filter(hook => !selectedAngle || hook.angle === selectedAngle)
                .map((hook, index) => (
                  <div
                    key={hook.id}
                    className="bg-card border border-border rounded-xl p-5 hover:border-primary/40 transition-all group"
                  >
                    {/* Hook Header */}
                    <div className="flex items-start gap-4 mb-4">
                      {/* Rank Badge */}
                      <div className="w-10 h-10 bg-muted rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="font-bold text-foreground">#{index + 1}</span>
                      </div>

                      {/* Hook Text */}
                      <div className="flex-1 min-w-0">
                        <p className="text-base font-semibold text-foreground leading-relaxed mb-3">
                          "{hook.text}"
                        </p>

                        {/* Metadata */}
                        <div className="flex flex-wrap items-center gap-2">
                          <div className={`px-2 py-1 rounded text-xs font-bold border ${getStageBadge(hook.stage).bg} ${getStageBadge(hook.stage).border} ${getStageBadge(hook.stage).color}`}>
                            {getStageBadge(hook.stage).label}
                          </div>
                          <div className="px-2 py-1 rounded text-xs font-semibold bg-muted text-foreground">
                            {hook.angle}
                          </div>
                          <div className="flex items-center gap-1.5 ml-auto">
                            <Target className="w-4 h-4 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">Score:</span>
                            <span className={`text-sm font-bold ${getScoreColor(hook.score)}`}>
                              {hook.score}/100
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => handleUseHook(hook)}
                        className="flex-1 px-4 py-2 bg-primary text-white rounded-lg font-semibold text-sm hover:bg-primary/90 transition-all"
                      >
                        Use in Creative Builder
                      </button>
                      <button className="px-4 py-2 bg-card border border-border text-foreground rounded-lg font-semibold text-sm hover:bg-muted/50 transition-all">
                        Add to Variants
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {viewMode === 'research' && (
          <div className="max-w-4xl mx-auto">
            <div className="bg-card border border-border rounded-xl p-6">
              <h3 className="font-bold text-foreground mb-6">Performance Patterns</h3>
              
              {/* Pattern Insights */}
              <div className="space-y-4">
                <div className="p-4 bg-blue-500/5 border border-blue-500/10 rounded-lg">
                  <div className="flex items-start gap-3">
                    <TrendingUp className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <h4 className="font-semibold text-foreground mb-1">
                        Social Proof Hooks Perform Best
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        Hooks with social proof numbers (e.g., "10,000+ users") have 23% higher CTR on average
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-green-500/5 border border-green-500/10 rounded-lg">
                  <div className="flex items-start gap-3">
                    <TrendingUp className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <h4 className="font-semibold text-foreground mb-1">
                        Question Format Works for Cold Traffic
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        Questions generate 18% more engagement in cold audiences compared to statements
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-primary/5 border border-primary/10 rounded-lg">
                  <div className="flex items-start gap-3">
                    <TrendingUp className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <h4 className="font-semibold text-foreground mb-1">
                        Urgency Converts Best in Hot Traffic
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        Time-limited offers in hooks increase conversion rate by 34% for warm/hot audiences
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Common Formats */}
              <div className="mt-8">
                <h4 className="font-bold text-foreground mb-4">Top Hook Formats</h4>
                <div className="space-y-2">
                  {[
                    { format: 'Pain point first', usage: '43%', example: '"Stop wasting money on..."' },
                    { format: 'Social proof number', usage: '31%', example: '"Join 10,000+ marketers..."' },
                    { format: 'Question format', usage: '18%', example: '"What if you could..."' },
                    { format: 'Urgency/scarcity', usage: '8%', example: '"Limited time: 50% off..."' }
                  ].map((item, i) => (
                    <div key={i} className="p-3 bg-muted/30 rounded-lg flex items-center justify-between">
                      <div className="flex-1">
                        <div className="font-semibold text-sm text-foreground">{item.format}</div>
                        <div className="text-xs text-muted-foreground mt-0.5">{item.example}</div>
                      </div>
                      <div className="text-sm font-bold text-primary">{item.usage}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}