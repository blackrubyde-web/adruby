import { useState } from 'react';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Target,
  CheckCircle2,
  Circle,
  ArrowRight,
  Sparkles,
  Zap,
  Calendar,
  ChevronDown,
} from 'lucide-react';
import { toast } from 'sonner';
import { useOverview } from '../hooks/useOverview';
import { SpendRevenueChart } from './SpendRevenueChart';
import { RoasMiniChart } from './RoasMiniChart';
import { PageShell, HeroHeader, Card, FeatureCard, Chip } from './layout';

interface ChecklistStep {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  actionLabel: string;
  onAction: () => void;
}

interface OverviewPageProps {
  onNavigate: (page: string) => void;
}

export function OverviewPage({ onNavigate }: OverviewPageProps) {
  const [dateFilter, setDateFilter] = useState<'today' | '7d' | '30d'>('7d');
  const [channelFilter, setChannelFilter] = useState('meta');
  
  // Fetch data with hook
  const { data, loading, error } = useOverview(dateFilter, channelFilter);
  
  // Checklist State - will be synced with API data when available
  const [checklistSteps, setChecklistSteps] = useState<ChecklistStep[]>([
    {
      id: 'connect-meta',
      title: 'Connect Meta Ads account',
      description: 'Link your Facebook Business account to import campaigns',
      completed: false,
      actionLabel: 'Connect',
      onAction: () => {
        toast.success('Meta Ads account connected!');
        completeStep('connect-meta');
      },
    },
    {
      id: 'create-campaign',
      title: 'Create your first campaign',
      description: 'Launch a campaign to start getting results',
      completed: false,
      actionLabel: 'Create',
      onAction: () => {
        onNavigate('adbuilder');
      },
    },
    {
      id: 'generate-creatives',
      title: 'Generate AI ad creatives',
      description: 'Use AI to create high-performing ad variations',
      completed: false,
      actionLabel: 'Generate',
      onAction: () => {
        toast.info('AI Creative Generator coming soon!');
      },
    },
    {
      id: 'enable-optimization',
      title: 'Enable AI optimization rules',
      description: 'Let AI automatically optimize your campaigns',
      completed: false,
      actionLabel: 'Enable',
      onAction: () => {
        onNavigate('strategies');
      },
    },
  ]);

  const completeStep = (stepId: string) => {
    setChecklistSteps(prev =>
      prev.map(step =>
        step.id === stepId ? { ...step, completed: true } : step
      )
    );
  };

  const completedSteps = checklistSteps.filter(s => s.completed).length;
  const totalSteps = checklistSteps.length;
  const progressPercentage = (completedSteps / totalSteps) * 100;

  // KPI Data
  const kpis = [
    {
      label: 'Total Spend',
      value: '€24.8K',
      change: '+12.5%',
      isPositive: false,
      comparison: 'vs last 7 days',
      icon: <DollarSign className="w-5 h-5 text-primary" />,
    },
    {
      label: 'Total Revenue',
      value: '€186.4K',
      change: '+18.2%',
      isPositive: true,
      comparison: 'vs last 7 days',
      icon: <TrendingUp className="w-5 h-5 text-primary" />,
    },
    {
      label: 'Average ROAS',
      value: '7.52x',
      change: '+0.8x',
      isPositive: true,
      comparison: 'vs last 7 days',
      icon: <Target className="w-5 h-5 text-primary" />,
    },
    {
      label: 'Active Campaigns',
      value: '24',
      change: '+3',
      isPositive: true,
      comparison: 'vs last 7 days',
      icon: <Zap className="w-5 h-5 text-primary" />,
    },
  ];

  // Top Performing Campaign
  const topCampaign = {
    name: 'Summer Sale 2024',
    roas: 12.4,
    spend: 3200,
    revenue: 39680,
  };

  // Best Creative
  const bestCreative = {
    name: 'Video Ad - Product Demo',
    aiScore: 94,
    ctr: 4.2,
    conversions: 234,
  };

  return (
    <PageShell>
      <HeroHeader
        title="Overview"
        subtitle="Here's what's happening with your campaigns today"
      />

      {/* Filters */}
      <div className="flex items-center gap-3">
        {/* Date Filter */}
        <div className="relative">
          <select
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value as any)}
            className="appearance-none pl-3 pr-8 py-2 bg-card border border-border rounded-lg text-sm font-medium text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 cursor-pointer active:scale-[0.98] transition-transform"
          >
            <option value="today">Today</option>
            <option value="7d">Last 7 days</option>
            <option value="30d">Last 30 days</option>
          </select>
          <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
        </div>

        {/* Channel Filter */}
        <div className="relative">
          <select
            value={channelFilter}
            onChange={(e) => setChannelFilter(e.target.value as any)}
            className="appearance-none pl-3 pr-8 py-2 bg-card border border-border rounded-lg text-sm font-medium text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 cursor-pointer active:scale-[0.98] transition-transform"
          >
            <option value="meta">Meta Ads</option>
            <option value="google">Google Ads</option>
            <option value="tiktok">TikTok Ads</option>
          </select>
          <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        {kpis.map((kpi, index) => (
          <Card key={index} className="p-5 hover:-translate-y-0.5 transition-all duration-300">
            {/* Accent Line */}
            <div className="absolute inset-x-0 top-0 h-[2px] rounded-t-xl bg-primary/40" />
            
            {/* Content */}
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="text-sm text-muted-foreground mb-2">{kpi.label}</div>
                <div className="text-2xl sm:text-3xl font-semibold tracking-tight text-foreground mb-2">
                  {kpi.value}
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <span
                    className={`flex items-center gap-1 font-medium ${
                      kpi.isPositive ? 'text-green-600' : 'text-muted-foreground'
                    }`}
                  >
                    {kpi.isPositive ? (
                      <TrendingUp className="w-3 h-3" />
                    ) : (
                      <TrendingDown className="w-3 h-3" />
                    )}
                    {kpi.change}
                  </span>
                  <span className="text-muted-foreground">{kpi.comparison}</span>
                </div>
              </div>

              {/* Icon Badge */}
              <div className="h-10 w-10 rounded-xl bg-primary/10 border border-primary/15 flex items-center justify-center shrink-0">
                {kpi.icon}
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Charts Section - Shopify Style (KPIs → Charts → Tasks) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-5 mb-6 sm:mb-8">
        {/* Spend vs Revenue - 2/3 width */}
        <div className="lg:col-span-2">
          <SpendRevenueChart
            points={data?.timeseries ?? []}
            range={dateFilter}
            loading={loading}
            error={error}
          />
        </div>
        
        {/* ROAS Trend - 1/3 width */}
        <div className="lg:col-span-1">
          <RoasMiniChart
            points={(data?.timeseries ?? []).map(p => ({ ts: p.ts, roas: p.roas }))}
            range={dateFilter}
            loading={loading}
            error={error}
          />
        </div>
      </div>

      {/* Getting Started Card (Shopify-style) */}
      <div className="rounded-2xl bg-card/70 backdrop-blur border border-border/50 shadow-[0_1px_0_rgba(255,255,255,0.5),0_12px_30px_rgba(0,0,0,0.06)] hover:shadow-[0_1px_0_rgba(255,255,255,0.6),0_18px_50px_rgba(0,0,0,0.10)] transition-all duration-300 p-6 sm:p-8 mb-6 sm:mb-8">
        {/* Header */}
        <div className="flex items-center justify-between gap-4 mb-5">
          <div>
            <h2 className="text-lg font-semibold tracking-tight text-foreground mb-1">
              Getting Started
            </h2>
            <p className="text-sm text-muted-foreground">
              Unlock the full power in 5 minutes
            </p>
          </div>
          <div className="text-sm font-medium text-muted-foreground whitespace-nowrap">
            {completedSteps}/{totalSteps}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="h-2 bg-muted rounded-full overflow-hidden mb-6">
          <div
            className="h-full bg-primary/80 transition-all duration-500"
            style={{ width: `${progressPercentage}%` }}
          />
        </div>

        {/* Checklist Steps - 2 Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {checklistSteps.map((step, index) => (
            <div
              key={step.id}
              className={`flex items-start gap-3 p-4 rounded-xl border transition-all duration-300 hover:-translate-y-0.5 ${
                step.completed
                  ? 'bg-muted/30 border-border/50'
                  : 'bg-background border-border hover:border-border/80'
              }`}
            >
              {/* Checkbox */}
              <div className="pt-0.5 shrink-0">
                {step.completed ? (
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                ) : (
                  <Circle className="w-5 h-5 text-muted-foreground" />
                )}
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div
                  className={`font-semibold tracking-tight mb-0.5 ${
                    step.completed
                      ? 'text-muted-foreground line-through'
                      : 'text-foreground'
                  }`}
                >
                  {step.title}
                </div>
                <div className="text-xs text-muted-foreground mb-3">
                  {step.description}
                </div>
                
                {/* Action Button */}
                {!step.completed && (
                  <button
                    onClick={step.onAction}
                    className="w-full px-3 py-1.5 bg-background hover:bg-muted border border-border text-foreground text-xs font-medium rounded-lg transition-all active:scale-[0.98]"
                  >
                    {step.actionLabel}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightweight Insights Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-5">
        {/* Top Performing Campaign */}
        <div className="rounded-2xl bg-card/70 backdrop-blur border border-border/50 shadow-[0_1px_0_rgba(255,255,255,0.5),0_12px_30px_rgba(0,0,0,0.06)] hover:shadow-[0_1px_0_rgba(255,255,255,0.6),0_18px_50px_rgba(0,0,0,0.10)] transition-all duration-300 hover:-translate-y-0.5 p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <h3 className="text-base font-semibold tracking-tight text-foreground mb-1">
                Top Performing Campaign Today
              </h3>
              <p className="text-sm text-muted-foreground">
                Highest ROAS in the last 24 hours
              </p>
            </div>
            <div className="h-10 w-10 rounded-xl bg-primary/10 border border-primary/15 flex items-center justify-center shrink-0">
              <Target className="w-5 h-5 text-primary" />
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <div className="text-lg font-semibold tracking-tight text-foreground mb-2">
                {topCampaign.name}
              </div>
              
              {/* Visual Element: ROAS Badge */}
              <div className="flex items-center gap-2 mb-3">
                <span className="px-2 py-1 rounded-full text-xs bg-green-500/10 text-green-600 border border-green-500/20 font-medium">
                  Top performer
                </span>
                <span className="text-xs text-muted-foreground">High confidence</span>
              </div>

              <div className="flex items-center gap-4 text-sm flex-wrap">
                <span className="text-muted-foreground">
                  ROAS:{' '}
                  <span className="font-semibold tracking-tight text-foreground">
                    {topCampaign.roas}x
                  </span>
                </span>
                <span className="text-muted-foreground">
                  Spend:{' '}
                  <span className="font-mono text-foreground">
                    €{(topCampaign.spend / 1000).toFixed(1)}K
                  </span>
                </span>
                <span className="text-muted-foreground">
                  Revenue:{' '}
                  <span className="font-mono text-foreground">
                    €{(topCampaign.revenue / 1000).toFixed(1)}K
                  </span>
                </span>
              </div>
            </div>

            <button
              onClick={() => onNavigate('campaigns')}
              className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:text-primary/80 transition-colors"
            >
              View all campaigns
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Best Creative (AI Score) */}
        <div className="rounded-2xl bg-card/70 backdrop-blur border border-border/50 shadow-[0_1px_0_rgba(255,255,255,0.5),0_12px_30px_rgba(0,0,0,0.06)] hover:shadow-[0_1px_0_rgba(255,255,255,0.6),0_18px_50px_rgba(0,0,0,0.10)] transition-all duration-300 hover:-translate-y-0.5 p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <h3 className="text-base font-semibold tracking-tight text-foreground mb-1">
                Best Creative (AI Score)
              </h3>
              <p className="text-sm text-muted-foreground">
                Highest AI performance score
              </p>
            </div>
            <div className="h-10 w-10 rounded-xl bg-primary/10 border border-primary/15 flex items-center justify-center shrink-0">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <div className="text-lg font-semibold tracking-tight text-foreground mb-2">
                {bestCreative.name}
              </div>
              
              {/* Visual Element: AI Badge + Progress */}
              <div className="flex items-center gap-2 mb-3">
                <span className="px-2 py-1 rounded-full text-xs bg-primary/10 text-primary border border-primary/15 font-medium">
                  AI insight
                </span>
                <span className="text-xs text-muted-foreground">High confidence</span>
              </div>

              {/* AI Score Progress Bar */}
              <div className="mb-3">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-muted-foreground">Performance Score</span>
                  <span className="font-semibold tracking-tight text-primary">{bestCreative.aiScore}/100</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary transition-all duration-500"
                    style={{ width: `${bestCreative.aiScore}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center gap-4 text-sm flex-wrap">
                <span className="text-muted-foreground">
                  CTR:{' '}
                  <span className="font-mono text-foreground">
                    {bestCreative.ctr}%
                  </span>
                </span>
                <span className="text-muted-foreground">
                  Conv:{' '}
                  <span className="font-mono text-foreground">
                    {bestCreative.conversions}
                  </span>
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3 flex-wrap">
              <button className="px-5 py-2.5 bg-primary text-white font-semibold rounded-lg hover:bg-primary/90 transition-all shadow-sm hover:shadow-md flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                AI Analysis
              </button>
              <button 
                onClick={() => onNavigate('creative-builder')}
                className="px-5 py-2.5 bg-card border border-border text-foreground font-semibold rounded-lg hover:bg-muted/50 transition-all flex items-center gap-2"
              >
                Creative Builder
              </button>
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}