import React, { useState } from 'react';
import { Card } from '../layout/Card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { 
  CheckCircle2,
  Circle,
  ArrowRight,
  Users,
  Sparkles,
  Target,
  Zap
} from 'lucide-react';
import type { MemberOnboarding as MemberOnboardingType } from '../../types/community';

// Mock Data
const mockOnboarding: MemberOnboardingType = {
  memberId: '1',
  mentorName: 'Alex Morrison',
  communityName: 'E-Commerce Masters',
  methodology: 'Data-driven creative testing with proven frameworks',
  welcomeMessage: 'Welcome to E-Commerce Masters! You\'re joining a community of serious media buyers who are scaling profitably. Follow the system, trust the process, and you\'ll see results faster than going solo.',
  presetTemplates: [],
  allowedFeatures: ['aiAnalysis', 'creativeBuilder', 'hookBuilder', 'analytics'],
  steps: [
    {
      id: '1',
      title: 'Connect your ad account',
      description: 'Link your Facebook Ads account so we can analyze your campaigns',
      completed: false
    },
    {
      id: '2',
      title: 'Review your first AI analysis',
      description: 'See what\'s working and what needs fixing in your current ads',
      completed: false
    },
    {
      id: '3',
      title: 'Use your first approved template',
      description: 'Create a new ad using one of your mentor\'s proven templates',
      completed: false
    },
    {
      id: '4',
      title: 'Launch your first test',
      description: 'Deploy your new creative and start collecting data',
      completed: false
    }
  ]
};

interface MemberOnboardingProps {
  onComplete: () => void;
}

export function MemberOnboarding({ onComplete }: MemberOnboardingProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [onboarding, setOnboarding] = useState(mockOnboarding);

  const completedSteps = onboarding.steps.filter(s => s.completed).length;
  const progress = (completedSteps / onboarding.steps.length) * 100;

  const handleStepComplete = () => {
    const updatedSteps = [...onboarding.steps];
    updatedSteps[currentStep].completed = true;
    setOnboarding({ ...onboarding, steps: updatedSteps });

    if (currentStep < onboarding.steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="max-w-2xl w-full space-y-6">
        {/* Welcome Card */}
        <Card>
          <div className="p-8">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                <Users className="w-8 h-8 text-primary" />
              </div>
              <h1 className="text-3xl font-bold text-foreground mb-2">
                Welcome to {onboarding.communityName}!
              </h1>
              <div className="flex items-center justify-center gap-2 text-muted-foreground">
                <span>Guided by</span>
                <Badge className="bg-primary/10 text-primary">{onboarding.mentorName}</Badge>
              </div>
            </div>

            <div className="p-6 rounded-xl bg-gradient-to-br from-primary/5 to-purple-500/5 border border-primary/20 mb-8">
              <div className="flex items-start gap-3">
                <Sparkles className="w-6 h-6 text-primary shrink-0 mt-1" />
                <div>
                  <div className="font-semibold text-foreground mb-2">Your Mentor's Approach</div>
                  <p className="text-sm text-muted-foreground mb-3">
                    "{onboarding.methodology}"
                  </p>
                  <p className="text-sm text-foreground">
                    {onboarding.welcomeMessage}
                  </p>
                </div>
              </div>
            </div>

            {/* Progress */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold text-foreground">Getting Started</span>
                <span className="text-xs text-muted-foreground">
                  {completedSteps}/{onboarding.steps.length} completed
                </span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary transition-all duration-500"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>

            {/* Steps */}
            <div className="space-y-3 mb-8">
              {onboarding.steps.map((step, index) => (
                <div
                  key={step.id}
                  className={`p-4 rounded-lg border transition-all ${
                    step.completed
                      ? 'bg-green-500/5 border-green-500/20'
                      : index === currentStep
                      ? 'bg-primary/5 border-primary/40'
                      : 'bg-muted/20 border-border/40'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="shrink-0 mt-0.5">
                      {step.completed ? (
                        <CheckCircle2 className="w-5 h-5 text-green-500" />
                      ) : (
                        <Circle className={`w-5 h-5 ${
                          index === currentStep ? 'text-primary' : 'text-muted-foreground'
                        }`} />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-foreground">{step.title}</span>
                        {index === currentStep && !step.completed && (
                          <Badge className="bg-primary/10 text-primary text-xs">Current</Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{step.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* CTA */}
            {currentStep < onboarding.steps.length && (
              <div className="flex gap-3">
                {currentStep > 0 && (
                  <Button
                    variant="secondary"
                    onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                  >
                    Back
                  </Button>
                )}
                <Button
                  variant="accent"
                  fullWidth={currentStep === 0}
                  icon={<ArrowRight className="w-4 h-4" />}
                  onClick={handleStepComplete}
                >
                  {currentStep === onboarding.steps.length - 1
                    ? 'Complete Setup'
                    : `Complete: ${onboarding.steps[currentStep].title}`}
                </Button>
              </div>
            )}
          </div>
        </Card>

        {/* What You'll Get */}
        <Card>
          <div className="p-6">
            <h3 className="font-semibold text-foreground mb-4">What You'll Get</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-primary/10 shrink-0">
                  <Target className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-foreground mb-1">Proven Templates</div>
                  <div className="text-xs text-muted-foreground">
                    Pre-built frameworks that work
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-primary/10 shrink-0">
                  <Sparkles className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-foreground mb-1">AI Guidance</div>
                  <div className="text-xs text-muted-foreground">
                    Simple, actionable insights
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-primary/10 shrink-0">
                  <Zap className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-foreground mb-1">Guardrails</div>
                  <div className="text-xs text-muted-foreground">
                    Avoid costly mistakes
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Trust Signal */}
        <div className="text-center text-xs text-muted-foreground">
          <p>You're in good hands. Your mentor has helped {47} other members scale profitably.</p>
        </div>
      </div>
    </div>
  );
}
