import React, { useState } from 'react';
import { PageShell } from '../layout/PageShell';
import { HeroHeader } from '../layout/HeroHeader';
import { Card } from '../layout/Card';
import { Chip } from '../layout/Chip';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { 
  Users, 
  TrendingUp, 
  AlertTriangle, 
  Trophy, 
  Send,
  Settings,
  Sparkles,
  Target,
  Activity,
  DollarSign,
  ArrowUp,
  ArrowDown,
  Minus
} from 'lucide-react';
import type { 
  MemberPerformance, 
  GroupPerformance, 
  GroupInsight, 
  CommonMistake,
  GroupPattern,
  LeaderboardEntry 
} from '../../types/community';

// Mock Data
const mockGroupPerformance: GroupPerformance = {
  totalMembers: 47,
  activeMembers: 42,
  aggregateMetrics: {
    totalSpend: 284750,
    totalRevenue: 892340,
    avgRoas: 3.13,
    avgCpa: 24.50,
    totalImpressions: 8450000,
    totalClicks: 42250,
    totalConversions: 11594
  },
  period: {
    start: '2024-12-01',
    end: '2024-12-18'
  },
  trend: {
    spendChange: 12.5,
    revenueChange: 28.3,
    roasChange: 14.2
  }
};

const mockGroupInsights: GroupInsight[] = [
  {
    id: '1',
    type: 'creative',
    severity: 'critical',
    title: '80% of members underuse social proof',
    description: 'Most ads lack testimonials, reviews, or UGC elements. This reduces trust and conversion rates.',
    affectedMembers: 38,
    affectedPercentage: 80.8,
    recommendation: 'Push UGC template pack to all members. Include 3 testimonial variants.',
    impact: 'high',
    createdAt: '2024-12-18T10:30:00Z'
  },
  {
    id: '2',
    type: 'targeting',
    severity: 'warning',
    title: 'Narrow audiences causing high CPAs',
    description: '15 members have audiences under 50k. This limits delivery and increases costs.',
    affectedMembers: 15,
    affectedPercentage: 31.9,
    recommendation: 'Recommend broader audience strategy with layered exclusions.',
    impact: 'high',
    createdAt: '2024-12-18T09:15:00Z'
  },
  {
    id: '3',
    type: 'offer',
    severity: 'warning',
    title: 'Discount framing performs poorly',
    description: 'Percentage-off offers underperform by 22% vs. value-based framing.',
    affectedMembers: 12,
    affectedPercentage: 25.5,
    recommendation: 'Share winning offer templates: "Save $X" performs better than "X% off".',
    impact: 'medium',
    createdAt: '2024-12-17T16:45:00Z'
  },
  {
    id: '4',
    type: 'creative',
    severity: 'success',
    title: 'UGC-style creatives outperform studio shots',
    description: 'Across the group, raw iPhone videos have 2.3x better CTR than polished content.',
    affectedMembers: 47,
    affectedPercentage: 100,
    recommendation: 'Promote this insight. Create UGC filming guide for all members.',
    impact: 'high',
    createdAt: '2024-12-17T14:20:00Z'
  }
];

const mockCommonMistakes: CommonMistake[] = [
  {
    category: 'Creative',
    mistake: 'Weak hooks (no curiosity gap)',
    occurrence: 28,
    avgImpact: '-32% CTR',
    quickFix: 'Use pattern interrupt or bold claim in first 3 seconds'
  },
  {
    category: 'Offer',
    mistake: 'No clear CTA or urgency',
    occurrence: 22,
    avgImpact: '-18% Conv',
    quickFix: 'Add time-bound offer + single clear action button'
  },
  {
    category: 'Targeting',
    mistake: 'Too many interests stacked',
    occurrence: 19,
    avgImpact: '+45% CPA',
    quickFix: 'Test broad + 1 interest vs. stacked interests'
  },
  {
    category: 'Budget',
    mistake: 'Daily budget under $50',
    occurrence: 15,
    avgImpact: 'Poor delivery',
    quickFix: 'Increase to minimum $75/day or consolidate campaigns'
  }
];

const mockGroupPatterns: GroupPattern[] = [
  {
    pattern: 'Problem-Agitate-Solution hooks',
    winningApproach: 'Start with relatable pain point → amplify → present solution',
    memberCount: 12,
    avgImprovement: '+43% CTR',
    examples: [
      '"Tired of X? Here\'s why..." → "It gets worse..." → "Until I discovered..."',
      '"Stop doing X. Here\'s what actually works..."'
    ]
  },
  {
    pattern: 'Risk reversal in offers',
    winningApproach: 'Money-back guarantee + free returns prominently displayed',
    memberCount: 8,
    avgImprovement: '+28% Conv',
    examples: [
      '30-day guarantee badge in thumbnail',
      '"Try risk-free" as primary CTA'
    ]
  },
  {
    pattern: 'Mobile-first video format',
    winningApproach: '9:16 vertical, captions on, first frame = hook',
    memberCount: 18,
    avgImprovement: '+36% CTR',
    examples: [
      'Native TikTok-style with text overlay',
      'Face-to-camera testimonial format'
    ]
  }
];

const mockLeaderboard: LeaderboardEntry[] = [
  {
    rank: 1,
    memberId: '1',
    memberName: 'Sarah Chen',
    avatarUrl: undefined,
    metric: 'improvement',
    value: 127,
    change: 15,
    badge: 'most_improved'
  },
  {
    rank: 2,
    memberId: '2',
    memberName: 'Marcus Johnson',
    metric: 'roas',
    value: 4.82,
    change: 8,
    badge: 'top_performer'
  },
  {
    rank: 3,
    memberId: '3',
    memberName: 'Emma Rodriguez',
    metric: 'consistency',
    value: 94,
    change: 2,
    badge: 'consistent'
  },
  {
    rank: 4,
    memberId: '4',
    memberName: 'David Kim',
    metric: 'roas',
    value: 4.21,
    change: -3
  },
  {
    rank: 5,
    memberId: '5',
    memberName: 'Lisa Patel',
    metric: 'improvement',
    value: 89,
    change: 12,
    badge: 'rising_star'
  }
];

export function MentorDashboard() {
  const [selectedPeriod, setSelectedPeriod] = useState<'7d' | '30d' | '90d'>('30d');

  const formatCurrency = (value: number) => 
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0 }).format(value);

  const formatNumber = (value: number) => 
    new Intl.NumberFormat('en-US').format(value);

  const getTrendIcon = (change: number) => {
    if (change > 0) return <ArrowUp className="w-3 h-3" />;
    if (change < 0) return <ArrowDown className="w-3 h-3" />;
    return <Minus className="w-3 h-3" />;
  };

  const getTrendColor = (change: number, inverse = false) => {
    if (inverse) {
      if (change > 0) return 'text-red-500';
      if (change < 0) return 'text-green-500';
      return 'text-muted-foreground';
    }
    if (change > 0) return 'text-green-500';
    if (change < 0) return 'text-red-500';
    return 'text-muted-foreground';
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-500/10 text-red-500 border-red-500/20';
      case 'warning': return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20';
      case 'success': return 'bg-green-500/10 text-green-500 border-green-500/20';
      default: return 'bg-blue-500/10 text-blue-500 border-blue-500/20';
    }
  };

  const getBadgeInfo = (badge?: string) => {
    switch (badge) {
      case 'most_improved': return { label: '🚀 Most Improved', color: 'bg-purple-500/10 text-purple-500' };
      case 'top_performer': return { label: '👑 Top Performer', color: 'bg-yellow-500/10 text-yellow-500' };
      case 'consistent': return { label: '💎 Consistent', color: 'bg-blue-500/10 text-blue-500' };
      case 'rising_star': return { label: '⭐ Rising Star', color: 'bg-green-500/10 text-green-500' };
      default: return null;
    }
  };

  return (
    <PageShell>
      {/* Hero Header */}
      <HeroHeader
        title="Community Control Room"
        subtitle="Strategic oversight for your entire community. Scale best practices, detect problems early, guide your members to better results."
        chips={
          <>
            <Chip icon={<Users className="w-3 h-3" />}>
              {mockGroupPerformance.activeMembers}/{mockGroupPerformance.totalMembers} Active Members
            </Chip>
            <Chip icon={<Target className="w-3 h-3" />}>
              Avg ROAS: {mockGroupPerformance.aggregateMetrics.avgRoas.toFixed(2)}x
            </Chip>
          </>
        }
        actions={
          <>
            <Button variant="secondary" size="sm" icon={<Settings className="w-4 h-4" />}>
              Settings
            </Button>
            <Button variant="accent" size="sm" icon={<Send className="w-4 h-4" />}>
              Push Update
            </Button>
          </>
        }
      />

      {/* Group Performance Overview */}
      <Card>
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-semibold text-foreground">Group Performance</h2>
              <p className="text-sm text-muted-foreground">Aggregated metrics across all active members</p>
            </div>
            <div className="flex gap-2">
              {(['7d', '30d', '90d'] as const).map(period => (
                <button
                  key={period}
                  onClick={() => setSelectedPeriod(period)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                    selectedPeriod === period
                      ? 'bg-foreground text-background'
                      : 'bg-muted text-muted-foreground hover:bg-muted/70'
                  }`}
                >
                  {period === '7d' ? '7 Days' : period === '30d' ? '30 Days' : '90 Days'}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Total Spend */}
            <div className="p-4 rounded-lg bg-muted/30 border border-border/40">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <DollarSign className="w-4 h-4" />
                <span className="text-xs font-semibold uppercase tracking-wide">Total Spend</span>
              </div>
              <div className="text-2xl font-bold text-foreground">
                {formatCurrency(mockGroupPerformance.aggregateMetrics.totalSpend)}
              </div>
              <div className={`flex items-center gap-1 text-xs font-semibold mt-1 ${getTrendColor(mockGroupPerformance.trend.spendChange)}`}>
                {getTrendIcon(mockGroupPerformance.trend.spendChange)}
                {Math.abs(mockGroupPerformance.trend.spendChange).toFixed(1)}% vs prev period
              </div>
            </div>

            {/* Total Revenue */}
            <div className="p-4 rounded-lg bg-muted/30 border border-border/40">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <TrendingUp className="w-4 h-4" />
                <span className="text-xs font-semibold uppercase tracking-wide">Total Revenue</span>
              </div>
              <div className="text-2xl font-bold text-foreground">
                {formatCurrency(mockGroupPerformance.aggregateMetrics.totalRevenue)}
              </div>
              <div className={`flex items-center gap-1 text-xs font-semibold mt-1 ${getTrendColor(mockGroupPerformance.trend.revenueChange)}`}>
                {getTrendIcon(mockGroupPerformance.trend.revenueChange)}
                {Math.abs(mockGroupPerformance.trend.revenueChange).toFixed(1)}% vs prev period
              </div>
            </div>

            {/* Avg ROAS */}
            <div className="p-4 rounded-lg bg-muted/30 border border-border/40">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <Activity className="w-4 h-4" />
                <span className="text-xs font-semibold uppercase tracking-wide">Avg ROAS</span>
              </div>
              <div className="text-2xl font-bold text-foreground">
                {mockGroupPerformance.aggregateMetrics.avgRoas.toFixed(2)}x
              </div>
              <div className={`flex items-center gap-1 text-xs font-semibold mt-1 ${getTrendColor(mockGroupPerformance.trend.roasChange)}`}>
                {getTrendIcon(mockGroupPerformance.trend.roasChange)}
                {Math.abs(mockGroupPerformance.trend.roasChange).toFixed(1)}% vs prev period
              </div>
            </div>

            {/* Avg CPA */}
            <div className="p-4 rounded-lg bg-muted/30 border border-border/40">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <Target className="w-4 h-4" />
                <span className="text-xs font-semibold uppercase tracking-wide">Avg CPA</span>
              </div>
              <div className="text-2xl font-bold text-foreground">
                {formatCurrency(mockGroupPerformance.aggregateMetrics.avgCpa)}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                {formatNumber(mockGroupPerformance.aggregateMetrics.totalConversions)} conversions
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* AI Group Insights */}
      <Card>
        <div className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-lg bg-primary/10">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-foreground">AI Group Insights</h2>
              <p className="text-sm text-muted-foreground">Patterns and problems detected across your community</p>
            </div>
          </div>

          <div className="space-y-3">
            {mockGroupInsights.map(insight => (
              <div
                key={insight.id}
                className={`p-4 rounded-lg border ${getSeverityColor(insight.severity)}`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="outline" className="text-xs">
                        {insight.type.charAt(0).toUpperCase() + insight.type.slice(1)}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        Affects {insight.affectedMembers} members ({insight.affectedPercentage.toFixed(0)}%)
                      </span>
                    </div>
                    <h3 className="font-semibold text-foreground mb-1">{insight.title}</h3>
                    <p className="text-sm text-muted-foreground mb-3">{insight.description}</p>
                    <div className="p-3 rounded-lg bg-background/50 border border-border/40">
                      <div className="text-xs font-semibold text-muted-foreground mb-1">RECOMMENDATION</div>
                      <div className="text-sm text-foreground">{insight.recommendation}</div>
                    </div>
                  </div>
                  <div className="shrink-0">
                    {insight.severity === 'critical' && <AlertTriangle className="w-5 h-5 text-red-500" />}
                    {insight.severity === 'warning' && <AlertTriangle className="w-5 h-5 text-yellow-500" />}
                    {insight.severity === 'success' && <TrendingUp className="w-5 h-5 text-green-500" />}
                  </div>
                </div>
                <div className="mt-3 flex gap-2">
                  <Button variant="secondary" size="sm">
                    View Details
                  </Button>
                  {insight.severity !== 'success' && (
                    <Button variant="accent" size="sm" icon={<Send className="w-3 h-3" />}>
                      Push Fix to Members
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Common Mistakes */}
        <Card>
          <div className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-red-500/10">
                <AlertTriangle className="w-5 h-5 text-red-500" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">Common Mistakes</h2>
                <p className="text-sm text-muted-foreground">Most frequent issues across the group</p>
              </div>
            </div>

            <div className="space-y-3">
              {mockCommonMistakes.map((mistake, index) => (
                <div key={index} className="p-4 rounded-lg bg-muted/30 border border-border/40">
                  <div className="flex items-start justify-between gap-4 mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline" className="text-xs">{mistake.category}</Badge>
                        <span className="text-xs text-muted-foreground">{mistake.occurrence} members</span>
                      </div>
                      <div className="font-semibold text-foreground text-sm mb-1">{mistake.mistake}</div>
                      <div className="text-xs text-red-500 font-semibold">Impact: {mistake.avgImpact}</div>
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-background border border-border/40">
                    <div className="text-xs font-semibold text-green-600 mb-1">QUICK FIX</div>
                    <div className="text-sm text-foreground">{mistake.quickFix}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Winning Patterns */}
        <Card>
          <div className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-green-500/10">
                <TrendingUp className="w-5 h-5 text-green-500" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">Winning Patterns</h2>
                <p className="text-sm text-muted-foreground">What's working across your community</p>
              </div>
            </div>

            <div className="space-y-3">
              {mockGroupPatterns.map((pattern, index) => (
                <div key={index} className="p-4 rounded-lg bg-muted/30 border border-border/40">
                  <div className="flex items-start justify-between gap-4 mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="font-semibold text-foreground">{pattern.pattern}</div>
                      </div>
                      <div className="text-sm text-muted-foreground mb-2">{pattern.winningApproach}</div>
                      <div className="flex items-center gap-3 text-xs">
                        <span className="text-muted-foreground">{pattern.memberCount} members</span>
                        <span className="font-semibold text-green-500">{pattern.avgImprovement}</span>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    {pattern.examples.map((example, i) => (
                      <div key={i} className="p-2 rounded bg-background/50 border border-border/40 text-xs text-foreground">
                        {example}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>

      {/* Leaderboard */}
      <Card>
        <div className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-lg bg-yellow-500/10">
              <Trophy className="w-5 h-5 text-yellow-500" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-foreground">Performance Leaderboard</h2>
              <p className="text-sm text-muted-foreground">Top performers by improvement, not vanity metrics</p>
            </div>
          </div>

          <div className="space-y-2">
            {mockLeaderboard.map((entry) => {
              const badgeInfo = getBadgeInfo(entry.badge);
              return (
                <div
                  key={entry.memberId}
                  className="flex items-center gap-4 p-4 rounded-lg bg-muted/30 border border-border/40 hover:bg-muted/50 transition-colors"
                >
                  {/* Rank */}
                  <div className={`flex items-center justify-center w-8 h-8 rounded-full font-bold text-sm ${
                    entry.rank === 1 ? 'bg-yellow-500/20 text-yellow-500' :
                    entry.rank === 2 ? 'bg-gray-400/20 text-gray-400' :
                    entry.rank === 3 ? 'bg-orange-500/20 text-orange-500' :
                    'bg-muted text-muted-foreground'
                  }`}>
                    {entry.rank}
                  </div>

                  {/* Avatar */}
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white font-semibold">
                    {entry.memberName.charAt(0)}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-foreground">{entry.memberName}</div>
                    <div className="text-xs text-muted-foreground">
                      {entry.metric === 'roas' && `ROAS: ${entry.value.toFixed(2)}x`}
                      {entry.metric === 'cpa' && `CPA: $${entry.value.toFixed(2)}`}
                      {entry.metric === 'improvement' && `${entry.value}% improvement`}
                      {entry.metric === 'consistency' && `${entry.value}% consistency score`}
                    </div>
                  </div>

                  {/* Badge */}
                  {badgeInfo && (
                    <Badge className={`${badgeInfo.color} text-xs`}>
                      {badgeInfo.label}
                    </Badge>
                  )}

                  {/* Change */}
                  <div className={`flex items-center gap-1 text-xs font-semibold ${getTrendColor(entry.change)}`}>
                    {getTrendIcon(entry.change)}
                    {Math.abs(entry.change)}%
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </Card>
    </PageShell>
  );
}
