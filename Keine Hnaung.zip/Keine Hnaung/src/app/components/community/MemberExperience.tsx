import React, { useState } from 'react';
import { PageShell } from '../layout/PageShell';
import { HeroHeader } from '../layout/HeroHeader';
import { Card } from '../layout/Card';
import { Chip } from '../layout/Chip';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { 
  CheckCircle2,
  AlertCircle,
  Lightbulb,
  ArrowRight,
  Sparkles,
  TrendingUp,
  Target,
  Zap,
  Users,
  Lock
} from 'lucide-react';

// Mock Data for Member View
const mockMentorInfo = {
  name: 'Alex Morrison',
  communityName: 'E-Commerce Masters',
  methodology: 'Data-driven creative testing with proven frameworks'
};

const mockGuidedTasks = [
  {
    id: '1',
    priority: 'high',
    title: 'Fix your main ad hook',
    description: 'Your current hook has low curiosity. Use the approved "Problem-Solution" template.',
    action: 'Use Template',
    reason: 'AI detected weak pattern interrupt in your top-spending ad',
    impact: 'Expected +25% CTR improvement'
  },
  {
    id: '2',
    priority: 'high',
    title: 'Add social proof to offer',
    description: 'Your ads lack trust signals. Add testimonial variant from approved library.',
    action: 'Browse Templates',
    reason: 'Missing trust elements reduce conversion by ~18%',
    impact: 'Expected +15% conversion rate'
  },
  {
    id: '3',
    priority: 'medium',
    title: 'Test new mobile-first format',
    description: 'Your mentor recommends trying 9:16 vertical video with captions.',
    action: 'View Example',
    reason: 'This format is winning across the group (+36% CTR)',
    impact: 'Proven winning pattern'
  }
];

const mockSimplifiedAnalysis = {
  status: 'warning',
  headline: 'Your ads need attention',
  problems: [
    {
      what: 'Weak hooks',
      why: 'First 3 seconds don\'t grab attention',
      fix: 'Use mentor-approved pattern interrupt hooks',
      severity: 'high'
    },
    {
      what: 'No social proof',
      why: 'People don\'t trust claims without evidence',
      fix: 'Add testimonials or review count',
      severity: 'high'
    },
    {
      what: 'CTA unclear',
      why: 'Users don\'t know what action to take',
      fix: 'Single clear button: "Shop Now" or "Get Yours"',
      severity: 'medium'
    }
  ]
};

const mockApprovedTemplates = [
  {
    id: '1',
    name: 'Problem-Solution Hook',
    type: 'hook',
    description: 'Start with pain point, present solution',
    locked: false,
    performance: { avgCtr: 3.2, uses: 156 }
  },
  {
    id: '2',
    name: 'Social Proof Variant',
    type: 'creative',
    description: 'Testimonial-focused creative with trust badges',
    locked: false,
    performance: { avgCtr: 2.8, uses: 89 }
  },
  {
    id: '3',
    name: 'Value Stack Offer',
    type: 'offer',
    description: 'Show full value breakdown + bonus',
    locked: false,
    performance: { avgCtr: 2.4, uses: 134 }
  },
  {
    id: '4',
    name: 'Advanced Targeting Strategy',
    type: 'strategy',
    description: 'Layered audience with exclusions',
    locked: true,
    performance: undefined
  }
];

const mockMemberStats = {
  currentRoas: 2.4,
  targetRoas: 3.5,
  improvement: 18,
  daysActive: 14,
  adsCreated: 8,
  nextMilestone: 'Reach 3.0x ROAS'
};

export function MemberExperience() {
  const [activeTab, setActiveTab] = useState<'tasks' | 'templates' | 'learn'>('tasks');

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-500/10 text-red-500 border-red-500/20';
      case 'medium': return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20';
      default: return 'bg-blue-500/10 text-blue-500 border-blue-500/20';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'high': return <AlertCircle className="w-4 h-4 text-red-500" />;
      case 'medium': return <AlertCircle className="w-4 h-4 text-yellow-500" />;
      default: return <Lightbulb className="w-4 h-4 text-blue-500" />;
    }
  };

  return (
    <PageShell>
      {/* Hero Header - Member View */}
      <HeroHeader
        title={`Welcome to ${mockMentorInfo.communityName}`}
        subtitle={`Guided by ${mockMentorInfo.name} • ${mockMentorInfo.methodology}`}
        chips={
          <>
            <Chip icon={<TrendingUp className="w-3 h-3" />}>
              {mockMemberStats.improvement}% improved
            </Chip>
            <Chip icon={<Target className="w-3 h-3" />}>
              ROAS: {mockMemberStats.currentRoas.toFixed(1)}x → {mockMemberStats.targetRoas.toFixed(1)}x
            </Chip>
          </>
        }
      />

      {/* Progress Card */}
      <Card>
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-lg font-semibold text-foreground">Your Progress</h2>
              <p className="text-sm text-muted-foreground">You're on the right track. Keep following the system.</p>
            </div>
            <Badge className="bg-green-500/10 text-green-500">
              Active {mockMemberStats.daysActive} days
            </Badge>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Current ROAS */}
            <div className="p-4 rounded-lg bg-muted/30 border border-border/40">
              <div className="text-xs font-semibold text-muted-foreground mb-1 uppercase tracking-wide">
                Current ROAS
              </div>
              <div className="text-2xl font-bold text-foreground mb-1">
                {mockMemberStats.currentRoas.toFixed(1)}x
              </div>
              <div className="text-xs text-muted-foreground">
                Target: {mockMemberStats.targetRoas.toFixed(1)}x
              </div>
              <div className="mt-2 h-2 bg-muted rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary transition-all"
                  style={{ width: `${(mockMemberStats.currentRoas / mockMemberStats.targetRoas) * 100}%` }}
                />
              </div>
            </div>

            {/* Improvement */}
            <div className="p-4 rounded-lg bg-muted/30 border border-border/40">
              <div className="text-xs font-semibold text-muted-foreground mb-1 uppercase tracking-wide">
                Improvement
              </div>
              <div className="text-2xl font-bold text-green-500 mb-1">
                +{mockMemberStats.improvement}%
              </div>
              <div className="text-xs text-muted-foreground">
                vs first week
              </div>
            </div>

            {/* Next Milestone */}
            <div className="p-4 rounded-lg bg-gradient-to-br from-primary/10 to-purple-500/10 border border-primary/20">
              <div className="text-xs font-semibold text-muted-foreground mb-1 uppercase tracking-wide">
                Next Milestone
              </div>
              <div className="text-sm font-semibold text-foreground">
                {mockMemberStats.nextMilestone}
              </div>
              <div className="text-xs text-muted-foreground mt-2">
                You're {((mockMemberStats.currentRoas / mockMemberStats.targetRoas) * 100).toFixed(0)}% there
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Tab Navigation */}
      <div className="flex gap-2 border-b border-border">
        {[
          { id: 'tasks' as const, label: 'What To Do', icon: Zap },
          { id: 'templates' as const, label: 'Approved Templates', icon: Sparkles },
          { id: 'learn' as const, label: 'Why This Works', icon: Lightbulb }
        ].map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 font-semibold text-sm border-b-2 transition-colors ${
                activeTab === tab.id
                  ? 'border-primary text-foreground'
                  : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      {activeTab === 'tasks' && (
        <div className="space-y-6">
          {/* Simplified AI Analysis */}
          <Card>
            <div className="p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="p-2 rounded-lg bg-primary/10">
                  <Sparkles className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-foreground">AI Analysis</h2>
                  <p className="text-sm text-muted-foreground">Simple breakdown of what to fix and why</p>
                </div>
              </div>

              <div className={`p-4 rounded-lg border mb-4 ${
                mockSimplifiedAnalysis.status === 'warning' 
                  ? 'bg-yellow-500/5 border-yellow-500/20' 
                  : 'bg-green-500/5 border-green-500/20'
              }`}>
                <div className="flex items-center gap-2 mb-1">
                  {mockSimplifiedAnalysis.status === 'warning' ? (
                    <AlertCircle className="w-5 h-5 text-yellow-500" />
                  ) : (
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                  )}
                  <span className="font-semibold text-foreground">{mockSimplifiedAnalysis.headline}</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Follow the tasks below to improve your performance
                </p>
              </div>

              <div className="space-y-3">
                {mockSimplifiedAnalysis.problems.map((problem, index) => (
                  <div key={index} className="p-4 rounded-lg bg-muted/30 border border-border/40">
                    <div className="flex items-start gap-3">
                      {getSeverityIcon(problem.severity)}
                      <div className="flex-1">
                        <div className="font-semibold text-foreground mb-1">{problem.what}</div>
                        <div className="text-sm text-muted-foreground mb-2">
                          <span className="font-semibold">Why it matters:</span> {problem.why}
                        </div>
                        <div className="p-3 rounded-lg bg-background border border-border/40">
                          <div className="text-xs font-semibold text-green-600 mb-1">DO THIS NOW</div>
                          <div className="text-sm text-foreground">{problem.fix}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Card>

          {/* Guided Tasks */}
          <Card>
            <div className="p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="p-2 rounded-lg bg-green-500/10">
                  <Zap className="w-5 h-5 text-green-500" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-foreground">Your Next Steps</h2>
                  <p className="text-sm text-muted-foreground">Clear actions to improve your ads</p>
                </div>
              </div>

              <div className="space-y-3">
                {mockGuidedTasks.map((task) => (
                  <div
                    key={task.id}
                    className={`p-4 rounded-lg border ${getPriorityColor(task.priority)}`}
                  >
                    <div className="flex items-start justify-between gap-4 mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline" className="text-xs uppercase">
                            {task.priority} priority
                          </Badge>
                        </div>
                        <h3 className="font-semibold text-foreground mb-1">{task.title}</h3>
                        <p className="text-sm text-muted-foreground mb-3">{task.description}</p>
                        
                        <div className="space-y-2 mb-3">
                          <div className="p-2 rounded bg-background/50 border border-border/40">
                            <div className="text-xs font-semibold text-muted-foreground mb-1">WHY</div>
                            <div className="text-xs text-foreground">{task.reason}</div>
                          </div>
                          <div className="p-2 rounded bg-background/50 border border-border/40">
                            <div className="text-xs font-semibold text-green-600 mb-1">EXPECTED RESULT</div>
                            <div className="text-xs text-foreground">{task.impact}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <Button variant="accent" size="sm" icon={<ArrowRight className="w-3 h-3" />}>
                      {task.action}
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </div>
      )}

      {activeTab === 'templates' && (
        <Card>
          <div className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-primary/10">
                <Sparkles className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">Approved Templates</h2>
                <p className="text-sm text-muted-foreground">Pre-built by your mentor. Proven to work.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {mockApprovedTemplates.map((template) => (
                <div
                  key={template.id}
                  className={`p-4 rounded-lg border ${
                    template.locked 
                      ? 'bg-muted/20 border-border/40 opacity-60' 
                      : 'bg-muted/30 border-border/40 hover:border-primary/40 transition-colors'
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline" className="text-xs">
                          {template.type}
                        </Badge>
                        {template.locked && (
                          <Lock className="w-3 h-3 text-muted-foreground" />
                        )}
                      </div>
                      <h3 className="font-semibold text-foreground mb-1">{template.name}</h3>
                      <p className="text-sm text-muted-foreground mb-3">{template.description}</p>
                      
                      {template.performance && (
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span>Avg CTR: {template.performance.avgCtr}%</span>
                          <span>Used {template.performance.uses}x</span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <Button 
                    variant={template.locked ? "secondary" : "accent"} 
                    size="sm" 
                    disabled={template.locked}
                    fullWidth
                  >
                    {template.locked ? 'Locked - Ask Mentor' : 'Use Template'}
                  </Button>
                </div>
              ))}
            </div>

            <div className="mt-6 p-4 rounded-lg bg-blue-500/5 border border-blue-500/20">
              <div className="flex items-start gap-3">
                <Lightbulb className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-foreground mb-1">Why use templates?</div>
                  <p className="text-sm text-muted-foreground">
                    These are proven frameworks your mentor uses. They work because they follow best practices 
                    and have been tested across the community. Start here, customize within the guidelines.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </Card>
      )}

      {activeTab === 'learn' && (
        <Card>
          <div className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-purple-500/10">
                <Lightbulb className="w-5 h-5 text-purple-500" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">Why This Works</h2>
                <p className="text-sm text-muted-foreground">Understanding the strategy behind the tactics</p>
              </div>
            </div>

            <div className="space-y-4">
              {/* Methodology */}
              <div className="p-4 rounded-lg bg-gradient-to-br from-primary/5 to-purple-500/5 border border-primary/20">
                <div className="flex items-start gap-3 mb-3">
                  <Users className="w-5 h-5 text-primary shrink-0" />
                  <div>
                    <h3 className="font-semibold text-foreground mb-2">Your Mentor's Methodology</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      "{mockMentorInfo.methodology}"
                    </p>
                    <p className="text-sm text-foreground">
                      This isn't about trying random tactics. Every template, every recommendation, 
                      every guardrail exists because it's been proven across hundreds of campaigns. 
                      Follow the system, and you'll see results.
                    </p>
                  </div>
                </div>
              </div>

              {/* Key Principles */}
              <div className="space-y-3">
                <h3 className="font-semibold text-foreground">Core Principles</h3>
                
                <div className="p-4 rounded-lg bg-muted/30 border border-border/40">
                  <div className="font-semibold text-foreground mb-2">1. Hook → Hold → Close</div>
                  <p className="text-sm text-muted-foreground">
                    First 3 seconds grab attention (Hook). Next 10 seconds build interest (Hold). 
                    Last 5 seconds drive action (Close). Every winning ad follows this structure.
                  </p>
                </div>

                <div className="p-4 rounded-lg bg-muted/30 border border-border/40">
                  <div className="font-semibold text-foreground mb-2">2. Trust Before Transaction</div>
                  <p className="text-sm text-muted-foreground">
                    People buy from brands they trust. Social proof (reviews, testimonials, UGC) 
                    builds trust faster than polished claims. That's why your mentor pushes social proof templates.
                  </p>
                </div>

                <div className="p-4 rounded-lg bg-muted/30 border border-border/40">
                  <div className="font-semibold text-foreground mb-2">3. Test, Don't Guess</div>
                  <p className="text-sm text-muted-foreground">
                    Your mentor's templates aren't random. They're based on data from your community. 
                    When 18 people test mobile-first format and get +36% CTR, that's a pattern worth following.
                  </p>
                </div>

                <div className="p-4 rounded-lg bg-muted/30 border border-border/40">
                  <div className="font-semibold text-foreground mb-2">4. Constraints Create Results</div>
                  <p className="text-sm text-muted-foreground">
                    Locked fields and guardrails aren't limits—they're protection. They stop you from 
                    making costly mistakes others have already made. Follow the guardrails first, 
                    customize once you understand why they exist.
                  </p>
                </div>
              </div>

              {/* Community Wins */}
              <div className="p-4 rounded-lg bg-green-500/5 border border-green-500/20">
                <div className="flex items-start gap-3">
                  <TrendingUp className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold text-foreground mb-1">What's Working in Your Community</div>
                    <ul className="text-sm text-muted-foreground space-y-2">
                      <li>• UGC-style creatives: +36% CTR vs polished content</li>
                      <li>• Problem-Agitate-Solution hooks: +43% CTR</li>
                      <li>• Risk reversal in offers: +28% conversions</li>
                      <li>• Mobile-first (9:16) format: Outperforms square by 2x</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Card>
      )}
    </PageShell>
  );
}
