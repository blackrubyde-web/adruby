import React, { useState } from 'react';
import { PageShell } from '../layout/PageShell';
import { HeroHeader } from '../layout/HeroHeader';
import { Card } from '../layout/Card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { 
  Settings,
  Users,
  Shield,
  Palette,
  Bell,
  Lock,
  Unlock,
  Plus,
  Trash2,
  Save,
  AlertCircle
} from 'lucide-react';
import type { CommunitySettings, StrategyGuardrail } from '../../types/community';

// Mock Data
const mockSettings: CommunitySettings = {
  communityName: 'E-Commerce Masters',
  mentorInfo: {
    name: 'Alex Morrison',
    methodology: 'Data-driven creative testing with proven frameworks',
    welcomeMessage: 'Welcome to E-Commerce Masters! Follow the system, trust the process, and you\'ll see results.'
  },
  features: {
    aiAnalysis: true,
    creativeBuilder: true,
    hookBuilder: true,
    adBuilder: false,
    strategies: true,
    analytics: true
  },
  branding: {
    primaryColor: '#C80000',
    logoUrl: undefined,
    customDomain: undefined
  },
  automation: {
    autoApplyTemplates: true,
    autoShareInsights: true,
    weeklyReports: true
  },
  guardrails: [
    {
      id: '1',
      name: 'Minimum Daily Budget',
      description: 'Prevent budget too low for proper delivery',
      rule: {
        type: 'min',
        field: 'daily_budget',
        value: 50
      },
      enabled: true,
      reason: 'Budgets under $50 rarely get optimal delivery'
    },
    {
      id: '2',
      name: 'Maximum Interests',
      description: 'Limit stacked interests to avoid narrow targeting',
      rule: {
        type: 'max',
        field: 'interests_count',
        value: 3
      },
      enabled: true,
      reason: 'Too many interests = high CPA and poor reach'
    },
    {
      id: '3',
      name: 'Hook Length',
      description: 'First 3 seconds must be attention-grabbing',
      rule: {
        type: 'range',
        field: 'hook_duration',
        value: { min: 2, max: 4 }
      },
      enabled: true,
      reason: 'Optimal hook length for attention + clarity'
    },
    {
      id: '4',
      name: 'Required Elements',
      description: 'Every ad must include CTA button',
      rule: {
        type: 'allowed_values',
        field: 'cta_present',
        value: true
      },
      enabled: true,
      reason: 'Clear CTA improves conversion by 40%+'
    }
  ]
};

export function CommunitySettings() {
  const [settings, setSettings] = useState<CommunitySettings>(mockSettings);
  const [hasChanges, setHasChanges] = useState(false);

  const handleFeatureToggle = (feature: keyof typeof settings.features) => {
    setSettings(prev => ({
      ...prev,
      features: {
        ...prev.features,
        [feature]: !prev.features[feature]
      }
    }));
    setHasChanges(true);
  };

  const handleAutomationToggle = (automation: keyof typeof settings.automation) => {
    setSettings(prev => ({
      ...prev,
      automation: {
        ...prev.automation,
        [automation]: !prev.automation[automation]
      }
    }));
    setHasChanges(true);
  };

  const handleGuardrailToggle = (id: string) => {
    setSettings(prev => ({
      ...prev,
      guardrails: prev.guardrails.map(g => 
        g.id === id ? { ...g, enabled: !g.enabled } : g
      )
    }));
    setHasChanges(true);
  };

  const handleSave = () => {
    // Save logic here
    setHasChanges(false);
    alert('Settings saved successfully!');
  };

  return (
    <PageShell>
      {/* Hero Header */}
      <HeroHeader
        title="Community Settings"
        subtitle="Configure features, guardrails, and automation for your community"
        actions={
          hasChanges && (
            <Button variant="accent" size="sm" icon={<Save className="w-4 h-4" />} onClick={handleSave}>
              Save Changes
            </Button>
          )
        }
      />

      {/* Basic Info */}
      <Card>
        <div className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-lg bg-primary/10">
              <Users className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-foreground">Community Information</h2>
              <p className="text-sm text-muted-foreground">Basic details shown to your members</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">
                Community Name
              </label>
              <Input
                value={settings.communityName}
                onChange={(e) => {
                  setSettings(prev => ({ ...prev, communityName: e.target.value }));
                  setHasChanges(true);
                }}
                placeholder="E-Commerce Masters"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">
                Your Methodology
              </label>
              <Input
                value={settings.mentorInfo.methodology}
                onChange={(e) => {
                  setSettings(prev => ({
                    ...prev,
                    mentorInfo: { ...prev.mentorInfo, methodology: e.target.value }
                  }));
                  setHasChanges(true);
                }}
                placeholder="Data-driven creative testing..."
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">
                Welcome Message
              </label>
              <textarea
                className="w-full px-4 py-2.5 rounded-lg border border-border bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
                rows={3}
                value={settings.mentorInfo.welcomeMessage}
                onChange={(e) => {
                  setSettings(prev => ({
                    ...prev,
                    mentorInfo: { ...prev.mentorInfo, welcomeMessage: e.target.value }
                  }));
                  setHasChanges(true);
                }}
                placeholder="Welcome message for new members..."
              />
            </div>
          </div>
        </div>
      </Card>

      {/* Feature Access */}
      <Card>
        <div className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-lg bg-blue-500/10">
              <Shield className="w-5 h-5 text-blue-500" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-foreground">Feature Access</h2>
              <p className="text-sm text-muted-foreground">Control which features your members can use</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Object.entries(settings.features).map(([key, enabled]) => (
              <div
                key={key}
                className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border/40"
              >
                <div>
                  <div className="font-semibold text-foreground capitalize">
                    {key.replace(/([A-Z])/g, ' $1').trim()}
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {key === 'aiAnalysis' && 'Simplified AI insights and recommendations'}
                    {key === 'creativeBuilder' && 'Template-based creative creation'}
                    {key === 'hookBuilder' && 'Pre-approved hook templates'}
                    {key === 'adBuilder' && 'Full ad builder (advanced)'}
                    {key === 'strategies' && 'Strategy recommendations'}
                    {key === 'analytics' && 'Performance analytics dashboard'}
                  </div>
                </div>
                <button
                  onClick={() => handleFeatureToggle(key as keyof typeof settings.features)}
                  className={`relative w-12 h-6 rounded-full transition-colors ${
                    enabled ? 'bg-primary' : 'bg-muted'
                  }`}
                >
                  <div
                    className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                      enabled ? 'translate-x-6' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            ))}
          </div>
        </div>
      </Card>

      {/* Guardrails */}
      <Card>
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-yellow-500/10">
                <Shield className="w-5 h-5 text-yellow-500" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">Strategy Guardrails</h2>
                <p className="text-sm text-muted-foreground">Protect members from common mistakes</p>
              </div>
            </div>
            <Button variant="secondary" size="sm" icon={<Plus className="w-4 h-4" />}>
              Add Guardrail
            </Button>
          </div>

          <div className="space-y-3">
            {settings.guardrails.map((guardrail) => (
              <div
                key={guardrail.id}
                className={`p-4 rounded-lg border transition-all ${
                  guardrail.enabled
                    ? 'bg-muted/30 border-border/40'
                    : 'bg-muted/10 border-border/20 opacity-60'
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="font-semibold text-foreground">{guardrail.name}</div>
                      {guardrail.enabled ? (
                        <Lock className="w-4 h-4 text-yellow-500" />
                      ) : (
                        <Unlock className="w-4 h-4 text-muted-foreground" />
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{guardrail.description}</p>
                    
                    <div className="p-3 rounded-lg bg-background/50 border border-border/40 mb-3">
                      <div className="text-xs font-semibold text-muted-foreground mb-1">RULE</div>
                      <div className="text-sm text-foreground">
                        {guardrail.rule.type === 'min' && `Minimum ${guardrail.rule.field}: $${guardrail.rule.value}`}
                        {guardrail.rule.type === 'max' && `Maximum ${guardrail.rule.field}: ${guardrail.rule.value}`}
                        {guardrail.rule.type === 'range' && `${guardrail.rule.field}: ${(guardrail.rule.value as any).min}-${(guardrail.rule.value as any).max}s`}
                        {guardrail.rule.type === 'allowed_values' && `${guardrail.rule.field} must be present`}
                      </div>
                    </div>

                    <div className="p-3 rounded-lg bg-blue-500/5 border border-blue-500/20">
                      <div className="text-xs font-semibold text-blue-600 mb-1">WHY THIS MATTERS</div>
                      <div className="text-xs text-foreground">{guardrail.reason}</div>
                    </div>
                  </div>

                  <div className="shrink-0 flex flex-col gap-2">
                    <button
                      onClick={() => handleGuardrailToggle(guardrail.id)}
                      className={`relative w-12 h-6 rounded-full transition-colors ${
                        guardrail.enabled ? 'bg-primary' : 'bg-muted'
                      }`}
                    >
                      <div
                        className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                          guardrail.enabled ? 'translate-x-6' : 'translate-x-0'
                        }`}
                      />
                    </button>
                    <Button variant="ghost" size="sm" icon={<Trash2 className="w-3 h-3" />}>
                      Remove
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 p-4 rounded-lg bg-yellow-500/5 border border-yellow-500/20">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-500 shrink-0 mt-0.5" />
              <div>
                <div className="font-semibold text-foreground mb-1">About Guardrails</div>
                <p className="text-sm text-muted-foreground">
                  Guardrails enforce best practices and prevent costly mistakes. Members can see why 
                  certain options are locked, which helps them learn while protecting their budgets.
                </p>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Automation */}
      <Card>
        <div className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-lg bg-green-500/10">
              <Bell className="w-5 h-5 text-green-500" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-foreground">Automation & Notifications</h2>
              <p className="text-sm text-muted-foreground">Automatically share insights and updates</p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border/40">
              <div>
                <div className="font-semibold text-foreground">Auto-Apply Templates</div>
                <div className="text-xs text-muted-foreground mt-1">
                  Automatically apply new templates to all members
                </div>
              </div>
              <button
                onClick={() => handleAutomationToggle('autoApplyTemplates')}
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  settings.automation.autoApplyTemplates ? 'bg-primary' : 'bg-muted'
                }`}
              >
                <div
                  className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                    settings.automation.autoApplyTemplates ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border/40">
              <div>
                <div className="font-semibold text-foreground">Auto-Share Insights</div>
                <div className="text-xs text-muted-foreground mt-1">
                  Push critical AI insights to members automatically
                </div>
              </div>
              <button
                onClick={() => handleAutomationToggle('autoShareInsights')}
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  settings.automation.autoShareInsights ? 'bg-primary' : 'bg-muted'
                }`}
              >
                <div
                  className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                    settings.automation.autoShareInsights ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border/40">
              <div>
                <div className="font-semibold text-foreground">Weekly Reports</div>
                <div className="text-xs text-muted-foreground mt-1">
                  Send weekly performance summary to all members
                </div>
              </div>
              <button
                onClick={() => handleAutomationToggle('weeklyReports')}
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  settings.automation.weeklyReports ? 'bg-primary' : 'bg-muted'
                }`}
              >
                <div
                  className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                    settings.automation.weeklyReports ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>
      </Card>

      {/* Branding */}
      <Card>
        <div className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-lg bg-purple-500/10">
              <Palette className="w-5 h-5 text-purple-500" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-foreground">Branding</h2>
              <p className="text-sm text-muted-foreground">Customize the look and feel (coming soon)</p>
            </div>
          </div>

          <div className="space-y-4 opacity-60">
            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">
                Primary Color
              </label>
              <div className="flex items-center gap-3">
                <div 
                  className="w-12 h-12 rounded-lg border border-border"
                  style={{ backgroundColor: settings.branding.primaryColor }}
                />
                <Input
                  value={settings.branding.primaryColor}
                  disabled
                  placeholder="#C80000"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">
                Logo URL
              </label>
              <Input
                value={settings.branding.logoUrl || ''}
                disabled
                placeholder="https://your-logo-url.com/logo.png"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">
                Custom Domain
              </label>
              <Input
                value={settings.branding.customDomain || ''}
                disabled
                placeholder="community.yourdomain.com"
              />
            </div>
          </div>

          <div className="mt-4 p-3 rounded-lg bg-muted/30 border border-border/40">
            <div className="text-xs text-muted-foreground">
              🎨 Custom branding is available on Enterprise plans. Contact us to learn more.
            </div>
          </div>
        </div>
      </Card>

      {/* Save Button Footer */}
      {hasChanges && (
        <div className="sticky bottom-6 p-4 rounded-xl bg-card border border-border shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-500" />
              <div>
                <div className="font-semibold text-foreground">You have unsaved changes</div>
                <div className="text-xs text-muted-foreground">Save to apply changes to your community</div>
              </div>
            </div>
            <div className="flex gap-2">
              <Button 
                variant="secondary" 
                size="sm"
                onClick={() => {
                  setSettings(mockSettings);
                  setHasChanges(false);
                }}
              >
                Cancel
              </Button>
              <Button 
                variant="accent" 
                size="sm" 
                icon={<Save className="w-4 h-4" />}
                onClick={handleSave}
              >
                Save Changes
              </Button>
            </div>
          </div>
        </div>
      )}
    </PageShell>
  );
}
