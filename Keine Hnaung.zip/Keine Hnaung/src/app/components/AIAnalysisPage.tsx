import React from 'react';
import { AIAnalysisDashboard } from './analysis/AIAnalysisDashboard';
import { PhilosophyStatement } from './differentiation/PhilosophyStatement';
import { MarketComparison } from './differentiation/MarketComparison';

interface AIAnalysisPageProps {
  onNavigateToBuilder?: () => void;
}

export function AIAnalysisPage({ onNavigateToBuilder }: AIAnalysisPageProps) {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-[1400px] mx-auto px-6 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            AI Analysis Dashboard
          </h1>
          <p className="text-sm text-muted-foreground">
            Decision engine for campaign optimization
          </p>
        </div>

        {/* Philosophy Statement */}
        <div className="mb-8">
          <PhilosophyStatement context="ai-analysis" />
        </div>

        {/* Main Dashboard */}
        <AIAnalysisDashboard onNavigateToBuilder={onNavigateToBuilder} />

        {/* Market Comparison - Bottom of Page */}
        <div className="mt-12">
          <MarketComparison />
        </div>
      </div>
    </div>
  );
}