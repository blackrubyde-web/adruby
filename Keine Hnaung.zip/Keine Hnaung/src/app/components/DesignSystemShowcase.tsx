import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Card, CardHeader, CardContent, CardFooter } from './ui/card';
import { EmptyState, LoadingState, SuccessState, ErrorState } from './ui/EmptyStates';
import { Search, Download, Trash2, Plus, TrendingUp } from 'lucide-react';

export function DesignSystemShowcase() {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-[1400px] mx-auto space-y-12">
        {/* Header */}
        <div>
          <h1 className="text-4xl font-bold text-foreground mb-2">
            AdRuby Design System
          </h1>
          <p className="text-muted-foreground">
            World-class SaaS polish — Calm, Fast, Expensive, Trustworthy
          </p>
        </div>

        {/* Buttons */}
        <section className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-4">Buttons</h2>
            <p className="text-sm text-muted-foreground mb-6">
              Perfect hierarchy with consistent states
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Variants */}
            <Card variant="premium" className="p-6">
              <h3 className="font-bold text-foreground mb-4">Variants</h3>
              <div className="space-y-3">
                <Button variant="primary">Primary Button</Button>
                <Button variant="secondary">Secondary Button</Button>
                <Button variant="accent">Accent Button</Button>
                <Button variant="ghost">Ghost Button</Button>
                <Button variant="danger">Danger Button</Button>
              </div>
            </Card>

            {/* Sizes */}
            <Card variant="premium" className="p-6">
              <h3 className="font-bold text-foreground mb-4">Sizes</h3>
              <div className="space-y-3">
                <Button size="sm">Small Button</Button>
                <Button size="md">Medium Button</Button>
                <Button size="lg">Large Button</Button>
              </div>
            </Card>

            {/* States */}
            <Card variant="premium" className="p-6">
              <h3 className="font-bold text-foreground mb-4">States</h3>
              <div className="space-y-3">
                <Button icon={<Download className="w-4 h-4" />}>
                  With Icon
                </Button>
                <Button loading>Loading State</Button>
                <Button disabled>Disabled State</Button>
              </div>
            </Card>

            {/* Full Width */}
            <Card variant="premium" className="p-6">
              <h3 className="font-bold text-foreground mb-4">Full Width</h3>
              <div className="space-y-3">
                <Button fullWidth variant="primary">
                  Full Width Primary
                </Button>
                <Button fullWidth variant="secondary">
                  Full Width Secondary
                </Button>
              </div>
            </Card>
          </div>
        </section>

        {/* Input Fields */}
        <section className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-4">Input Fields</h2>
            <p className="text-sm text-muted-foreground mb-6">
              Clean, accessible, with perfect focus states
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card variant="premium" className="p-6">
              <h3 className="font-bold text-foreground mb-4">Basic Inputs</h3>
              <div className="space-y-4">
                <Input
                  label="Email Address"
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  fullWidth
                />
                <Input
                  label="Password"
                  type="password"
                  placeholder="••••••••"
                  required
                  fullWidth
                />
              </div>
            </Card>

            <Card variant="premium" className="p-6">
              <h3 className="font-bold text-foreground mb-4">With Icons</h3>
              <div className="space-y-4">
                <Input
                  label="Search"
                  placeholder="Search campaigns..."
                  icon={<Search className="w-4 h-4" />}
                  iconPosition="left"
                  fullWidth
                />
                <Input
                  label="Email"
                  placeholder="you@example.com"
                  error="Invalid email address"
                  fullWidth
                />
              </div>
            </Card>

            <Card variant="premium" className="p-6">
              <h3 className="font-bold text-foreground mb-4">States</h3>
              <div className="space-y-4">
                <Input
                  label="Disabled"
                  placeholder="Disabled input"
                  disabled
                  fullWidth
                />
                <Input
                  label="With Hint"
                  placeholder="Type something..."
                  hint="This is a helpful hint"
                  fullWidth
                />
              </div>
            </Card>

            <Card variant="premium" className="p-6">
              <h3 className="font-bold text-foreground mb-4">Error State</h3>
              <div className="space-y-4">
                <Input
                  label="Campaign Name"
                  placeholder="Summer Sale 2024"
                  error="Campaign name already exists"
                  fullWidth
                />
              </div>
            </Card>
          </div>
        </section>

        {/* Badges */}
        <section className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-4">Badges</h2>
            <p className="text-sm text-muted-foreground mb-6">
              Status indicators with semantic colors
            </p>
          </div>

          <Card variant="premium" className="p-6">
            <div className="space-y-4">
              <div className="flex items-center gap-3 flex-wrap">
                <Badge variant="primary">Primary</Badge>
                <Badge variant="success">Success</Badge>
                <Badge variant="warning">Warning</Badge>
                <Badge variant="danger">Danger</Badge>
                <Badge variant="neutral">Neutral</Badge>
              </div>

              <div className="flex items-center gap-3 flex-wrap">
                <Badge variant="primary" icon={<TrendingUp className="w-3 h-3" />}>
                  With Icon
                </Badge>
                <Badge variant="success" size="sm">Small</Badge>
                <Badge variant="warning" size="md">Medium</Badge>
              </div>
            </div>
          </Card>
        </section>

        {/* Cards */}
        <section className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-4">Cards</h2>
            <p className="text-sm text-muted-foreground mb-6">
              Multiple variants for different contexts
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card variant="standard" className="p-6">
              <CardHeader
                title="Standard Card"
                subtitle="Default card style"
                icon={<TrendingUp className="w-5 h-5 text-primary" />}
              />
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Standard card with hover effect
                </p>
              </CardContent>
            </Card>

            <Card variant="premium" className="p-6">
              <CardHeader
                title="Premium Card"
                subtitle="Shopify-style glass"
                icon={<TrendingUp className="w-5 h-5 text-primary" />}
              />
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Premium glass effect
                </p>
              </CardContent>
            </Card>

            <Card variant="flat" className="p-6">
              <CardHeader
                title="Flat Card"
                subtitle="No shadow"
                icon={<TrendingUp className="w-5 h-5 text-primary" />}
              />
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Minimal flat design
                </p>
              </CardContent>
            </Card>

            <Card variant="glass" className="p-6">
              <CardHeader
                title="Glass Card"
                subtitle="Frosted glass"
                icon={<TrendingUp className="w-5 h-5 text-primary" />}
              />
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Frosted glass effect
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Empty States */}
        <section className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-4">Empty States</h2>
            <p className="text-sm text-muted-foreground mb-6">
              Clear, analytical messaging
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card variant="premium">
              <EmptyState
                type="no-data"
                onAction={() => alert('Action clicked')}
              />
            </Card>

            <Card variant="premium">
              <LoadingState message="Processing campaign data" />
            </Card>

            <Card variant="premium">
              <SuccessState
                title="Campaign deployed"
                description="Changes propagated to active campaigns. Monitor for impact."
              />
            </Card>

            <Card variant="premium">
              <ErrorState
                onRetry={() => alert('Retry')}
              />
            </Card>
          </div>
        </section>

        {/* Typography Scale */}
        <section className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-4">Typography</h2>
            <p className="text-sm text-muted-foreground mb-6">
              Consistent rhythm and hierarchy
            </p>
          </div>

          <Card variant="premium" className="p-6">
            <div className="space-y-4">
              <h1 className="text-4xl font-bold text-foreground">Display Heading</h1>
              <h2 className="text-3xl font-bold text-foreground">H1 Heading</h2>
              <h3 className="text-2xl font-bold text-foreground">H2 Heading</h3>
              <h4 className="text-xl font-bold text-foreground">H3 Heading</h4>
              <p className="text-base text-foreground">
                Body text with perfect line-height and spacing for optimal readability
              </p>
              <p className="text-sm text-muted-foreground">
                Small body text for secondary content
              </p>
              <p className="text-xs text-muted-foreground">
                Caption text for labels and hints
              </p>
            </div>
          </Card>
        </section>

        {/* Color System */}
        <section className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-4">Color System</h2>
            <p className="text-sm text-muted-foreground mb-6">
              Professional black/white + #C80000 accent
            </p>
          </div>

          <Card variant="premium" className="p-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <div className="w-full h-20 bg-foreground rounded-lg mb-2" />
                <p className="text-xs font-semibold">Foreground</p>
                <p className="text-xs text-muted-foreground">Primary text</p>
              </div>
              <div>
                <div className="w-full h-20 bg-background border border-border rounded-lg mb-2" />
                <p className="text-xs font-semibold">Background</p>
                <p className="text-xs text-muted-foreground">Page background</p>
              </div>
              <div>
                <div className="w-full h-20 bg-primary rounded-lg mb-2" />
                <p className="text-xs font-semibold">Primary</p>
                <p className="text-xs text-muted-foreground">#C80000 accent</p>
              </div>
              <div>
                <div className="w-full h-20 bg-muted rounded-lg mb-2" />
                <p className="text-xs font-semibold">Muted</p>
                <p className="text-xs text-muted-foreground">Subtle backgrounds</p>
              </div>
            </div>
          </Card>
        </section>
      </div>
    </div>
  );
}
