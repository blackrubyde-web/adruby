import { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { AdMetricsCard } from './components/AdMetricsCard';
import { PerformanceChart } from './components/PerformanceChart';
import { AudienceBreakdown } from './components/AudienceBreakdown';
import { CampaignsTable } from './components/CampaignsTable';
import { StrategyInsights } from './components/StrategyInsights';
import { AdBuilderPage } from './components/AdBuilderPage';
import { AnalyticsPage } from './components/AnalyticsPage';
import { AdsStrategiesPage } from './components/AdsStrategiesPage';
import { CampaignsPage } from './components/CampaignsPage';
import { AIAnalysisPage } from './components/AIAnalysisPage';
import { HookBuilderPage } from './components/HookBuilderPage';
import { CreativeBuilderPage } from './components/builder/CreativeBuildePage';
import { LearningDashboard } from './components/LearningDashboard';
import { AgencyDashboard } from './components/AgencyDashboard';
import { MasterDemo } from './components/MasterDemo';
import { SettingsPage } from './components/SettingsPage';
import { AffiliatePage } from './components/AffiliatePage';
import { ProfilePage } from './components/ProfilePage';
import { HelpSupportPage } from './components/HelpSupportPage';
import { OverviewPage } from './components/OverviewPage';
import { LandingPage } from './components/LandingPage';
import { FeaturesPage } from './components/FeaturesPage';
import { PricingPage } from './components/PricingPage';
import { MarketingShell } from './components/MarketingShell';
import { AppShell } from './components/AppShell';
import { 
  LoginPage, 
  RegisterPage, 
  AuthProcessingPage, 
  PaymentVerificationPage,
  PaymentSuccessPage,
  PaymentCancelledPage 
} from './components/auth';
import { ThemeProvider } from './components/ThemeProvider';
import { TimeRangeFilter } from './components/TimeRangeFilter';
import { PerformanceScore } from './components/PerformanceScore';
import { BudgetTracker } from './components/BudgetTracker';
import { AIInsightsPanel } from './components/AIInsightsPanel';
import { PerformanceHeatmap } from './components/PerformanceHeatmap';
import { ConversionFunnel } from './components/ConversionFunnel';
import { PredictiveAnalytics } from './components/PredictiveAnalytics';
import { QuickActionsButton } from './components/QuickActionsButton';
import { NotificationBanner } from './components/NotificationBanner';
import { DashboardCustomizer, DashboardSection } from './components/DashboardCustomizer';
import { ReorderableWidget } from './components/ReorderableWidget';
import { GridDashboard } from './components/GridDashboard';
import { AppleGridDashboard } from './components/AppleGridDashboard';
import { GettingStartedChecklist } from './components/GettingStartedChecklist';
import { MobileKPICarousel } from './components/MobileKPICarousel';
import { Eye, MousePointerClick, DollarSign, TrendingUp, LayoutGrid, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import { Toaster } from './components/ui/sonner';

// Page type - Extended with auth pages
export type PageType = 
  | 'landing' 
  | 'features'
  | 'pricing'
  | 'login' 
  | 'register' 
  | 'auth-processing' 
  | 'payment-verification' 
  | 'payment-success' 
  | 'payment-cancelled'
  | 'dashboard' 
  | 'analytics' 
  | 'adbuilder' 
  | 'strategies' 
  | 'campaigns' 
  | 'aianalysis'
  | 'creative-builder'
  | 'hook-builder'
  | 'settings' 
  | 'affiliate' 
  | 'profile' 
  | 'help';

// Default Dashboard Configuration - Only Essential HIGH-LEVEL Sections
const DEFAULT_SECTIONS: DashboardSection[] = [
  {
    id: 'ai-insights',
    name: 'AI-Powered Insights',
    description: 'Smart recommendations and anomaly detection',
    category: 'essential',
    isVisible: true
  },
  {
    id: 'performance-chart',
    name: 'Performance Trend',
    description: 'High-level performance over time',
    category: 'essential',
    isVisible: true
  },
  {
    id: 'campaigns-table',
    name: 'Recent Campaigns',
    description: 'Quick overview of active campaigns',
    category: 'essential',
    isVisible: false
  },
  {
    id: 'metrics',
    name: 'Detailed Metrics',
    description: 'Deep dive into performance numbers',
    category: 'analytics',
    isVisible: false
  },
  {
    id: 'notifications',
    name: 'Alerts & Notifications',
    description: 'Critical alerts about budget and performance',
    category: 'essential',
    isVisible: false
  },
  {
    id: 'performance-score',
    name: 'Performance Score',
    description: 'Overall campaign health score (0-100)',
    category: 'essential',
    isVisible: false
  },
  {
    id: 'budget-tracker',
    name: 'Budget Tracker',
    description: 'Track spending and remaining budget',
    category: 'essential',
    isVisible: false
  },
  {
    id: 'audience-breakdown',
    name: 'Audience Demographics',
    description: 'Age and gender distribution of your audience',
    category: 'analytics',
    isVisible: false
  },
  {
    id: 'conversion-funnel',
    name: 'Conversion Funnel',
    description: 'Track user journey from impression to purchase',
    category: 'analytics',
    isVisible: false
  },
  {
    id: 'performance-heatmap',
    name: 'Performance Heatmap',
    description: 'Best times to run ads by day and hour',
    category: 'advanced',
    isVisible: false
  },
  {
    id: 'predictive-analytics',
    name: 'Predictive Analytics',
    description: '7-day forecast with AI-powered predictions',
    category: 'advanced',
    isVisible: false
  },
  {
    id: 'strategy-insights',
    name: 'Strategy Insights',
    description: 'Additional strategic recommendations',
    category: 'advanced',
    isVisible: false
  }
];

function AppContent() {
  const [currentPage, setCurrentPage] = useState<PageType>('landing'); // Start with landing page
  
  // Show MasterDemo instead of regular flow
  return (
    <div className="min-h-screen w-full max-w-[100vw] overflow-x-hidden">
      <MasterDemo />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <Toaster />
      <AppContent />
    </ThemeProvider>
  );
}